/**
 * To display limit on buttons
 * @param limit {object}
 * @return {{overusage: boolean, overusagePrice: number, remaining: number} | null}
 */
export function getSingleDownloadLimit (limit) {
  if (!limit) { return null }
  if (limit.used < limit.max) {
    return {
      overusage: false,
      remaining: limit.max - limit.used,
      overusagePrice: 0
    }
  }
  if (limit.used >= limit.max) {
    return {
      overusage: true,
      remaining: 0,
      overusagePrice: limit.overusagePrice
    }
  }
}

/**
 * To display limit on buttons
 * @param limit {object}
 * @param collection {object}
 * @param alreadyDownloadedIconsIds
 * @return {{
 *  overLimit: number,
 *  overusage: boolean,
 *  overusageOverallPrice: object,
 *  remaining: number,
 *  paidIconsNum: number
 * } | null}
 */
export function getCollectionDownloadLimit (
  limit,
  collection,
  alreadyDownloadedIconsIds
) {
  if (!limit || !collection || !collection.icons) { return null }

  const paidIcons = collection?.icons.filter(icon => !alreadyDownloadedIconsIds.includes(icon.id) && !(icon.isFree || icon.free))
  const paidIconsNum = getPaidIconsAmount(paidIcons)

  let overLimit = limit.usagesLeft - paidIconsNum
  if (overLimit >= 0) overLimit = 0
  else overLimit = Math.abs(overLimit)

  return {
    ...limit,
    paidIconsNum,
    overLimit
  }
}

/**
 * Calculate amount of unique icons in given array.
 * @param {Object[]} icons
 * @returns {number}
 */
function getPaidIconsAmount (icons) {
  return getUniqueIconIds(icons).length
}

/**
 * Get unique icon ids from given array.
 * @param {Object[]} icons
 * @returns {number[]}
 */
function getUniqueIconIds (icons) {
  return [...new Set(icons.map(icon => icon.id))]
}

/**
 * Convert price object to price string.
 * @param value {number}
 * @param currency {string | undefined}
 * @return {string}
 */
export function toCurrencyString ({ value, currency = 'USD' }) {
  return Number(value).toLocaleString('en-US', {
    style: 'currency',
    currency,
    maximumFractionDigits: 3,
    minimumFractionDigits: 0
  })
}

/**
 * Set data with given key to localStorage.
 * @param {string} key
 * @param {object} data
 */
export function setToLocalStorage (key, data) {
  localStorage.setItem(key, JSON.stringify(data))
}

/**
 * Get data with given key from localStorage.
 * @param {string} key
 * @returns {any}
 */
export function getFromLocalStorage (key) {
  return JSON.parse(localStorage.getItem(key))
}

/**
 * Simple debounce.
 * TODO: get rid of 'debounce' npm package.
 * @param {*} func
 * @param {number} wait
 * @param immediate
 * @returns {function(...[*]=)}
 */
export function debounce (func, wait, immediate) {
  let timeout
  return function () {
    const context = this; const args = arguments
    const later = function () {
      timeout = null
      if (!immediate) func.apply(context, args)
    }
    const callNow = immediate && !timeout
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
    if (callNow) func.apply(context, args)
  }
}

/**
 * Get given number with commas as thousands separators.
 * Example: 1999 -> 1,999
 * @param {*} number
 * @returns {String}
 */
export function beatifyNumberWithCommas (number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

/**
 * Remove filter params from given string.
 * @param {String} str
 * @param {Object} filters
 * @return {String}
 */
export function clearFilterParams (str, filters = {}) {
  let term = str
  // clear string from filter params (they can be mixed in url with search query parts in any order)
  if (filters.authors) term = term.replace(`--${filters.authors}`, '')
  if (filters.color) term = term.replace(`--${filters.color}`, '')
  if (filters.isAnimated !== undefined) {
    term = term.replace(`--${filters.isAnimated ? 'animated' : 'static'}`, '')
  }
  return term
}

export function trimTerm (term, normalizeFn) {
  return decodeURIComponent(
    normalizeFn(
      term
        .trim()
        .replace(/ +/g, ' ')
        .replace(/[-/\\^+?%&.()|[\]{}<>"#]/g, '')
    )
  )
}

/**
 * Format number in comma separated number rounded to hundreds.
 * @param {String} num
 * @returns {String}
 */
export function formatToHundreds (num) {
  let str = num.replace(/,/g, '')
  str = str.replace(/ /g, '')
  str = parseInt(Math.floor(str / 100) * 100).toString()
  str = str.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  return str
}
