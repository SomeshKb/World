import { getIconContentBySVG } from '@/api/icon/download/bySvg'
import axios from '@/plugins/axios'
import { normalizeValue } from '@icons8/frontend-utils'
import iconUtils from '@/plugins/iconUtils'
import { mapState } from 'vuex'

const base64Cache = {}

// icons8 images in different formats for stubs
export const icons8PngCDN = '<img src="https://img.icons8.com/material-sharp/96/1FB141/icons8-new-logo.png"/>'
export const icons8PngBase64 = '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABmJLR0QA/wD/AP+gvaeTAAAHTElEQVR4nO2dbWxb5RmGr+e1TZJ2tBrawpYlcUI7Oug00arSxpowO1m/GHXCVto/sD9M++i6FjGxT1AjNqQxaSoTFBDi34omdYLGBALNaGzSFm1joEoTqTalS5x0H4xttB2Fhtjn2Y8kXeR2tOfDPuXNuST/iu7nvZXLPvY5Oq8NERERERERERERERERERERERER7w/EbaC5L9WGsroSZfwwnsnf7yXXkkvVOidkuQjLxEi9g1Mz/Rd5MyYyZkrFo8e6hyaC7PpexN0GjGM+r+jOSpTxyUULady77op4zdQWRTfpKT4rhloAVUXmPEcdVRyJkcymR1GeA3mi0D34UgW6n8W1kPczTdk1DTEpflf13a8oLHARbUXYCro1mU2/isqPC92D+yrR0VRi6CVHT49pzqZ2GIpHVdmOOxnlrET0qWRv+oXGbGppUBVnsV5IQ1/qQ80rXuwX5AFgUWCDhc4Y8kpLb2pLYDOxXEhTdk1DoiQ5gXUVWmKRivyyJdvRE9RAa4UseWptvVDKI3yywkuJojuT2fRdQQyzUkjj3uvrirGp/YJ+vIrL3t+c7bjF7xArhZja2l3AdVVeVgR9vGlfxxI/Q6wT0tTb2S7KV0NaflHMOI/4GWCXEEWMOA/h4QpEgBXWNGXTGa95q4S09KUzwKfC7mHgHh9Zi1D9ZtgVZljV0pv+tJegNUKasmsaFOkIu8csKtzmJWeNkBhTa4BY2D3m4Olk1BohitwQdocyljb2dXzMbcgaIcC1YRcox5Sca1xnKlEkJFrDLnAORq5yHalEj5AI7kpuQIiy2G3GJiGJsAucg+plbiM2CTkddoFyFPmP24w1QhT5R9gdyjGirjtZI0Tgj2F3KEdxXHeyScgrYXco4+1EYuGw25A1QkoqB8LuMBdBD4/c+Nyk25w1QiaOtB8GjofdYxYH8ysvOWuE0NPjqOiesGvMcNo4zjwXApgYPwfeCbsHyKNjN+dPeElaJWTsC/m/Aw+FXONEvBT/qdewVUIA3p7Ue4HxsNYX5AfHvjjg+ZzIOiFvbM6/JaJbgKmqLy70j2UGH/UzwjohAGOZ/G8Q7qjyssNqpm5FUD9DrBQCUMjkHkb17iotdyyupfXjNx160+8ga4UAFLrz9wmyFShWag1BXzaY1UFt6rFaCMBY1+AjqHwOpRDwaEV5MJ6oax/tOvB6UEOtFwJQ6B586UxdYrmK/oRgzlN+j0pboTu33cvlkfdi3uygen3dwGng+63ZzgccdbYjfBlodDGiBDoAsruQyfX7ffP+f8wbIbPMHF5+SE/PPc0rXrxeoENglcIyoB5YzPSr6C1gBBhWdChRumzAz/nFxTIvDlnn5drXJIbEFDWKGEVm/xcy5xEDDCqmqO9U5Z6vefcKST7Z/lGJJXao/PM2Bxqmd91q+d3ZC2Ye9cBnRLideLzU3Js+oMLuiUyuLzpk+eTDe1MfWFBjekC3KVrjYURMhLUCa5NPp4+YrOwY7RocCrrnvDhkNfV2ttfVyDDotwEvMsq5zkHzyWz64ZZcqjaAeWexXkgy27HNiDMo0BTwaAG+oafkcMuzqY8ENdRqIclsx92gD1LZQ/NKLcrhJb03BCLcWiHJbMc20B9Vabmriia+v3Hvuiv8DrJSSFNvZzvorqouqnpNrGZyz7kf2NxhnZBl2dWXizhPEMonSNmQzKa2+plgnZAz1OyswBv4xSNyX2u280qvcauETH/aUV/P0ABY7OB8x2vYKiFMmTuAurBrAF9rfqbtg16C9gjp6TEqemvYNWZYiJPw9DUb1ghpXTHUBrje01cpjOomT7mgi4SFwiWzJRpAkdVL+ze4vkxjkRBdFXaHMhZMTZ12vRHVIiFyddgdyhHMMrcZa4QIWh92h3IcFdedrBECLAy7QDmCXu42Y5OQ6t86eiFE3nUbsUnIqbALlKPCSbcZm4SMhl3gHBz9s9uITUJeC7tAOU7MHHWbsUaIoAfD7lDGyPGNg39xG7JGiBZLA0Ap7B7/Q5/3krJGSOFLB/+myiWzNdo45heeckEXCRMVdofdAaa3KIzePPg7L1mrhExkcn3AkbB7OGo831xhlRAEVaPfgsrc5nkxqDIw3j3Y5zVvlxBgfGP+EOBr46UPToopfd3PAOuEAMgivRN4tcrLKsLthcyQrxNUK4WMpfNnEonieuBP1VtV7ypkck/6nWKlEICRGw++4RBPC/KHCi+lKvq9Qlf+Z0EMs1YIwETXr/9anEykgGcrtMRJhFu8/mTf+bBaCMDxzfv/XcjkNqK6DfD0hTDnQ2G/xmIrgzhMzcV6IQAIWujO7zaYTyDswscXZgr6sqpkxrty68dvesH11dwLMW92UMHZDZ93tuxL3evEZLNR3aRIGxe+uW4E9HlR2TPWnf9tJTu6FuKoc8hgAjtmhsHMd1k9Bjy2tH9DzVRpcrk4ztUOXIlM/+qnOPxLJVZwjA57uWobERERERERERERERERERERERFhO/8FIwUq5gTtlIMAAAAASUVORK5CYII=">'
export const icons8SvgInline = '<svg\nxmlns="http://www.w3.org/2000/svg"\nx="0px" y="0px"\nwidth="100" height="100"\nviewBox="0 0 172 172"\nstyle=" fill:#26e07f;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#1fb141"><path d="M21.5,21.5v129h64.5v-32.25v-64.5v-32.25zM86,53.75c0,17.7805 14.4695,32.25 32.25,32.25c17.7805,0 32.25,-14.4695 32.25,-32.25c0,-17.7805 -14.4695,-32.25 -32.25,-32.25c-17.7805,0 -32.25,14.4695 -32.25,32.25zM118.25,86c-17.7805,0 -32.25,14.4695 -32.25,32.25c0,17.7805 14.4695,32.25 32.25,32.25c17.7805,0 32.25,-14.4695 32.25,-32.25c0,-17.7805 -14.4695,-32.25 -32.25,-32.25z"></path></g></g></svg>'
export const icons8SvgImgTag = '<img alt="svgImg" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHg9IjBweCIgeT0iMHB4Igp3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIKdmlld0JveD0iMCAwIDE3MiAxNzIiCnN0eWxlPSIgZmlsbDojMjZlMDdmOyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJub256ZXJvIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9ImJ1dHQiIHN0cm9rZS1saW5lam9pbj0ibWl0ZXIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWRhc2hhcnJheT0iIiBzdHJva2UtZGFzaG9mZnNldD0iMCIgZm9udC1mYW1pbHk9Im5vbmUiIGZvbnQtd2VpZ2h0PSJub25lIiBmb250LXNpemU9Im5vbmUiIHRleHQtYW5jaG9yPSJub25lIiBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6IG5vcm1hbCI+PHBhdGggZD0iTTAsMTcydi0xNzJoMTcydjE3MnoiIGZpbGw9Im5vbmUiPjwvcGF0aD48ZyBmaWxsPSIjMWZiMTQxIj48cGF0aCBkPSJNMjEuNSwyMS41djEyOWg2NC41di0zMi4yNXYtNjQuNXYtMzIuMjV6TTg2LDUzLjc1YzAsMTcuNzgwNSAxNC40Njk1LDMyLjI1IDMyLjI1LDMyLjI1YzE3Ljc4MDUsMCAzMi4yNSwtMTQuNDY5NSAzMi4yNSwtMzIuMjVjMCwtMTcuNzgwNSAtMTQuNDY5NSwtMzIuMjUgLTMyLjI1LC0zMi4yNWMtMTcuNzgwNSwwIC0zMi4yNSwxNC40Njk1IC0zMi4yNSwzMi4yNXpNMTE4LjI1LDg2Yy0xNy43ODA1LDAgLTMyLjI1LDE0LjQ2OTUgLTMyLjI1LDMyLjI1YzAsMTcuNzgwNSAxNC40Njk1LDMyLjI1IDMyLjI1LDMyLjI1YzE3Ljc4MDUsMCAzMi4yNSwtMTQuNDY5NSAzMi4yNSwtMzIuMjVjMCwtMTcuNzgwNSAtMTQuNDY5NSwtMzIuMjUgLTMyLjI1LC0zMi4yNXoiPjwvcGF0aD48L2c+PC9nPjwvc3ZnPg=="/>'
export const icons8SvgBgHtml = '<div class="icons8-icons8"></div>'
export const icons8SvgBgCss = '.icons8-icons8 { \ndisplay: inline-block;\nwidth: 100px;\nheight: 100px;\nbackground: url(\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHg9IjBweCIgeT0iMHB4Igp3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIKdmlld0JveD0iMCAwIDE3MiAxNzIiCnN0eWxlPSIgZmlsbDojMjZlMDdmOyI+PGcgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJub256ZXJvIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgc3Ryb2tlLWxpbmVjYXA9ImJ1dHQiIHN0cm9rZS1saW5lam9pbj0ibWl0ZXIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIgc3Ryb2tlLWRhc2hhcnJheT0iIiBzdHJva2UtZGFzaG9mZnNldD0iMCIgZm9udC1mYW1pbHk9Im5vbmUiIGZvbnQtd2VpZ2h0PSJub25lIiBmb250LXNpemU9Im5vbmUiIHRleHQtYW5jaG9yPSJub25lIiBzdHlsZT0ibWl4LWJsZW5kLW1vZGU6IG5vcm1hbCI+PHBhdGggZD0iTTAsMTcydi0xNzJoMTcydjE3MnoiIGZpbGw9Im5vbmUiPjwvcGF0aD48ZyBmaWxsPSIjMWZiMTQxIj48cGF0aCBkPSJNMjEuNSwyMS41djEyOWg2NC41di0zMi4yNXYtNjQuNXYtMzIuMjV6TTg2LDUzLjc1YzAsMTcuNzgwNSAxNC40Njk1LDMyLjI1IDMyLjI1LDMyLjI1YzE3Ljc4MDUsMCAzMi4yNSwtMTQuNDY5NSAzMi4yNSwtMzIuMjVjMCwtMTcuNzgwNSAtMTQuNDY5NSwtMzIuMjUgLTMyLjI1LC0zMi4yNWMtMTcuNzgwNSwwIC0zMi4yNSwxNC40Njk1IC0zMi4yNSwzMi4yNXpNMTE4LjI1LDg2Yy0xNy43ODA1LDAgLTMyLjI1LDE0LjQ2OTUgLTMyLjI1LDMyLjI1YzAsMTcuNzgwNSAxNC40Njk1LDMyLjI1IDMyLjI1LDMyLjI1YzE3Ljc4MDUsMCAzMi4yNSwtMTQuNDY5NSAzMi4yNSwtMzIuMjVjMCwtMTcuNzgwNSAtMTQuNDY5NSwtMzIuMjUgLTMyLjI1LC0zMi4yNXoiPjwvcGF0aD48L2c+PC9nPjwvc3ZnPg==\') 50% 50% no-repeat;\nbackground-size: 100%; }'

/**
 * Method for creating object to generate manifest.json for Android Chrome category in Favicon format.
 * @param {String} fileName
 * @param {[Object]} selectedSizes Array of selected sizes from DownloadIconModalV2 component
 */
export function generateAndroidManifest (fileName, selectedSizes) {
  const androidSizes = selectedSizes.filter(selectedSize => selectedSize.category === 'Android Chrome')
  if (androidSizes.length > 0) {
    const manifest = {
      name: 'App',
      icons: []
    }

    androidSizes.forEach(androidSize => {
      if (androidSize.width === 36) {
        manifest.icons.push(
          {
            src: `/${fileName}-36.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '0.75'
          }
        )
      } else if (androidSize.width === 48) {
        manifest.icons.push(
          {
            src: `/${fileName}-48.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '1.0'
          }
        )
      } else if (androidSize.width === 72) {
        manifest.icons.push(
          {
            src: `/${fileName}-72.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '1.5'
          }
        )
      } else if (androidSize.width === 96) {
        manifest.icons.push(
          {
            src: `/${fileName}-96.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '2.0'
          }
        )
      } else if (androidSize.width === 144) {
        manifest.icons.push(
          {
            src: `/${fileName}-144.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '3.0'
          }
        )
      } else if (androidSize.width === 192) {
        manifest.icons.push(
          {
            src: `/${fileName}-192.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png',
            density: '4.0'
          }
        )
      } else {
        manifest.icons.push(
          {
            src: `/${fileName}-${androidSize.width}.png`,
            sizes: `${androidSize.size}`,
            type: 'image/png'
          }
        )
      }
    })
    return JSON.stringify(manifest, null, ' ')
  } else {
    return undefined
  }
}

/**
 * Method to generate additional properties for selected size object of favicon format.
 * Generates html and assigns formats for corresponding category and size.
 * @param {Number} width Width of icon size
 * @param {Number} height Height of icon size
 * @param {'Web' | 'Android Chrome' | 'iOS Safari Web Clip' | 'iOS Safari Web Clip' | 'macOS' | 'Windows'} category Name of the category.
 * @param {String} fileName
 */
export function faviconProperties (width, height, category, fileName) {
  let formats
  let html
  if (category === 'Web') {
    if (width === 16 && height === 16) {
      html = [
        // `<link type="image/x-icon" rel="shortcut icon" href=".../${fileName}-${width}.ico">`,
        `<link type="image/png" sizes="${width}x${height}" rel="icon" href=".../${fileName}-${width}.png">`
      ]
      // formats = ['ico', 'png']
      formats = ['png']
    } else {
      html = [`<link type="image/png" sizes="${width}x${height}" rel="icon" href=".../${fileName}-${width}.png">`]
      formats = ['png']
    }
  } else if (category === 'Android Chrome') {
    html = [`<link rel="icon" type="image/png" sizes="${width}x${height}" href=".../${fileName}-${width}.png">`]
    formats = ['png']
  } else if (category === 'iOS Safari Web Clip') {
    html = [`<link rel="apple-touch-icon" type="image/png" sizes="${width}x${height}" href=".../${fileName}-${width}.png">`]
    formats = ['png']
  } else if (category === 'macOS') {
    // todo: pick similar black icon (outlined, ios and etc style), if current is colorful and let user pick color. (link below)
    // https://www.figma.com/file/RalhItBw7aq19O9DXG6FRo?node-id=605:3740#148892282
    // chosen default color is icons8 green (#26E07F), which should be chosen by user (user cant do it now)
    formats = ['svg']
    html = [`<link color="#26E07F" rel="mask-icon" href=".../${fileName}-${width}.svg">`]
  } else if (category === 'Windows') {
    formats = ['png']
    if (width === 144) {
      html = [`<meta name="msapplication-TileImage" content=".../${fileName}-${width}.png">`]
    } else if (width === 70) {
      html = [`<meta name="msapplication-square70x70logo" content=".../${fileName}-${width}.png">`]
    } else if (width === 150) {
      html = [`<meta name="msapplication-square150x150logo" content=".../${fileName}-${width}.png">`]
    } else if (width === 310 && height === 310) {
      html = [`<meta name="msapplication-square310x310logo" content=".../${fileName}-${width}.png">`]
    } else if (width === 310 && height === 150) {
      // this combination of width and height is implemented for future usage (this condition is unreachable because of unsupported asymmetric size)
      html = [`<meta name="msapplication-wide310x150logo" content=".../${fileName}-${width}.png">`]
    }
  }
  return { formats, html }
}

/**
 * Method for generating img element with source link from CDN.
 * For Link (CDN) icon format
 * @param {Object} icon
 * @param {Number} size
 * @param {Object} platforms
 * @return {Promise} Promise with string img element in 'result' property
 */
export function pngCdn (icon, size, platforms) {
  return new Promise((resolve) => {
    const content = {
      preview: undefined,
      result: undefined,
      html: undefined,
      css: undefined
    }
    const platform = platforms[icon.platform]
    const seoCode = platform ? platform.seoCode : icon.platform
    let url = `${process.env.iconsUrl}/${seoCode}/${size}/${icon.color}/${icon.commonName}.png`

    if (icon.platform === 'nolan') {
      if (icon.colorGradient) {
        const gradientStart = icon.colorGradient.start.replace('#', '')
        const gradientEnd = icon.colorGradient.end.replace('#', '')
        url = `${process.env.iconsUrl}/${seoCode}/${size}/${gradientStart}/${gradientEnd}/${icon.commonName}.png`
      } else {
        url = `${process.env.iconsUrl}/${seoCode}/${size}/${icon.commonName}.png`
      }
    }

    content.result = `<img src="${url}"/>`
    resolve(content)
  })
}

/**
 * Method for generating img element with bas64 encoded image in source.
 * For Base64 icon format
 * @param {Object} icon
 * @param {Number} size
 * @param {Object} platforms
 * @return {Promise} Promise with string img element in 'result' property
 */
export function pngBase64 (icon, size, platforms) {
  return new Promise((resolve, reject) => {
    const content = {
      preview: undefined,
      result: undefined,
      html: undefined,
      css: undefined
    }

    let color
    if (!icon.svgEffect) {
      color = icon.color
      if (icon.platform === 'nolan' && icon.colorGradient) {
        // // gradients are not supported by getIconContentBySVG

        // const gradientStart = icon.colorGradient.start.replace('#', '')
        // const gradientEnd = icon.colorGradient.end.replace('#', '')
        // color = `${gradientStart},${gradientEnd}`
        color = undefined
      }


    }

    const base64CacheKey = `${icon.id}_${size}_${color}`
    if (!icon.svgEffect && base64Cache[base64CacheKey]) {
      content.preview = base64Cache[base64CacheKey].preview
      content.result = content.preview
      resolve(content)
      return
    }

    getIconContentBySVG(icon.svgEffect || icon.svg, 'png', size, color, undefined, icon.id, icon.free || icon.isFree)
      .then(response => {
        const reader = new FileReader()
        reader.onloadend = () => {
          content.preview = `<img src="${reader.result}">`
          content.result = content.preview

          if (!icon.svgEffect) {
            base64Cache[base64CacheKey] = {
              preview: content.preview
            }
          }

          resolve(content)
        }
        reader.readAsDataURL(response.data)
      })
      .catch(reject)
  })
}

/**
 * Method for generating svg element from icon.
 * WARNING: icon must have svgEffect or svg
 * @param {Object} icon
 * @param {Number} size
 * @return {String} String
 */
export function getIconSVG (icon, size) {
  const svg = icon.svgEffect || icon.svg
  if (!svg) {
    console.warn('getIconSVG: svg is not defined')
    return ''
  }
  const $svg = iconUtils.getSVGNode(svg)
  convertIdsGradient($svg, icon)
  const innerHTML = $svg.innerHTML

  const viewBoxSvg = $svg.getAttribute('viewBox')
  const styleSvg = $svg.getAttribute('style')
  const svgBody = innerHTML.split('\n').join('')
  const svgStyle = styleSvg || icon.color ? `style="${styleSvg ? styleSvg + '; ' : ''}${icon.color? `fill:#${icon.color};` : ''}"` : ''
  const svgStart = `<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
width="${size}" height="${size}"
viewBox="${viewBoxSvg}"${svgStyle ? '\n' + svgStyle: ''}>`

  const svgEnd = '</svg>'
  return svgStart + '\n' +svgBody + '\n' + svgEnd
}

/**
 * pls describe who understands what it does...
 * @param {ChildNode} svg
 * @param {Object} icon
 */
export function convertIdsGradient (svg, icon) {
  if (svg.children && svg.children.length > 0) {
    const mapGradients = {}
    let index = 0
    for (const element of svg.children) {
      if (element.tagName === 'linearGradient') {
        index++
        const newId = `${element.id}_${icon.id}_gr${index}`
        mapGradients[element.id] = newId
        element.id = newId
      }
      if (element.tagName === 'defs') {
        for (const defs of element.children) {
          index++
          const newId = `${defs.id}_${icon.id}_gr${index}`
          mapGradients[defs.id] = newId
          defs.id = newId
        }
      }
    }
    for (const element of svg.children) {
      if (element.tagName !== 'linearGradient') {
        element.outerHTML = element.outerHTML.replace(
          new RegExp('fill="(.+?)"', 'gim'),
          (m, group) => {
            if (group.indexOf('url') !== -1) {
              let id = group.split('(#')[1]
              id = id.slice(0, -1)
              return `fill="url(#${mapGradients[id]})"`
            } else {
              return `fill="${group}"`
            }
          }
        )
      }
    }
  }
}

/**
 * Method for generating inline svg element from icon
 * @param {Object} icon
 * @param {Number} size
 * @return {Promise} Promise with string svg element in 'result' property
 */
export function svgInline (icon, size) {
  return new Promise(resolve => {
    const content = {
      preview: undefined,
      result: undefined,
      html: undefined,
      css: undefined
    }
    content.preview = undefined
    content.result = getIconSVG(icon, size)
    resolve(content)
  })
}

/**
 * Method for generating img element with base64 encoded svg element in source
 * @param {Object} icon
 * @param {Number} size
 * @return {Promise} Promise with string img element in 'result' property
 */
export function svgImg (icon, size) {
  return new Promise((resolve, reject) => {
    let content = {
      preview: undefined,
      result: undefined,
      html: undefined,
      css: undefined
    }
    svgInline(icon, size).then((result) => {
      content = { ...content, ...result }
      content.result = `<img alt="svgImg" src="data:image/svg+xml;base64,${window.btoa(
        content.result
      )}"/>`
      resolve(content)
    }).catch(reject)
  })
}

/**
 * Method for generating div element with style where background is base64 encoded svg
 * @param {Object} icon
 * @param {Number} size
 * @return {Promise} Promise with string div element in 'html' property and string css in 'css' property or
 * one string div element with inserted style in 'preview' property.
 */
export function svgCss (icon, size) {
  return new Promise((resolve, reject) => {
    let content = {
      preview: undefined,
      result: undefined,
      html: undefined,
      css: undefined
    }
    const name = normalizeValue(icon.name)
    svgInline(icon, size).then((result) => {
      content = { ...content, ...result }
      const style = `
display: inline-block;
width: ${size}px;
height: ${size}px;
background: url('data:image/svg+xml;base64,${window.btoa(content.result)}') 50% 50% no-repeat;
background-size: 100%;`

      content.preview = `<div style="${style}"></div>`
      content.html = `<div class="icons8-${name}"></div>`
      content.css = `.icons8-${name} { ${style} }`
      resolve(content)
    }).catch(reject)
  })
}
