import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.symbol.js";
import "core-js/modules/es.array.filter.js";
import "core-js/modules/es.object.get-own-property-descriptor.js";
import "core-js/modules/web.dom-collections.for-each.js";
import "core-js/modules/es.object.get-own-property-descriptors.js";
import _asyncToGenerator from "@babel/runtime/helpers/esm/asyncToGenerator";
import _defineProperty from "@babel/runtime/helpers/esm/defineProperty";
import "regenerator-runtime/runtime.js";
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.array.map.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.string.replace.js";
import Vue from 'vue';
import Vuex from 'vuex';
import Meta from 'vue-meta';
import ClientOnly from 'vue-client-only';
import NoSsr from 'vue-no-ssr';
import { createRouter } from './router.js';
import NuxtChild from './components/nuxt-child.js';
import NuxtError from '../layouts/error.vue';
import Nuxt from './components/nuxt.js';
import App from './App.js';
import { setContext, getLocation, getRouteData, normalizeError } from './utils';
import { createStore } from './store.js';

/* Plugins */

import nuxt_plugin_appplugin_6e4ae16c from 'nuxt_plugin_appplugin_6e4ae16c'; // Source: ../node_modules/@nuxt/bridge/dist/runtime/app.plugin.mjs (mode: 'all')
import nuxt_plugin_configplugin_4417b6a3 from 'nuxt_plugin_configplugin_4417b6a3'; // Source: ../node_modules/@nuxt/bridge/dist/runtime/config.plugin.mjs (mode: 'all')
import nuxt_plugin_nitrobridgeserver_1ab611b4 from 'nuxt_plugin_nitrobridgeserver_1ab611b4'; // Source: ./nitro-bridge.server.mjs (mode: 'server')
import nuxt_plugin_nitrobridgeclient_6d7d5b88 from 'nuxt_plugin_nitrobridgeclient_6d7d5b88'; // Source: ./nitro-bridge.client.mjs (mode: 'client')
import nuxt_plugin_icons_9c1d6dbc from 'nuxt_plugin_icons_9c1d6dbc'; // Source: ./icons.js (mode: 'all')
import nuxt_plugin_googleanalytics_0f318e20 from 'nuxt_plugin_googleanalytics_0f318e20'; // Source: ./google-analytics.js (mode: 'client')
import nuxt_plugin_pluginutils_ea6a7e96 from 'nuxt_plugin_pluginutils_ea6a7e96'; // Source: ./nuxt-i18n/plugin.utils.js (mode: 'all')
import nuxt_plugin_pluginrouting_8dc41680 from 'nuxt_plugin_pluginrouting_8dc41680'; // Source: ./nuxt-i18n/plugin.routing.js (mode: 'all')
import nuxt_plugin_pluginmain_7e05a2a2 from 'nuxt_plugin_pluginmain_7e05a2a2'; // Source: ./nuxt-i18n/plugin.main.js (mode: 'all')
import nuxt_plugin_capiplugin_2b56d48d from 'nuxt_plugin_capiplugin_2b56d48d'; // Source: ./capi.plugin.mjs (mode: 'all')
import nuxt_plugin_errorpluginserver_e4c11288 from 'nuxt_plugin_errorpluginserver_e4c11288'; // Source: ../node_modules/@nuxt/bridge/dist/runtime/error.plugin.server.mjs (mode: 'server')
import nuxt_plugin_components_2c318a2d from 'nuxt_plugin_components_2c318a2d'; // Source: ../plugins/components (mode: 'all')
import nuxt_plugin_hostUrl_200fbef0 from 'nuxt_plugin_hostUrl_200fbef0'; // Source: ../plugins/hostUrl (mode: 'all')
import nuxt_plugin_icons8common_171c0bc3 from 'nuxt_plugin_icons8common_171c0bc3'; // Source: ../plugins/icons8-common (mode: 'all')
import nuxt_plugin_infiniteloading_589c174c from 'nuxt_plugin_infiniteloading_589c174c'; // Source: ../plugins/infinite-loading (mode: 'client')
import nuxt_plugin_scrollTo_484d5a02 from 'nuxt_plugin_scrollTo_484d5a02'; // Source: ../plugins/scrollTo (mode: 'client')
import nuxt_plugin_loadPage_61d1996c from 'nuxt_plugin_loadPage_61d1996c'; // Source: ../plugins/loadPage (mode: 'client')
import nuxt_plugin_nuxtClientInit_6244e316 from 'nuxt_plugin_nuxtClientInit_6244e316'; // Source: ../plugins/nuxtClientInit (mode: 'client')
import nuxt_plugin_vmask_3889a70c from 'nuxt_plugin_vmask_3889a70c'; // Source: ../plugins/v-mask (mode: 'client')
import nuxt_plugin_analytics_731798c4 from 'nuxt_plugin_analytics_731798c4'; // Source: ../node_modules/icons8-common/src/plugins/analytics.js (mode: 'all')
import nuxt_plugin_build_e3868394 from 'nuxt_plugin_build_e3868394'; // Source: ../node_modules/icons8-common/src/plugins/build.js (mode: 'all')
import nuxt_plugin_i18nFormatter_7cbd8ad0 from 'nuxt_plugin_i18nFormatter_7cbd8ad0'; // Source: ../node_modules/icons8-common/src/plugins/i18nFormatter.js (mode: 'all')
import nuxt_plugin_i18n_31b2b80c from 'nuxt_plugin_i18n_31b2b80c'; // Source: ../node_modules/icons8-common/src/plugins/i18n.js (mode: 'all')
import nuxt_plugin_authv2_c7b6e25e from 'nuxt_plugin_authv2_c7b6e25e'; // Source: ../node_modules/icons8-common/src/plugins/auth_v2.js (mode: 'all')
import nuxt_plugin_seoWithHreflang_3d4ebe28 from 'nuxt_plugin_seoWithHreflang_3d4ebe28'; // Source: ../node_modules/icons8-common/src/plugins/seoWithHreflang.js (mode: 'all')
import nuxt_plugin_commonIcons_cc786156 from 'nuxt_plugin_commonIcons_cc786156'; // Source: ../node_modules/icons8-common/src/plugins/commonIcons.js (mode: 'all')
import nuxt_plugin_tapfiliate_13e173bd from 'nuxt_plugin_tapfiliate_13e173bd'; // Source: ../node_modules/icons8-common/src/plugins/tapfiliate.client (mode: 'client')

// Component: <ClientOnly>
Vue.component(ClientOnly.name, ClientOnly);

// TODO: Remove in Nuxt 3: <NoSsr>
Vue.component(NoSsr.name, _objectSpread(_objectSpread({}, NoSsr), {}, {
  render: function render(h, ctx) {
    if (process.client && !NoSsr._warned) {
      NoSsr._warned = true;
      console.warn('<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead');
    }
    return NoSsr.render(h, ctx);
  }
}));

// Component: <NuxtChild>
Vue.component(NuxtChild.name, NuxtChild);
Vue.component('NChild', NuxtChild);

// Component NuxtLink is imported in server.js or client.js

// Component: <Nuxt>
Vue.component(Nuxt.name, Nuxt);
Object.defineProperty(Vue.prototype, '$nuxt', {
  get: function get() {
    var globalNuxt = this.$root ? this.$root.$options.$nuxt : null;
    if (process.client && !globalNuxt && typeof window !== 'undefined') {
      return window.$nuxt;
    }
    return globalNuxt;
  },
  configurable: true
});
Vue.use(Meta, {
  "keyName": "head",
  "attribute": "data-n-head",
  "ssrAttribute": "data-n-head-ssr",
  "tagIDKeyName": "hid"
});
var defaultTransition = {
  "name": "page",
  "mode": "out-in",
  "appear": false,
  "appearClass": "appear",
  "appearActiveClass": "appear-active",
  "appearToClass": "appear-to"
};
var originalRegisterModule = Vuex.Store.prototype.registerModule;
function registerModule(path, rawModule) {
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var preserveState = process.client && (Array.isArray(path) ? !!path.reduce(function (namespacedState, path) {
    return namespacedState && namespacedState[path];
  }, this.state) : path in this.state);
  return originalRegisterModule.call(this, path, rawModule, _objectSpread({
    preserveState: preserveState
  }, options));
}
function createApp(_x) {
  return _createApp.apply(this, arguments);
}
function _createApp() {
  _createApp = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(ssrContext) {
    var config,
      store,
      router,
      app,
      next,
      route,
      path,
      inject,
      _args2 = arguments;
    return regeneratorRuntime.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            inject = function _inject(key, value) {
              if (!key) {
                throw new Error('inject(key, value) has no key provided');
              }
              if (value === undefined) {
                throw new Error("inject('".concat(key, "', value) has no value provided"));
              }
              key = '$' + key;
              // Add into app
              app[key] = value;
              // Add into context
              if (!app.context[key]) {
                app.context[key] = value;
              }

              // Add into store
              store[key] = app[key];

              // Check if plugin not already installed
              var installKey = '__nuxt_' + key + '_installed__';
              if (Vue[installKey]) {
                return;
              }
              Vue[installKey] = true;
              // Call Vue.use() to install the plugin into vm
              Vue.use(function () {
                if (!Object.prototype.hasOwnProperty.call(Vue.prototype, key)) {
                  Object.defineProperty(Vue.prototype, key, {
                    get: function get() {
                      return this.$root.$options[key];
                    }
                  });
                }
              });
            };
            config = _args2.length > 1 && _args2[1] !== undefined ? _args2[1] : {};
            store = createStore(ssrContext);
            _context2.next = 5;
            return createRouter(ssrContext, config, {
              store: store
            });
          case 5:
            router = _context2.sent;
            // Add this.$router into store actions/mutations
            store.$router = router;

            // Fix SSR caveat https://github.com/nuxt/nuxt.js/issues/3757#issuecomment-414689141
            store.registerModule = registerModule;

            // Create Root instance

            // here we inject the router and store to all child components,
            // making them available everywhere as `this.$router` and `this.$store`.
            app = _objectSpread({
              head: {
                "title": "Download free icons, music, stock photos, vectors",
                "meta": [{
                  "charset": "utf-8"
                }, {
                  "name": "viewport",
                  "content": "width=device-width, initial-scale=1"
                }, {
                  "name": "format-detection",
                  "content": "telephone=no"
                }, {
                  "name": "robots",
                  "hid": "robots",
                  "content": "noodp"
                }, {
                  "http-equiv": "X-UA-Compatible",
                  "content": "IE=edge, chrome=1"
                }, {
                  "name": "description",
                  "hid": "description",
                  "content": "Designers, download the design stuff for free — icons, photos, UX illustrations, and music for your videos."
                }],
                "script": [{
                  "src": "https://www.googleoptimize.com/optimize.js?id=OPT-PJMHSJC"
                }],
                "link": [{
                  "rel": "icon",
                  "type": "image/png",
                  "size": 32,
                  "hid": "favicon-32",
                  "href": "https://maxst.icons8.com/vue-static/icon/favicon/icons8_fav_32\xD732.png"
                }],
                "style": []
              },
              store: store,
              router: router,
              nuxt: {
                defaultTransition: defaultTransition,
                transitions: [defaultTransition],
                setTransitions: function setTransitions(transitions) {
                  if (!Array.isArray(transitions)) {
                    transitions = [transitions];
                  }
                  transitions = transitions.map(function (transition) {
                    if (!transition) {
                      transition = defaultTransition;
                    } else if (typeof transition === 'string') {
                      transition = Object.assign({}, defaultTransition, {
                        name: transition
                      });
                    } else {
                      transition = Object.assign({}, defaultTransition, transition);
                    }
                    return transition;
                  });
                  this.$options.nuxt.transitions = transitions;
                  return transitions;
                },
                err: null,
                dateErr: null,
                error: function error(err) {
                  err = err || null;
                  app.context._errored = Boolean(err);
                  err = err ? normalizeError(err) : null;
                  var nuxt = app.nuxt; // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207
                  if (this) {
                    nuxt = this.nuxt || this.$options.nuxt;
                  }
                  nuxt.dateErr = Date.now();
                  nuxt.err = err;
                  // Used in src/server.js
                  if (ssrContext) {
                    ssrContext.nuxt.error = err;
                  }
                  return err;
                }
              }
            }, App); // Make app available into store via this.app
            store.app = app;
            next = ssrContext ? ssrContext.next : function (location) {
              return app.router.push(location);
            }; // Resolve route
            if (ssrContext) {
              route = router.resolve(ssrContext.url).route;
            } else {
              path = getLocation(router.options.base, router.options.mode);
              route = router.resolve(path).route;
            }

            // Set context to app.context
            _context2.next = 14;
            return setContext(app, {
              store: store,
              route: route,
              next: next,
              error: app.nuxt.error.bind(app),
              payload: ssrContext ? ssrContext.payload : undefined,
              req: ssrContext ? ssrContext.req : undefined,
              res: ssrContext ? ssrContext.res : undefined,
              beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
              beforeSerializeFns: ssrContext ? ssrContext.beforeSerializeFns : undefined,
              ssrContext: ssrContext
            });
          case 14:
            // Inject runtime config as $config
            inject('config', config);
            if (process.client) {
              // Replace store state before plugins execution
              if (window.__NUXT__ && window.__NUXT__.state) {
                store.replaceState(window.__NUXT__.state);
              }
            }

            // Add enablePreview(previewData = {}) in context for plugins
            if (process.static && process.client) {
              app.context.enablePreview = function () {
                var previewData = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                app.previewData = Object.assign({}, previewData);
                inject('preview', previewData);
              };
            }
            // Plugin execution
            if (!(typeof nuxt_plugin_appplugin_6e4ae16c === 'function')) {
              _context2.next = 20;
              break;
            }
            _context2.next = 20;
            return nuxt_plugin_appplugin_6e4ae16c(app.context, inject);
          case 20:
            if (!(typeof nuxt_plugin_configplugin_4417b6a3 === 'function')) {
              _context2.next = 23;
              break;
            }
            _context2.next = 23;
            return nuxt_plugin_configplugin_4417b6a3(app.context, inject);
          case 23:
            if (!(process.server && typeof nuxt_plugin_nitrobridgeserver_1ab611b4 === 'function')) {
              _context2.next = 26;
              break;
            }
            _context2.next = 26;
            return nuxt_plugin_nitrobridgeserver_1ab611b4(app.context, inject);
          case 26:
            if (!(process.client && typeof nuxt_plugin_nitrobridgeclient_6d7d5b88 === 'function')) {
              _context2.next = 29;
              break;
            }
            _context2.next = 29;
            return nuxt_plugin_nitrobridgeclient_6d7d5b88(app.context, inject);
          case 29:
            if (!(typeof nuxt_plugin_icons_9c1d6dbc === 'function')) {
              _context2.next = 32;
              break;
            }
            _context2.next = 32;
            return nuxt_plugin_icons_9c1d6dbc(app.context, inject);
          case 32:
            if (!(process.client && typeof nuxt_plugin_googleanalytics_0f318e20 === 'function')) {
              _context2.next = 35;
              break;
            }
            _context2.next = 35;
            return nuxt_plugin_googleanalytics_0f318e20(app.context, inject);
          case 35:
            if (!(typeof nuxt_plugin_pluginutils_ea6a7e96 === 'function')) {
              _context2.next = 38;
              break;
            }
            _context2.next = 38;
            return nuxt_plugin_pluginutils_ea6a7e96(app.context, inject);
          case 38:
            if (!(typeof nuxt_plugin_pluginrouting_8dc41680 === 'function')) {
              _context2.next = 41;
              break;
            }
            _context2.next = 41;
            return nuxt_plugin_pluginrouting_8dc41680(app.context, inject);
          case 41:
            if (!(typeof nuxt_plugin_pluginmain_7e05a2a2 === 'function')) {
              _context2.next = 44;
              break;
            }
            _context2.next = 44;
            return nuxt_plugin_pluginmain_7e05a2a2(app.context, inject);
          case 44:
            if (!(typeof nuxt_plugin_capiplugin_2b56d48d === 'function')) {
              _context2.next = 47;
              break;
            }
            _context2.next = 47;
            return nuxt_plugin_capiplugin_2b56d48d(app.context, inject);
          case 47:
            if (!(process.server && typeof nuxt_plugin_errorpluginserver_e4c11288 === 'function')) {
              _context2.next = 50;
              break;
            }
            _context2.next = 50;
            return nuxt_plugin_errorpluginserver_e4c11288(app.context, inject);
          case 50:
            if (!(typeof nuxt_plugin_components_2c318a2d === 'function')) {
              _context2.next = 53;
              break;
            }
            _context2.next = 53;
            return nuxt_plugin_components_2c318a2d(app.context, inject);
          case 53:
            if (!(typeof nuxt_plugin_hostUrl_200fbef0 === 'function')) {
              _context2.next = 56;
              break;
            }
            _context2.next = 56;
            return nuxt_plugin_hostUrl_200fbef0(app.context, inject);
          case 56:
            if (!(typeof nuxt_plugin_icons8common_171c0bc3 === 'function')) {
              _context2.next = 59;
              break;
            }
            _context2.next = 59;
            return nuxt_plugin_icons8common_171c0bc3(app.context, inject);
          case 59:
            if (!(process.client && typeof nuxt_plugin_infiniteloading_589c174c === 'function')) {
              _context2.next = 62;
              break;
            }
            _context2.next = 62;
            return nuxt_plugin_infiniteloading_589c174c(app.context, inject);
          case 62:
            if (!(process.client && typeof nuxt_plugin_scrollTo_484d5a02 === 'function')) {
              _context2.next = 65;
              break;
            }
            _context2.next = 65;
            return nuxt_plugin_scrollTo_484d5a02(app.context, inject);
          case 65:
            if (!(process.client && typeof nuxt_plugin_loadPage_61d1996c === 'function')) {
              _context2.next = 68;
              break;
            }
            _context2.next = 68;
            return nuxt_plugin_loadPage_61d1996c(app.context, inject);
          case 68:
            if (!(process.client && typeof nuxt_plugin_nuxtClientInit_6244e316 === 'function')) {
              _context2.next = 71;
              break;
            }
            _context2.next = 71;
            return nuxt_plugin_nuxtClientInit_6244e316(app.context, inject);
          case 71:
            if (!(process.client && typeof nuxt_plugin_vmask_3889a70c === 'function')) {
              _context2.next = 74;
              break;
            }
            _context2.next = 74;
            return nuxt_plugin_vmask_3889a70c(app.context, inject);
          case 74:
            if (!(typeof nuxt_plugin_analytics_731798c4 === 'function')) {
              _context2.next = 77;
              break;
            }
            _context2.next = 77;
            return nuxt_plugin_analytics_731798c4(app.context, inject);
          case 77:
            if (!(typeof nuxt_plugin_build_e3868394 === 'function')) {
              _context2.next = 80;
              break;
            }
            _context2.next = 80;
            return nuxt_plugin_build_e3868394(app.context, inject);
          case 80:
            if (!(typeof nuxt_plugin_i18nFormatter_7cbd8ad0 === 'function')) {
              _context2.next = 83;
              break;
            }
            _context2.next = 83;
            return nuxt_plugin_i18nFormatter_7cbd8ad0(app.context, inject);
          case 83:
            if (!(typeof nuxt_plugin_i18n_31b2b80c === 'function')) {
              _context2.next = 86;
              break;
            }
            _context2.next = 86;
            return nuxt_plugin_i18n_31b2b80c(app.context, inject);
          case 86:
            if (!(typeof nuxt_plugin_authv2_c7b6e25e === 'function')) {
              _context2.next = 89;
              break;
            }
            _context2.next = 89;
            return nuxt_plugin_authv2_c7b6e25e(app.context, inject);
          case 89:
            if (!(typeof nuxt_plugin_seoWithHreflang_3d4ebe28 === 'function')) {
              _context2.next = 92;
              break;
            }
            _context2.next = 92;
            return nuxt_plugin_seoWithHreflang_3d4ebe28(app.context, inject);
          case 92:
            if (!(typeof nuxt_plugin_commonIcons_cc786156 === 'function')) {
              _context2.next = 95;
              break;
            }
            _context2.next = 95;
            return nuxt_plugin_commonIcons_cc786156(app.context, inject);
          case 95:
            if (!(process.client && typeof nuxt_plugin_tapfiliate_13e173bd === 'function')) {
              _context2.next = 98;
              break;
            }
            _context2.next = 98;
            return nuxt_plugin_tapfiliate_13e173bd(app.context, inject);
          case 98:
            // Lock enablePreview in context
            if (process.static && process.client) {
              app.context.enablePreview = function () {
                console.warn('You cannot call enablePreview() outside a plugin.');
              };
            }

            // Wait for async component to be resolved first
            _context2.next = 101;
            return new Promise(function (resolve, reject) {
              // Ignore 404s rather than blindly replacing URL in browser
              if (process.client) {
                var _router$resolve = router.resolve(app.context.route.fullPath),
                  _route = _router$resolve.route;
                if (!_route.matched.length) {
                  return resolve();
                }
              }
              router.replace(app.context.route.fullPath, resolve, function (err) {
                // https://github.com/vuejs/vue-router/blob/v3.4.3/src/util/errors.js
                if (!err._isRouter) return reject(err);
                if (err.type !== 2 /* NavigationFailureType.redirected */) return resolve();

                // navigated to a different route in router guard
                var unregister = router.afterEach( /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(to, from) {
                    return regeneratorRuntime.wrap(function _callee$(_context) {
                      while (1) {
                        switch (_context.prev = _context.next) {
                          case 0:
                            if (process.server && ssrContext && ssrContext.url) {
                              ssrContext.url = to.fullPath;
                            }
                            _context.next = 3;
                            return getRouteData(to);
                          case 3:
                            app.context.route = _context.sent;
                            app.context.params = to.params || {};
                            app.context.query = to.query || {};
                            unregister();
                            resolve();
                          case 8:
                          case "end":
                            return _context.stop();
                        }
                      }
                    }, _callee);
                  }));
                  return function (_x2, _x3) {
                    return _ref.apply(this, arguments);
                  };
                }());
              });
            });
          case 101:
            return _context2.abrupt("return", {
              store: store,
              app: app,
              router: router
            });
          case 102:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _createApp.apply(this, arguments);
}
export { createApp, NuxtError };