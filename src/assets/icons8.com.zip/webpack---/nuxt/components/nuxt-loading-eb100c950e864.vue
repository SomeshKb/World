var render, staticRenderFns
import script from "./nuxt-loading.vue?vue&type=script&lang=js&"
export * from "./nuxt-loading.vue?vue&type=script&lang=js&"
import style0 from "./nuxt-loading.vue?vue&type=style&index=0&id=6fdb1a70&prod&lang=css&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports