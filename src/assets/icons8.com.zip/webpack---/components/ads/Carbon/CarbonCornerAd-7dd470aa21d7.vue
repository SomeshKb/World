// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only{display:none!important}}@media(max-width:1023px){.desktop-only{display:none!important}}.carbon-corner-ads #carbonads{font-size:12px;color:#fff;text-align:left;background:linear-gradient(-30deg,rgba(45,182,124,.85),rgba(45,182,124,.85) 45%,#2db67c 65%) #fff;max-width:200px;display:flex;z-index:10;border-radius:8px;border:1px solid #f2f2f2;padding:18px 20px;text-decoration:none;flex-direction:column;justify-content:flex-start;align-items:center}.carbon-corner-ads #carbonads__close{position:absolute;z-index:12;width:14px;height:26px;top:6px;right:10px;cursor:pointer}.carbon-corner-ads #carbonads__close svg{fill:#fff}.carbon-corner-ads #carbonads__close.is-black svg{fill:#000}.carbon-corner-ads #carbonads .carbon-poweredby{display:block;color:#fff;letter-spacing:1px;font-weight:500;font-size:8px;line-height:18px;margin-top:5px;text-transform:uppercase}.carbon-corner-ads #carbonads .carbon-img{text-decoration:none;border:none;display:flex;justify-content:center;margin-bottom:10px}.carbon-corner-ads #carbonads img{max-height:100px}.carbon-corner-ads #carbonads .carbon-text{color:#fff;text-decoration:none;border:none;letter-spacing:1px;font-weight:400;font-size:12px;line-height:18px;margin:10px 0}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
