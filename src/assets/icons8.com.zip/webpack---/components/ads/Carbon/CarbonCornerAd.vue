<template>
  <div class="app-ads carbon-corner-ads">
    <div class="container" />
    <div
      v-if="isEnabled"
      class="carbon-corner-ads__close"
      @click.prevent="closeAd"
      v-html="$icons.cancel"
    />
    <transition name="fade">
      <div
        v-if="adClosed"
        class="after-ad"
      >
        <div class="native-main">
          <span class="after-ad-title">Remove ads</span>
        </div>
        <a
          class="upgrade"
          href="https://icons8.com/pricing"
        >
          Upgrade
        </a>
      </div>
    </transition>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'

export default {
  name: 'CarbonCornerAd',
  props: {
    landingAds: {
      type: Boolean,
      default: false
    },
    showForMobile: {
      type: Boolean,
      default: true
    }
  },
  data () {
    return {
      isMobile: false,
      container: undefined,
      isEnabled: false,
      adClosed: false
    }
  },
  computed: {
    ...mapState({
      user: state => state.auth.user
    })
  },
  watch: {
    '$route' () {
      this.startShowAds()
    },
    'user.loaded' () {
      this.startShowAds()
    },
    'user.activeLicense' (value) {
      if (value) this.cleanAds()
      else this.startShowAds()
    }
  },
  mounted () {
    if (
      window &&
      window.outerWidth &&
      window.outerWidth < 680) {
      this.isMobile = true
    }
    this.container = this.$el.querySelector('.container')
    this.startShowAds()
  },
  methods: {
    ...mapActions({
      showCornerAd: 'showCornerAd',
      hideCornerAd: 'hideCornerAd'
    }),
    loadAds (callback = () => {
    }) {
      this.container.style.display = 'block'
      this.cleanAds()
      if (this.lang === 'zh-cN') return
      this.isEnabled = true

      const ads = document.createElement('script')
      ads.setAttribute('src', '//cdn.carbonads.com/carbon.js?serve=CKYIV27I&placement=icons8com')
      ads.async = true
      ads.setAttribute('type', 'text/javascript')
      ads.setAttribute('id', '_carbonads_js')
      ads.addEventListener('load', callback)
      this.container.appendChild(ads)
    },
    cleanAds () {
      while (this.container && this.container.firstChild) {
        this.container.removeChild(this.container.firstChild)
      }
      this.hideCornerAd()
    },
    closeAd () {
      this.isEnabled = false
      this.adClosed = true
      this.container.style.display = 'none'
    },
    disableAds () {
      this.isEnabled = false
      this.hideCornerAd()
    },
    startShowAds () {
      const isFreeUser = this.user.loaded && !this.user.activeLicense
      const isBannerWidget = (window && window.bannerWidget && window.bannerWidget.isActive())
      const isAllowedMobile = this.isMobile ? (this.showForMobile && !isBannerWidget) : true

      const isCarbonCardPresent = document.querySelector('.carbon-card-ad')
      const isCarbonVerticalPresent = document.querySelector('.carbon-vertical-ad')
      const isCarbonHorizontalPresent = document.querySelector('.carbon-horizontal-ad')
      const areOtherCarbonsPresent = isCarbonCardPresent || isCarbonVerticalPresent || isCarbonHorizontalPresent

      if (isFreeUser && isAllowedMobile && !areOtherCarbonsPresent) {
        this.loadAds(this.callbackScript)
      } else {
        this.disableAds()
      }
    },
    checkAds () {
      return this.container.querySelector('#carbonads')
    },
    callbackScript () {
      const callBackFunc = window._carbonads_go
      if (typeof callBackFunc === 'function') {
        window._carbonads_go = (...args) => {
          if (!this.checkAds()) callBackFunc.apply(window, args)

          if (this.checkAds()) {
            this.$emit('approveAds')
            this.showCornerAd()
          } else this.$emit('rejectAds')
        }
      } else {
        setTimeout(() => {
          // standard behavior
          if (this.checkAds()) {
            this.$emit('approveAds')
            this.showCornerAd()
          } else this.$emit('rejectAds')
        }, 300)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.app-ads {
  max-width: 280px;

  &:after {
    content: "";
    display: table;
    clear: both;
  }
}

.after-ad {
  position: absolute;
  font-size: 15px;
  display: flex;
  width: 200px;
  height: 60px;
  bottom: 0;
  z-index: 5;
  padding: 0 16px;
  right: 0;
  border-radius: 8px;
  justify-content: space-between;
  align-items: center;
  background: #363250;

  .native-main {
    color: rgba(255, 255, 255, 0.7);
    font-weight: 400;
  }

  .upgrade {
    background-color: #FED9A3;
    border-radius: 8px;
    padding: 5px 8px;
    font-size: 14px;
    color: rgba(0, 0, 0, 0.7);
    font-weight: 400;
  }

  @media (max-width: 767px) {
    display: none;
  }
}
</style>

<style lang="scss">
.carbon-corner-ads #carbonads {
  font-size: 12px;
  color: #fff;
  text-align: left;
  background: linear-gradient(-30deg, rgba(45, 182, 124, 0.85), rgba(45, 182, 124, 0.85) 45%, rgb(45, 182, 124) 65%) rgb(255, 255, 255);
  max-width: 200px;
  display: flex;
  z-index: 10;
  border-radius: 8px;
  border: solid 1px #f2f2f2;
  padding: 18px 20px;
  text-decoration: none;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;

  &__close {
    position: absolute;
    z-index: 12;
    width: 14px;
    height: 26px;
    top: 6px;
    right: 10px;
    cursor: pointer;

    svg {
      fill: white;
    }

    &.is-black {
      svg {
        fill: black;
      }
    }
  }

  .carbon-poweredby {
    display: block;
    color: #fff;
    letter-spacing: 1px;
    font-weight: 500;
    font-size: 8px;
    line-height: 18px;
    margin-top: 5px;
    text-transform: uppercase;
  }

  .carbon-img {
    text-decoration: none;
    border: none;
    display: flex;
    justify-content: center;
    margin-bottom: 10px;
  }

  img {
    max-height: 100px;
  }

  .carbon-text {
    color: #fff;
    text-decoration: none;
    border: none;
    letter-spacing: 1px;
    font-weight: 400;
    font-size: 12px;
    line-height: 18px;
    margin: 10px 0;
  }
}
</style>
