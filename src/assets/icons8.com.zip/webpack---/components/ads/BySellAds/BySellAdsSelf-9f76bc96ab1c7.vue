<template>
  <a
    class="by-sell-ads-self"
    :href="ad.statlink"
    target="blank"
  ><img
    class="ad-image"
    :src="ad.image"
  ><span class="ad-ad">Ad</span></a>
</template>

<script>
export default {
  name: 'BySellAdsSelf',
  props: {
    ad: {
      type: Object,
      required: true
    }
  }
}
</script>

<style scoped>
.by-sell-ads-self {
  display: flex;
  position: relative;
  border: 1px solid rgba(51, 51, 51, 0.1);
  box-sizing: border-box;
  border-radius: 8px;
  max-width: 730px;
  overflow: hidden;
}

.ad-image {
  max-width: 100%;
  height: auto;
  line-height: 0;
}

.ad-ad {
  position: absolute;
  top: 6px;
  right: 6px;
  font-weight: 600;
  font-size: 10px;
  line-height: 10px;
  display: flex;
  align-items: center;
  color: #1A1A1A;
  opacity: 0.4;
  text-transform: uppercase;
}
</style>
