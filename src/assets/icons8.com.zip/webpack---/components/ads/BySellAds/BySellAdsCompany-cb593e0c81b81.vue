<template>
  <a
    class="by-sell-ads-large"
    :href="ad.statlink"
    target="blank"
  >
    <div
      class="ad-image-container"
      :style="imageContainerStyles"
    ><img
      class="ad-image"
      :src="ad.image"
    ></div>
    <div class="ad-content">
      <p class="ad-text-title">{{ ad.company }}</p>
      <p class="ad-text-description">{{ ad.description }}</p>
    </div><span class="ad-ad">Ad</span>
  </a>
</template>

<script>
export default {
  name: 'BySellAdsCompany',
  props: {
    ad: {
      type: Object,
      required: true
    }
  },
  computed: {
    imageContainerStyles () {
      return {
        backgroundColor: this.ad.backgroundColor
      }
    }
  }
}
</script>

<style scoped>
.by-sell-ads-large {
  position: relative;
  background: #F7F7F7;
  box-sizing: border-box;
  border-radius: 8px;
  min-height: 72px;
  max-width: 720px;
  padding: 16px;
  display: flex;
}

.ad-image-container {
  border-radius: 20px;
  box-sizing: border-box;
  padding: 10px;
  max-width: 40px;
  max-height: 40px;
}

.ad-image {
  max-width: 20px;
  height: auto;
}

.ad-content {
  margin-left: 16px;
  color: #1A1A1A;
}
.ad-content > * {
  margin: 0;
  padding: 0;
  display: block;
}
.ad-text-title {
  font-weight: 700;
  font-size: 14px;
  line-height: 24px;
}
.ad-text-description {
  font-size: 14px;
  line-height: 20px;
}

.ad-ad {
  position: absolute;
  top: 12px;
  right: 6px;
  font-weight: 600;
  font-size: 10px;
  line-height: 10px;
  display: flex;
  align-items: center;
  color: #1A1A1A;
  opacity: 0.4;
  text-transform: uppercase;
}
</style>
