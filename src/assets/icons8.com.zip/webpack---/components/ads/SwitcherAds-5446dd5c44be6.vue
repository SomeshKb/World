import { render, staticRenderFns } from "./SwitcherAds.vue?vue&type=template&id=18d5999e&scoped=true&"
import script from "./SwitcherAds.vue?vue&type=script&lang=js&"
export * from "./SwitcherAds.vue?vue&type=script&lang=js&"
import style0 from "./SwitcherAds.vue?vue&type=style&index=0&id=18d5999e&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "18d5999e",
  null
  
)

export default component.exports