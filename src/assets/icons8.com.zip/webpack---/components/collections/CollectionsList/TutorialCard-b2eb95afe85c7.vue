<template>
  <div
    v-if="type === 'createCollections'"
    class="tutorial-card"
  >
    <I8Icon
      class="tutorial-card__icon tutorial-card__icon_plus"
      family="simpleSmall"
      icon="plus"
    />
    {{ $t('ICON.COMPONENTS.COLLECTIONS.TUTORIAL.CREATE_COLLECTIONS') }}
  </div>

  <div
    v-else-if="type === 'createFont'"
    class="tutorial-card"
  >
    <div v-html="$icons.textUpperLower" class="tutorial-card__icon"/>
    {{ $t('ICON.COMPONENTS.COLLECTIONS.TUTORIAL.CREATE_ICON_FONT') }}
  </div>

  <div
    v-else-if="type === 'uploadAndStore'"
    class="tutorial-card"
  >
    <div v-html="$icons.folderOutlined" class="tutorial-card__icon"/>
    {{ $t('ICON.COMPONENTS.COLLECTIONS.TUTORIAL.UPLOAD_AND_STORE') }}
  </div>
</template>

<script>
import { I8Icon } from '@icons8/vue-kit'

export default {
  name: "TutorialCards",
  components: {
    I8Icon
  },
  props: {
    type: {
      type: String,
      default: 'createCollections',
      validator: (val) => ['createCollections', 'createFont', 'uploadAndStore'].includes(val)
    }
  }
}
</script>

<style scoped lang="scss">
.tutorial-card {
  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-items: center;
  padding: 16px;
  gap: 8px;

  --collection-card-min-height: 88px;
  min-height: var(--collection-card-min-height);

  --collection-card-border-radius: 8px;
  border: 1px solid var(--c-transparent-black_200);
  border-radius: var(--collection-card-border-radius);

  text-align: center;
  font-style: normal;
  font-weight: 400;
  font-size: 12px;
  line-height: 16px;
  color: var(--c-transparent-black_500);

  &__icon {
    width: 16px;
    height: 16px;
    &_plus {
      opacity: 0.4;
    }
  }
}
</style>
