import { render, staticRenderFns } from "./CollectionsList.vue?vue&type=template&id=2b5740f0&scoped=true&"
import script from "./CollectionsList.vue?vue&type=script&lang=js&"
export * from "./CollectionsList.vue?vue&type=script&lang=js&"
import style0 from "./CollectionsList.vue?vue&type=style&index=0&id=2b5740f0&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "2b5740f0",
  null
  
)

export default component.exports