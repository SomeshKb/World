import { render, staticRenderFns } from "./CollectionCardContainer.vue?vue&type=template&id=2b365e26&scoped=true&"
import script from "./CollectionCardContainer.vue?vue&type=script&lang=js&"
export * from "./CollectionCardContainer.vue?vue&type=script&lang=js&"
import style0 from "./CollectionCardContainer.vue?vue&type=style&index=0&id=2b365e26&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "2b365e26",
  null
  
)

export default component.exports