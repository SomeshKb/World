<template>
  <Portal>
    <transition name="undo-toast__transition">
      <div
        v-if="shownKey"
        class="undo-toast"
      >
        <div class="undo-toast__content">
          <I8Icon
            class="undo-toast__icon"
            family="materialOutline"
            icon="info"
          />
          <div class="undo-toast__text">
            <slot>
              {{ 'undo toast text' }}
            </slot>
          </div>
          <I8Button
            type="text"
            class="undo-toast__btn"
            @click="undo"
          >
            {{ $t('ICON.COMPONENTS.COLLECTIONS.PAGE.TOASTS.UNDO') }}
          </I8Button>
          <div class="undo-toast__progress-bar">
            <div
              ref="progressBarLine"
              class="undo-toast__progress-bar-line"
            />
          </div>
        </div>
      </div>
    </transition>
  </Portal>
</template>

<script>
import { I8Button, I8Icon } from '@icons8/vue-kit'
import { Portal } from '@linusborg/vue-simple-portal'

export default {
  name: 'UndoToast',
  components: {
    Portal,
    I8Button,
    I8Icon
  },
  props: {
    shownKey: {
      required: true
    },
    duration: {
      // in ms
      type: Number,
      default: 7000
    }
  },
  data: () => ({
    timerId: undefined,
    percentTime: 100
  }),
  watch: {
    shownKey: {
      immediate: true,
      handler (newValue, oldValue) {
        if (newValue && !oldValue) {
          this.stopProgressBar()
          this.startProgressBar()
        } else if (!newValue && oldValue) {
          this.stopProgressBar()
        }
      }
    }
  },
  beforeDestroy () {
    if (this.timerId) {
      clearInterval(this.timerId)
    }
  },
  methods: {
    undo () {
      this.stopProgressBar()
      this.$emit('undo')
    },
    startProgressBar () {
      const interval = this.duration / 100

      this.timerId = setInterval(() => {
        this.setProgress()
      }, interval)
    },
    stopProgressBar () {
      if (this.timerId) {
        clearInterval(this.timerId)
        this.timerId = undefined
      }
      this.percentTime = 100
    },
    setProgress () {
      if (this.percentTime <= 0) {
        this.stopProgressBar()
        this.$emit('confirmed')
      } else {
        this.updateProgressBar()
        this.percentTime -= 1
      }
    },
    updateProgressBar () {
      if (this.$refs.progressBarLine) {
        this.$refs.progressBarLine.style.width = `${this.percentTime}%`
      } else {
        console.warn('Could not find progress bar element of Undo toast')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.undo-toast {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;

  display: flex;
  justify-content: center;
  align-items: center;

  z-index: 1500;

  @media (max-width: 768px) {
    left: 20px;
    right: 98px;  // crisp right (20px) + crisp width (60px) + gap (18px)
  }

  &__content {
    position: relative;

    display: flex;
    align-items: center;
    margin-bottom: 20px;

    border-radius: 4px;
    background: var(--c-yellow_300);
  }

  &__icon {
    margin: 16px;

    @media (max-width: 768px) {
      margin: 12px 8px 12px 12px;
    }

    width: 24px;
    height: 24px;
  }

  &__text {
    margin: 18px 0;

    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    letter-spacing: -0.006em;
    color: var(--c-black_900);

    @media (max-width: 768px) {
      margin: 16px 0;

      font-size: 12px;
      line-height: 16px;
    }
  }

  &__btn {
    display: flex;
    flex-flow: column nowrap;
    justify-content: center;

    --button-padding-small: 18px 16px;
    --button-height-small: 100%;

    --button-background-color-hover: transparent;
    --button-background-color-active: transparent;
    --button-color: var(--c-transparent-black_500);

    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    letter-spacing: -0.006em;

    @media (max-width: 768px) {
      --button-padding-small: 16px 12px 16px 8px;
      font-size: 12px;
      line-height: 16px;
    }

    &:hover {
      --button-color: var(--c-transparent-black_700);
    }
    &:active {
      --button-color: var(--c-transparent-black_900);
    }
  }

  &__progress-bar {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;

    height: 2px;

    border-radius: 0 0 4px 4px;
    overflow-x: hidden;

    &-line {
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      width: 100%;

      background: var(--c-transparent-black_400);
      transition: width 300ms ease;
    }
  }

  &__transition {
    &-enter-active, &-leave-active {
      transition: transform 300ms ease-out;
    }

    &-enter, &-leave-to {
      transform: translateY(200px);
    }
  }
}
</style>
