// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-34ac2a68]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-34ac2a68]{display:none!important}}.collection-sidebar-container[data-v-34ac2a68]{z-index:11;position:absolute;top:0;bottom:0;left:224px;right:0;width:calc(100vw - 224px);background-color:#fff}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
