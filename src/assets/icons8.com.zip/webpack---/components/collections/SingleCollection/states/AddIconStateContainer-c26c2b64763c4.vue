// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-fccb505a]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-fccb505a]{display:none!important}}.upload-state[data-v-fccb505a]{--main-color:var(--c-red_500);flex-direction:column;justify-content:flex-end}.icon-container[data-v-fccb505a],.upload-state[data-v-fccb505a]{display:flex;align-items:center}.icon-container[data-v-fccb505a]{--icon-color:var(--c-white);--size:24px;width:var(--size);height:var(--size);border-radius:50%;margin-bottom:4px;justify-content:center;background-color:var(--main-color)}span[data-v-fccb505a]{color:var(--main-color);font:var(--upload-error-text,var(--upload-error-text-weight,var(--font-normal)) var(--upload-error-text-size,var(--font-sm))/var(--upload-error-text-line-height,20px) var(--upload-error-text-family,var(--font-family-legacy)))}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
