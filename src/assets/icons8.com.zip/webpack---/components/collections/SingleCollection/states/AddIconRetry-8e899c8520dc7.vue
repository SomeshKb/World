<template>
  <UploadStateContainer
    :icon="icon"
    color="var(--c-green_500)"
  >
    {{ isMessage ? '' : 'Retry' }}
  </UploadStateContainer>
</template>

<script>
import UploadStateContainer from './AddIconStateContainer'

export default {
  name: 'AddIconRetry',
  components: { UploadStateContainer },
  props: {
    isMessage: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data () {
    return {
      icon: 'M8 2C4.69187 2 2 4.69187 2 8C2 11.3081 4.69187 14 8 14C11.3081 14 14 11.3081 14 8H13C13 10.7679 10.7679 13 8 13C5.23213 13 3 10.7679 3 8C3 5.23213 5.23213 3 8 3C9.51111 3 10.8538 3.675 11.7695 4.73047L10.5 6H14V2.5L12.4766 4.02344C11.3769 2.78698 9.78113 2 8 2Z'
    }
  }
}
</script>
