<template>
  <UploadStateContainer
    :icon="'close'"
    color="var(--c-red_500)"
  >
    {{ isMessage ? '' : 'Error' }}
  </UploadStateContainer>
</template>

<script>
import UploadStateContainer from './AddIconStateContainer'

export default {
  name: "AddIconError",
  components: { UploadStateContainer },
  props: {
    isMessage: {
      type: Boolean,
      required: false,
      default: false
    }
  }
}
</script>
