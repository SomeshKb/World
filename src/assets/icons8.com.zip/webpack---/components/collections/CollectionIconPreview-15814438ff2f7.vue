import { render, staticRenderFns } from "./CollectionIconPreview.vue?vue&type=template&id=7f60a60e&scoped=true&"
import script from "./CollectionIconPreview.vue?vue&type=script&lang=js&"
export * from "./CollectionIconPreview.vue?vue&type=script&lang=js&"
import style0 from "./CollectionIconPreview.vue?vue&type=style&index=0&id=7f60a60e&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "7f60a60e",
  null
  
)

export default component.exports