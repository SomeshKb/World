import { render, staticRenderFns } from "./CollectionDNDWrapper.vue?vue&type=template&id=6d0f1119&scoped=true&"
import script from "./CollectionDNDWrapper.vue?vue&type=script&lang=js&"
export * from "./CollectionDNDWrapper.vue?vue&type=script&lang=js&"
import style0 from "./CollectionDNDWrapper.vue?vue&type=style&index=0&id=6d0f1119&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "6d0f1119",
  null
  
)

export default component.exports