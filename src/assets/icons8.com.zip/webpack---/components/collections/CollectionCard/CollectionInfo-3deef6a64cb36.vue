import { render, staticRenderFns } from "./CollectionInfo.vue?vue&type=template&id=c6f78fcc&scoped=true&"
import script from "./CollectionInfo.vue?vue&type=script&lang=js&"
export * from "./CollectionInfo.vue?vue&type=script&lang=js&"
import style0 from "./CollectionInfo.vue?vue&type=style&index=0&id=c6f78fcc&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "c6f78fcc",
  null
  
)

export default component.exports