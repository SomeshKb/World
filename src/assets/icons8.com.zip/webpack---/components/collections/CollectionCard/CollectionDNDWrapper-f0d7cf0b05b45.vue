// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = require("!!../../../node_modules/css-loader/dist/cjs.js??ref--9-oneOf-1-1!../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../node_modules/postcss-loader/dist/cjs.js??ref--9-oneOf-1-2!../../../node_modules/sass-loader/dist/cjs.js??ref--9-oneOf-1-3!../../../node_modules/sass-resources-loader/lib/loader.js??ref--9-oneOf-1-4!../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./CollectionDNDWrapper.vue?vue&type=style&index=0&id=6d0f1119&prod&lang=scss&scoped=true&");
if(content.__esModule) content = content.default;
if(typeof content === 'string') content = [[module.id, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var add = require("!../../../node_modules/vue-style-loader/lib/addStylesClient.js").default
var update = add("c44c1e24", content, true, {"sourceMap":false});