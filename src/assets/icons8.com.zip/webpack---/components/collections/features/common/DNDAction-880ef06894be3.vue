<template>
  <div
    class="dnd-action"
    v-on="$listeners"
  >
    <div
      class="icon-container"
      v-html="$icons.upload"
    />
    <span>
      <slot>Action</slot>
    </span>
  </div>
</template>

<script>
export default {
  name: 'DNDAction'
}
</script>

<style lang="scss" scoped>
.dnd-action {
  width: 100%;
  height: 100%;

  display: flex;
  flex-flow: column nowrap;
  justify-content: center;
  align-items: center;
  gap: 6px;

  border: 1px dashed var(--c-transparent-black_800);
  border-radius: 4px;
  background: #F6F9F7;
}

.icon-container {
  --size: 24px;
  width: var(--size);
  height: var(--size);

  display: flex;
  justify-content: center;
  align-items: center;
}

span {
  color: var(--c-black_800);
  @include font(
    --collection-card-title,
    var(--font-semibold),
    var(--font-sm),
    20px
  );
}
</style>
