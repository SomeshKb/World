import { render, staticRenderFns } from "./DNDAction.vue?vue&type=template&id=c60bb0c2&scoped=true&"
import script from "./DNDAction.vue?vue&type=script&lang=js&"
export * from "./DNDAction.vue?vue&type=script&lang=js&"
import style0 from "./DNDAction.vue?vue&type=style&index=0&id=c60bb0c2&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "c60bb0c2",
  null
  
)

export default component.exports