import { render, staticRenderFns } from "./CreateCollectionCard.vue?vue&type=template&id=3eb2ad8b&scoped=true&"
import script from "./CreateCollectionCard.vue?vue&type=script&lang=js&"
export * from "./CreateCollectionCard.vue?vue&type=script&lang=js&"
import style0 from "./CreateCollectionCard.vue?vue&type=style&index=0&id=3eb2ad8b&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "3eb2ad8b",
  null
  
)

export default component.exports