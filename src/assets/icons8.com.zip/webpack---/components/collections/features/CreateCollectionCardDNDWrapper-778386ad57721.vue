import { render, staticRenderFns } from "./CreateCollectionCardDNDWrapper.vue?vue&type=template&id=3f476778&scoped=true&"
import script from "./CreateCollectionCardDNDWrapper.vue?vue&type=script&lang=js&"
export * from "./CreateCollectionCardDNDWrapper.vue?vue&type=script&lang=js&"
import style0 from "./CreateCollectionCardDNDWrapper.vue?vue&type=style&index=0&id=3f476778&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "3f476778",
  null
  
)

export default component.exports