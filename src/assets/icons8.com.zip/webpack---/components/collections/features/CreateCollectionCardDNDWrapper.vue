<template>
  <div class="create-collection-card-dnd-wrapper">
    <DNDZone
      class="collection-dnd-wrapper"
      @dnd-dragging="handleDragging"
      @dnd-upload="handleUpload"
    >
      <CreateCollectionDNDCard
        v-if="isDragging"
        class="dnd-container"
      />
      <CreateCollectionCard
        v-else
        @createCollection="$emit('create')"
      />
    </DNDZone>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
import DNDZone from './drag-n-drop/DNDZone'
import CreateCollectionCard from './CreateCollectionCard'
import CreateCollectionDNDCard from './drag-n-drop/CreateCollectionDNDCard'

export default {
  name: 'CreateCollectionCardDNDWrapper',
  components: {
    DNDZone,
    CreateCollectionCard,
    CreateCollectionDNDCard
  },
  data () {
    return {
      isDragging: false
    }
  },
  methods: {
    ...mapActions({
      createCollection: 'collections/addCollection'
    }),
    handleDragging (isDragging) {
      this.isDragging = isDragging
    },
    handleUpload (icons) {
      if (!icons.length) return
      this.createCollection({ icons })
        .catch((err) => {
          console.error(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
  .collection-dnd-wrapper .dnd-container {
    pointer-events: none;
  }
</style>
