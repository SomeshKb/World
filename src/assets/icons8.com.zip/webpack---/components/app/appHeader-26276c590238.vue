import { render, staticRenderFns } from "./appHeader.vue?vue&type=template&id=4e8e34aa&scoped=true&"
import script from "./appHeader.vue?vue&type=script&lang=js&"
export * from "./appHeader.vue?vue&type=script&lang=js&"
import style0 from "./appHeader.vue?vue&type=style&index=0&id=4e8e34aa&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "4e8e34aa",
  null
  
)

export default component.exports