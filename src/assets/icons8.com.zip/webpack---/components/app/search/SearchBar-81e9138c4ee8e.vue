<template>
  <div class="search-bar">
    <SearchAutoComplete
      id="search-autocomplete"
      ref="searchInputWithAutocomplete"
      v-model="rawTerm"
      :domain="searchDomain"
      :class="{ 'hidden-labels': showHeader }"
      :items="displayedSuggestions"
      :placeholder="placeholder"
      @image-search-discard="onImageSearchDiscard"
      @submit="search"
      @suggest="onRawTermUpdate"
      @update:domain="v => searchDomain = v"
    >
      <template v-slot:prepend>
        <h1
          v-if="showHeader && rawTerm"
          class="search-header"
          @click="handleClickHeader"
        >
          <label
            for="icons-search-input"
            class="term"
          >
            {{ rawTerm }}
          </label>
        </h1>
      </template>
    </SearchAutoComplete>

    <SearchFilters v-if="showFilters" />

    <I8Button
      v-if="showFilters"
      icon-only
      size="large"
      class="mobile-filter-btn"
      aria-label="Filter"
      @click="toggleMobileFilter(!mobileFilterActive)"
    >
      <img
        v-if="filtersChanged"
        :src="`${staticUrl}/vue-static/icon/search-bar/filterSliderSelected.png`"
        alt="slider"
      >
      <I8Icon
        v-else
        :icon="filterSliderIcon.paths"
        :view-box="filterSliderIcon.viewBox"
        size="20px"
      />
    </I8Button>
  </div>
</template>

<script>
import { computed, ref, unref } from 'vue'
import { mapState, mapActions } from 'vuex'
import { I8Button, I8Icon, I8Dropdown, I8DropdownItem } from '@icons8/vue-kit'
import useStore from 'icons8-common/src/composables/store'
import { getUrlForSubmittedQuery, useSuggestions } from 'icons8-common/src/components/I8Search/helper'
import parserUrlParams from '@/plugins/parser-url-params'
import SearchAutoComplete from 'icons8-common/src/components/I8Search/I8SearchAutoComplete.vue'
import SearchFilters from '@/components/app/SearchFilters.vue'
import { useFilter } from '@/composables/useFilter'
import { filterSlider } from '@/assets/icons'

/**
 * "arrOw% baCk" -> arrow back
 *
 * @param {string} term
 * @param {function} normalizeFn
 * @return {string}
 */

function removeParamsFromTerm (term) {
  const mapPath = parserUrlParams(term)
  let cleanTerm = term
  for (const param in mapPath) {
    cleanTerm = cleanTerm.replace(`--${mapPath[param]}`, '')
  }
  return cleanTerm
}

export default {
  name: 'SearchBar',
  components: {
    I8Button,
    I8Icon,
    SearchAutoComplete,
    SearchFilters,
    I8Dropdown,
    I8DropdownItem
  },

  props: {
    showFilters: {
      type: Boolean,
      default: true
    }
  },

  setup () {
    const store = useStore()
    return useSuggestions(
      ref('icons'),
      {
        icons: {
          packs: computed(() => store.state.appInfo.packs),
          platform: computed(() => store.state.platform.apiCode)
        }
      }
    )
  },

  data () {
    return {
      term: '',
      showHeader: true,

      staticUrl: process.env.staticUrl ?? ''
    }
  },

  computed: {
    ...mapState({
      platform: state => state.platform,
      filters: state => state.filters,
      mobileFilterActive: state => state.ui.mobileFilterActive,
      isAnimated: state => state.filters.isAnimated,
      authors: state => state.filters.authors,
      baseColor: state => state.color,
      color: state => state.filters.color
    }),

    /** @returns {string} */
    placeholder () {
      const translatedDomain = this.$t(
        `WEB_APP.SEARCH.PLATFORM.${unref(this.searchDomain).toUpperCase()}`
      ).toLowerCase()
      return this.$t('WEB_APP.SEARCH.PLATFORM.PLACEHOLDER', { platform: translatedDomain })
    },

    /** @returns {{viewBox: string, paths: string[]}} */
    filterSliderIcon () {
      return filterSlider
    },

    /** @returns {boolean} */
    filtersChanged () {
      return this.platform.apiCode !== 'all' ||
        this.filters.isAnimated !== undefined ||
        this.filters.authors !== undefined ||
        this.filters.color !== undefined ||
        this.filters.colorGradient !== undefined
    }
  },

  watch: {
    '$route': {
      handler: 'termNormalize',
      immediate: true
    }
  },

  mounted () {
    this.showHeader = false // !!this.term

    // little hack for @icons8
    try {
      const $textInput = this.$refs.searchInputWithAutocomplete.$refs.searchInput
      $textInput.$el.removeAttribute('tabindex') // remove unnecessary tabindex
      $textInput.$refs.input.id = 'icons-search-input' // add input id so label can reference this control
    } catch (e) {
      console.error(e)
    }
  },

  methods: {
    ...mapActions([
      'toggleMobileFilter'
    ]),

    /** @param {import('icons8-common/src/components/I8Search/helper').Suggestion | string} item */
    search (item) {
      let query = typeof item === 'object' ? item.label : item
      if (arguments.length < 1) query = this.rawTerm
      if (!query) return

      // change input label with term without special symbols and extra spaces
      const cleanedTerm = query
        .split('-')
        .filter(it => it !== '')
        .join('-')

      this.rawTerm = removeParamsFromTerm(cleanedTerm).replace(/-/g, ' ')
      this.$store.dispatch('hideLeftSidebar')

      /* Redirect to other domain if not in icons */
      if (unref(this.searchDomain) !== 'icons') {
        window.location = getUrlForSubmittedQuery(item, this.urlCreator)
        return
      }

      const request = cleanedTerm
          // .replace(/ /g, '-')
          .replace(/[\s`~!@#$^&*()_|+=?;:",.<>\{\}\[\]\\\/]/gi, '-')

      this.pushSearchHistory(request)
      this.$router.push(useFilter(this.$store).createIconsURL({
        request,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authors,
        color: this.baseColor.code || this.baseColor.value,
        platform: this.platform.seoCode
      }))
    },

    handleClickHeader () {
      this.showHeader = false
      this.$refs.searchInputWithAutocomplete.$refs.searchInput.$refs.input.focus()
    },

    animatedParamsNormalize(value) {
      let animatedParams = null
      if (value) {
        animatedParams = 'animated'
      } else if (value === false) {
        animatedParams = 'static'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    },

    termNormalize() {
      if (this.$route.params.term) {
        this.rawTerm = removeParamsFromTerm(this.$route.params.term).replace(/-/g, ' ')
      }
    },

    onImageSearchDiscard () {
      this.$router.replace('/icons/set/popular')
    }
  }
}
</script>

<style lang="scss" scoped>
@use '@icons8/design-system/breakpoints';
@import '~assets/css/mixins';

$search-height: 48px;
$search-background: #ffffff;
$search-responsive-breakpoint: 'max-width: 500px';

:deep(.i8-dropdown__label:hover) {
  border-color: #BDBDBD;
}
:deep(.i8-dropdown__label:active), :deep(.i8-dropdown-label--is-open) {
  border-color: #737373 !important;
}

.search-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;

  @include breakpoints.for-desktop {
    gap: .5rem;
  }

  position: relative;
  margin: 24px 20px 0 20px;

  @include min(768) {
    margin: 16px 22px 0 32px;
  }

  z-index: 10;

  .i8-button {
    --button-padding-large: 24px;

    padding: 14px 24px;
    margin-left: 16px;

    @media (max-width: 800px) {
      --button-padding-large: 18px;
      margin-left: 0;
      padding: 14px 18px;
    }

    @media (max-width: 1023px) {
      margin-left: 0;
      &:not(.mobile-filter-btn) {
        display: none;
      }
    }
  }

  .i8-button.mobile-filter-btn {
    padding: 10px;

    @media (min-width: 1024px) {
      display: none;
    }

    img {
      width: 24px;
      height: 24px;
    }
  }
}

.search-header {
  position: absolute;
  z-index: 4;
  display: flex;
  align-items: center;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  margin: 0;
  padding-left: 15px;
  color: var(--c-black);
  overflow: hidden;
  letter-spacing: normal;

  .term {
    display: block;
    margin-left: -1px;
    font-size: var(--h3-font-size);
    white-space: nowrap;

    @media (max-width: 800px) {
      font-size: 16px;
    }
  }
}

.hidden-labels :deep(.auto-complete) {
  --text-input-input-color: transparent;
  --dropdown-font-color: transparent;
}

:deep(.i8-dropdown--is-open) {
  z-index: 4 !important
}
</style>
