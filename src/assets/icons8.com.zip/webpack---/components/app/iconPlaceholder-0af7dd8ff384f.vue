import { render, staticRenderFns } from "./iconPlaceholder.vue?vue&type=template&id=5432a6d3&scoped=true&"
import script from "./iconPlaceholder.vue?vue&type=script&lang=js&"
export * from "./iconPlaceholder.vue?vue&type=script&lang=js&"
import style0 from "./iconPlaceholder.vue?vue&type=style&index=0&id=5432a6d3&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "5432a6d3",
  null
  
)

export default component.exports