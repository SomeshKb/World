import "core-js/modules/es.object.keys.js";
import "core-js/modules/es.symbol.js";
import "core-js/modules/es.array.filter.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.object.get-own-property-descriptor.js";
import "core-js/modules/web.dom-collections.for-each.js";
import "core-js/modules/es.object.get-own-property-descriptors.js";
import "core-js/modules/es.array.slice.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.array.from.js";
import "core-js/modules/es.string.iterator.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.symbol.description.js";
import "core-js/modules/es.symbol.iterator.js";
import "core-js/modules/web.dom-collections.iterator.js";
import _defineProperty from "@babel/runtime/helpers/esm/defineProperty";
import _asyncToGenerator from "@babel/runtime/helpers/esm/asyncToGenerator";
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }
function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }
import "regenerator-runtime/runtime.js";
import { mapState } from 'vuex';
import SupportChat from '@icons8/support-chat';
import '@icons8/support-chat/dist/I8SupportChat.css';
export default defineComponent({
  name: 'CrispHelper',
  components: {
    SupportChat: SupportChat
  },
  setup: function setup() {
    /**
     * @param {{ id: string, email: string }} user
     */
    var hasher = /*#__PURE__*/function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(user) {
        var userId, userEmail;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                userId = user.id, userEmail = user.email;
                if (!(!userEmail || !userId)) {
                  _context.next = 3;
                  break;
                }
                return _context.abrupt("return", null);
              case 3:
                _context.next = 5;
                return $fetch('/icons/api/user-hash', {
                  method: 'POST',
                  body: {
                    userEmail: userEmail,
                    userId: userId
                  }
                });
              case 5:
                return _context.abrupt("return", _context.sent.data);
              case 6:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));
      return function hasher(_x) {
        return _ref.apply(this, arguments);
      };
    }();
    return {
      hasher: hasher,
      supportChatAppId: process.env.INTERCOM_APP_ID
    };
  },
  computed: _objectSpread({}, mapState({
    user: function user(state) {
      return state.auth.user;
    },
    shownSidebarCollection: function shownSidebarCollection(state) {
      return state.ui.sidebars.right.enabled && state.ui.sidebars.right.active;
    },
    cornerAd: function cornerAd(state) {
      return state.ui ? state.ui.cornerAd : undefined;
    }
  })),
  watch: {
    'user.loaded': function userLoaded(state) {
      // инфо о юзере загружено, если гость, то реклама показывается
      // значит у кнопки криспа должен быть отступ справа
      // для этого body дается класс карбона
      // if (this.user.isGuest) {
      //   this.toggleAds(true)
      // }
    },
    'user.isGuest': function userIsGuest(newState) {
      // если пользователь логинется или разлогинивается рантайм
      // в зависимости от состояния юзера туглим класс показа карбона на body
      this.toggleAds(newState);
    },
    '$route': function $route() {
      // выполняем только если юзер не залогинен
      if (this.user.isGuest) {
        // при смене роута, сбросим позицию по умолчанию(если вдруг реклама не загрузится)
        // и снова будем следить за появлением рекламы
        this.toggleCrispStyles('shown-carbon', false);
        this.observerStart();
      }
    },
    shownSidebarCollection: function shownSidebarCollection(newState) {
      // в зависимости от состояния колекции внизу экрана
      // смещаем кнопку криспа выше/ниже
      // переключая класс у body
      this.toggleCrispStyles('shown-collection', newState);
    }
  },
  mounted: function mounted() {
    this.observerStart();
  },
  beforeDestroy: function beforeDestroy() {
    this.observerStop();
  },
  methods: {
    toggleAds: function toggleAds(state) {
      if (!state) {
        // юзер залогинен, реклама карбона прячется
        // кнопку криспа располагается по умолчанию
        this.toggleCrispStyles('shown-carbon', false);
      } else {
        // следим за DOM в ожидании появления рекламы carbon
        this.observerStart();
      }
    },
    toggleCrispStyles: function toggleCrispStyles(classname, state) {
      // управляем позицей кнопки криспа в зависимости от наличия блока с carbon
      this.$el.classList.toggle(classname, state);
    },
    observerStart: function observerStart() {
      var _this = this;
      // бывает реклама не загружается
      // если проверять ее наличие только по состоянию юзера,
      // то может быть такое что реклама не загрузилась а пользователь залогинен
      // в этом случае кнопку криспа сдвигать нет смысла, так как блок с рекламой не загрузился
      // чтобы более точно убедится в наличии рекламы, будем следить за ее появлением в DOM с помощью Mutation Observer API
      // если произошли изменения в DOM и среди них есть блок с carbon рекламой
      // то кнопке криспа нужно дать отступ от правого края

      // на всякий случай, если обсервер уже есть
      this.observerStop();
      // следим за обновлением в DOM
      this.observer = new MutationObserver(function (mutations) {
        var _iterator = _createForOfIteratorHelper(mutations),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var mutation = _step.value;
            var node = mutation.addedNodes[0];
            if (!node) continue;
            var id = node.id;
            if (id && id === 'carbonads') {
              _this.toggleCrispStyles('shown-carbon', true);
              _this.observer.disconnect();
              break;
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      });
      this.observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    },
    observerStop: function observerStop() {
      if (this.observer) this.observer.disconnect();
      this.observer = null;
    }
  }
});