var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"crisp"},[_c('client-only',[_c('support-chat',{attrs:{"app-id":_vm.supportChatAppId,"corner-ad":_vm.cornerAd,"user":_vm.user,"user-hasher":_vm.hasher}})],1)],1)
}
var staticRenderFns = []

export { render, staticRenderFns }