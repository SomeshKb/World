// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-6c5ea0c2]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-6c5ea0c2]{display:none!important}}.app-page .box-header[data-v-6c5ea0c2]{position:relative;opacity:1;transition:all .3s}.app-page .title-wrap[data-v-6c5ea0c2]{display:flex;flex-wrap:wrap;align-items:center;margin-bottom:16px}@media(max-width:600px){.app-page .title-wrap[data-v-6c5ea0c2]{flex-direction:column;align-items:flex-start}}.app-page .app-title[data-v-6c5ea0c2]{color:#1a1a1a;margin:0;font-weight:700;font-size:18px;line-height:24px;letter-spacing:-.006em}.app-page .app-title[data-v-6c5ea0c2]:first-letter{text-transform:none}.app-page .app-page-subtitle[data-v-6c5ea0c2]{color:var(--c-black_900)}[data-v-6c5ea0c2] .app-title a{color:#1a1a1a;border-bottom:1px solid rgba(26,26,26,.26)}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
