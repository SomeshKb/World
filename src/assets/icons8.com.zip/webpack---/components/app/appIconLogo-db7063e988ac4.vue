<template>
  <a
    class="logo"
    :href="link"
  >
    <span class="rectangle" />
    <span class="circles">
      <span class="circle" />
      <span class="circle" />
    </span>
  </a>
</template>

<script>
export default {
  name: 'AppIconLogo',
  props: {
    link: {
      type: String,
      default: ''
    }
  }
}
</script>

<style lang="scss" scoped>
  @import '~assets/css/variables';
  .logo {
    background: transparent;
    width: 30px;
    height: 30px;
    display: flex;
    span {
      display: block;
    }
    .rectangle {
      width: 15px;
      height: 100%;
      box-sizing: border-box;
      // border: 2px solid white;
      background-color: $color-green;
    }
    .circle{
      width: 15px;
      height: 50%;
      box-sizing: border-box;
      // border: 2px solid white;
      border-radius: 100%;
      background-color: $color-green;
    }
  }
</style>
