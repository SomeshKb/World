<template>
  <div
    v-if="items"
    class="list i8-scroll"
  >
    <template v-for="item in items">
      <nuxt-link
        v-if="item.url"
        v-show="!item.hide"
        :key="item.id"
        class="list-item"
        :class="{'is-active': checkIsItemActive(item)}"
        :to="localePath(item.url)"
        @click.native="menuItemClick"
      >
        {{ generateListItem(item) }}
        <I8Badge
          v-if="item.isFree"
          class="free-badge"
        >
          {{ $t('ICON.COMPONENTS.PACK_PREVIEW.FREE') }}
        </I8Badge>
      </nuxt-link>
      <app-expand
        v-else-if="item.sublist"
        :key="item.id"
        class="is-sub-expand"
        :title="generateListItem(item)"
        :item="item"
        :chapter="'submenu'"
      >
        <div class="list sub-list">
          <nuxt-link
            v-for="submenuItem in item.sublist"
            :key="submenuItem.id"
            class="list-item sub-list-item"
            :class="{'is-active': $route.path === submenuItem.url}"
            :to="submenuItem.url"
            v-html="generateListItem(submenuItem)"
          />
        </div>
      </app-expand>
    </template>
  </div>
</template>

<script>
import { I8Badge } from '@icons8/vue-kit'
import { normalizeValue } from '@icons8/frontend-utils'

export default {
  name: 'MenuList',
  components: {
    I8Badge
  },
  props: {
    items: {
      type: Array,
      default: null
    }
  },
  methods: {
    generateListItem (item) {
      return item.subtitle || item.title
    },
    menuItemClick () {
      this.$emit('menu-item-click')
    },
    checkIsItemActive (item) {
      return this.$route.params.term?.split('--')[0] === normalizeValue(item.title.toLowerCase())
    },
  }
}
</script>

<style lang="scss" scoped>
  @import '~assets/css/components/list';

  .list {
    max-height: calc(100vh - 410px);
    --scroll-color-thumb-default: rgba(0, 0, 0, 0);
    --scroll-color-thumb-hover: rgba(0, 0, 0, 0);
    --scroll-color-thumb-active: rgba(0, 0, 0, 0);

    .list-item.sub-list-item {
      padding-left: 50px;
    }

    .list-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      white-space: normal;
    }

    .free-badge {
      --badge-color-regular: var(--c-green_500);
      background: rgba(31, 177, 65, 0.08);
    }
  }
</style>
