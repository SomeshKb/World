import { render, staticRenderFns } from "./appPage.vue?vue&type=template&id=0a1d8922&"
import script from "./appPage.vue?vue&type=script&lang=js&"
export * from "./appPage.vue?vue&type=script&lang=js&"
import style0 from "./appPage.vue?vue&type=style&index=0&id=0a1d8922&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports