<template>
  <div class="pack-filter" v-if="packList && packList.length">
    <menu-list
      :items="packList"
      @menu-item-click="menuItemClick"
    />
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { normalizeValue } from '@icons8/frontend-utils'
import { useFilter } from '@/composables/useFilter'
import { trimTerm } from '@/utils'
import menuList from './menuList.vue'

export default {
  name: 'PackFilter',
  components: {
    menuList
  },
  computed: {
    ...mapState({
      packs: state => state.appInfo.packs,
      user: state => state.auth.user,
      filters: state => state.filters,
      isAnimated: state => state.filters.isAnimated,
      authors: state => state.filters.authors,
      color: state => state.filters.color,
      platform: state => state.platform,
      platforms: state => state.appInfo.platforms,
    }),
    // TODO: это свойство почему-то пересчитывается по разу за каждый элемент в this.packs.
    //  Надо бы разобраться, а то должно-то за O(1) работать и не нагружать поток.
    packList () {
      let formattedList = this.packs.map(pack => {
        const isoCode = this.$i18n.localeProperties.iso
        const name = pack.name[isoCode] || pack.name['en-US']
        return {
          id: pack.code,
          title: name,
          url: this.createCategoryLink(name),
          isFree: pack.isFree
        }
      })

      formattedList.sort((a, b) => {
        if (a.title > b.title) {
          return 1
        }
        if (a.title < b.title) {
          return -1
        }
        return 0
      })

      // move freeIcons on top of list
      let freeIconsIndex = -1
      formattedList.some((pack, i) => {
        if (pack.id === 'free-icons') {
          freeIconsIndex = i
          return true
        }
      })
      if (freeIconsIndex > -1) {
        const freePack = Object.assign({}, formattedList.splice(freeIconsIndex, 1)[0])
        formattedList = [freePack].concat(formattedList)
      }

      return formattedList.filter(item => this.platform.packs && this.platform.packs.includes(item.id))
    }
  },
  mounted () {
    this.$emit('countPackFilters', this.packList.length)
  },
  methods: {
    menuItemClick () {
      this.$emit('menu-item-click')
    },
    createCategoryLink(category) {
      const categoryNormalize = trimTerm(category, normalizeValue)

      const animated = this.isAnimated
        ? 'animated'
        : this.isAnimated === false
          ? 'static'
          : undefined


      return useFilter(this.$store).createMenuURL({
        request: categoryNormalize,
        fullPath: `/icons/set/${categoryNormalize}`,
        animated: animated,
        authors: this.authors,
        color: this.color,
        platform: this.platform.seoCode
      })
    }
  }
}
</script>
<style lang="scss">
.pack-filter {
  padding-bottom: 30px;
}
</style>
