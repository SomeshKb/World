<template>
  <client-only>
    <div
        class="placeholder-wrap"
        :class="{'is-loading': isLoading}"
    >
      <template v-if="type === 'card'">
        <div
            v-if="iconsHeading"
            class="subtitle-placeholder animated-background"
        />
        <div class="item-wrap is-card">
          <div
              v-for="i of count"
              :key="i"
              class="layout-placeholder is-card"
          >
            <div class="placeholder">
              <div class="animated-background is-card" />
            </div>
          </div>
        </div>
      </template>
      <template v-if="type === 'icon'">
        <div
            v-if="iconsHeading"
            class="subtitle-placeholder animated-background"
        />
        <div class="item-wrap is-icon">
          <div class="gradient-layer" />
          <div
              v-for="i of count"
              :key="i"
              class="layout-placeholder is-icon"
          >
            <div class="placeholder-icon">
              <div class="ph-icon animated-background" />
              <div class="ph-title animated-background" />
            </div>
          </div>
        </div>
      </template>
      <template v-if="type === 'filters'">
        <div
            v-if="aggregatedTags"
            class="placeholder-tags animated-background"
        />
        <div class="placeholder-filters">
          <div
              v-for="filter in filters"
              :key="filter"
              class="placeholder-filter animated-background"
          />
        </div>
      </template>
      <template v-if="type === 'loading'">
        <div class="animated-background is-loading" />
      </template>
      <template v-if="type === 'slider'">
        <div class="placeholder-slider">
          <div class="animated-background is-slider is-loading" v-for="(item, index) in count "/>
        </div>
      </template>
    </div>
  </client-only>
</template>

<script>
export default {
  name: 'IconPlaceholder',
  props: {
    count: {
      type: Number,
      default: 19
    },
    type: {
      type: String,
      default: 'icon'
    },
    lineText: {
      type: Number,
      default: 3
    },
    text: {
      type: String,
      default: 'haveDescription'
    },
    iconsHeading: {
      type: Boolean,
      default: true
    },
    shortBottomMargin: {
      type: Boolean,
      default: false
    },
    descriptionHeading: {
      type: Boolean,
      default: true
    },
    aggregatedTags: {
      type: Boolean,
      default: false
    },
    filters: {
      type: Number,
      default: 2
    }
  },
  computed: {
    isLoading () {
      return this.type === 'loading'
    },
  }
}
</script>

<style lang="scss" scoped>
@import '~assets/css/mixins';
  .placeholder-wrap {
    height: 100%;
  }
  .subtitle-placeholder {
    background-color: #eee;
    width: 130px;
    height: 16px;
    margin: 40px 0 32px;
    border-radius: 16px;

    &:first-child {
      margin-top: 0;
    }
  }
  .item-wrap {
    margin: 0 -4px;
    position: relative;

    &.is-icon {
      max-height: calc(100vh - 280px);
      overflow-y: hidden;

      .gradient-layer {
        position: absolute;
        width: 100%;
        height: 100%;
        z-index: 999;
        background: linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, #FFFFFF 100%);
      }
    }

    &.is-card {
      margin: 0 -16px;
      display: flex;
      flex-flow: row wrap;
      justify-content: space-between;
    }
  }

  .layout-placeholder {
    display: inline-block;

    &.is-icon {
      width: 160px;
      height: 179px;
      padding: 0 3.5px;

      @media (max-width: 365px) {
        width: 50%;
        height: 159px;
      }
    }
    &.is-card {
      display: flex;
      position: relative;
      flex: 1;
      width: 307px;
      min-width: 307px;
      height: 203px;
      margin: 16px;
      border-radius: 8px;
      box-shadow: 0 8px 16px rgba(0, 0, 0, 0.03);
    }
  }

  .placeholder {
    background-color: #eee;
    border-radius: 8px;
    width: 100%;
    height: 100%;
  }

  .placeholder-icon {
    background: rgba(196, 196, 196, 0.1);
    border-radius: 8px;
    width: 100%;
    height: 100%;
    position: relative;

    .ph-icon {
      width: 64px;
      height: 64px;
      border-radius: 8px;
      position: absolute;
      top: 41px;
      left: 44px;
    }

    .ph-title {
      width: 116px;
      height: 16px;
      border-radius: 16px;
      position: absolute;
      bottom: 18px;
      left: 18px;
    }

      @media (max-width: 365px) {
        .ph-icon {
          width: 53px;
          height: 53px;
          top: 38px;
          left: 41px;
        }
        .ph-title {
          width: 96px;
        }
      }
  }

  .placeholder-slider {
    display: grid;
    column-gap: 32px;
    grid-template-columns: repeat(3, 1fr);
    @include max(1440) {
      grid-template-columns: repeat(2, 1fr);
      .animated-background.is-slider:nth-child(3) {
        display: none;
      }
    }
    height: 100%;
  }

  .animated-background {
    animation-duration: 1.25s;
    animation-fill-mode: forwards;
    animation-iteration-count: infinite;
    animation-name: placeHolderShimmer;
    animation-timing-function: linear;
    background: darkgray;
    // background: linear-gradient(to right, #eeeeee 10%, #dddddd 18%, #eeeeee 33%);
    background: linear-gradient(to right, rgba(0, 0, 0, 0.1) 10%, rgba(0, 0, 0, 0.05) 18%, rgba(0, 0, 0, 0.1) 33%);
    position: relative;
    background-size: 800px 104px;

    &.is-icon {
      height: 179px;
      border-radius: 6px;
      background-size: 800px 104px;
    }

    &.is-card {
      height: 203px;
      border-radius: 8px;
      background-size: 800px 104px;
    }

    &.is-loading {
      border-radius: 8px;
    }

    &.is-slider {
      margin-top: 0;
      border-radius: 8px;
      background-size: 800px 104px;
      width: 100%;
      height: 100%;
      top: 0;
      left: 28px;
    }

    &.heading-placeholder {
      background-size: 1200px 36px;
    }

    &.placeholder-text {
      background-size: 1200px 19px;
    }
  }

  .heading-placeholder {
    width: 400px;
    height: 32px;
    margin: 40px 0 32px;
    border-radius: 16px;

    @media (max-width: 520px) {
      width: 256px;
    }

    @media (max-width: 365px) {
      width: 200px;
    }
  }

  .placeholder-tags {
    width: 426px;
    height: 24px;
    border-radius: 16px;
    margin: 12px 0 28px;
    @media (max-width: $mobile-max){
      width: 100%;
    }
  }

  .placeholder-filters{
    display: flex;
    flex-wrap: wrap;
    margin: 20px 0 12px 0;
  }

  .placeholder-filter{
    width: 181px;
    height: 40px;
    border-radius: 16px;
    margin: 0 18px 0 0;
  }

  .placeholder-text {
    max-width: 800px;
    height: 16px;
    margin-bottom: 16px;
    border-radius: 16px;

    &.is-search {
      &:last-child {
        margin-bottom: 28px;
      }
    }

    &:last-child {
      margin-bottom: 80px;
      max-width: 400px;
    }

    @media (max-width: 520px) {
      &:last-child {
        max-width: 256px;
      }
    }

    @media (max-width: 365px) {
      &:last-child {
        max-width: 200px;
      }
    }
  }

  @keyframes placeHolderShimmer {
    0% {
      background-position: -468px 0
    }
    100% {
      background-position: 468px 0
    }
  }

  .is-loading {
    width: 100%;
    height: 100%;
  }

</style>
