<template>
  <div class="app-bottom-info">
    <div class="box-header">
      <div
        v-if="showTitle && seo && seo.page"
        class="title-wrap"
      >
        <h2
          v-if="subtitle"
          class="app-title"
          v-html="subtitle"
        />
      </div>
      <div
        v-if="showSeoDescription"
        class="app-page-subtitle is-small is-left"
        v-html="seo.page.description"
      />
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'AppBottomInfo',
  props: {
    showTitle: {
      type: Boolean,
      default: true
    },
    subtitle: {
      type: String,
      default: ''
    }
  },
  computed: {
    ...mapState({
      platform: state => state.platform,
      seo: state => state.seo.data,
      user: state => state.auth.user
    }),
    showSeoDescription () {
      return this.seo?.page?.description?.length > 3
    }
  },
  mounted () {
    this.currentPlatform = this.platform.apiCode
  }
}
</script>

<style lang="scss" scoped>
@import '~assets/css/variables';

.app-page {
  .box-header {
    position: relative;
    opacity: 1;
    transition: all 0.3s;
  }
  .title-wrap {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    margin-bottom: 16px;

    @media (max-width: 600px) {
      flex-direction: column;
      align-items: flex-start;
    }
  }
  .app-title {
    color: $sidebar-l_text-color;
    margin: 0;
    font-weight: bold;
    font-size: 18px;
    line-height: 24px;
    letter-spacing: -0.006em;
    &:first-letter {
      text-transform: none;
    }
  }

  .app-page-subtitle {
    color: var(--c-black_900);
  }
}
:deep(.app-title a) {
  color: $sidebar-l_text-color;
  border-bottom: 1px solid rgba(26, 26, 26, 0.26);
}

</style>
