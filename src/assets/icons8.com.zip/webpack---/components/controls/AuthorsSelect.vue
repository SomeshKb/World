<template>
  <div :class="['authors-select']">
    <I8Dropdown
      :value="dropdownValue"
      mode="outline"
      size="large"
      class="desktop-filter"
      :select="true"
      :cleanable="!areAllTypesSelected"
      @input="handleDropdownInput"
    >
      <I8DropdownItem
        v-for="(option, index) in options"
        :key="index"
        :value="option.label"
      />
    </I8Dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.FILTERS.DESIGNERS')"
      class="mobile-filter"
    >
      <template #summary-addon>
        {{ dropdownValue }}
      </template>
      <template #content>
        <DetailItem
          v-for="(option, index) in options"
          :key="index"
          :is-active="option.label === dropdownValue"
          @toggle="handleDropdownInput(option.label)"
        >
          <template #title>
            {{ option.label }}
          </template>
        </DetailItem>
      </template>
    </DetailExpander>
  </div>
</template>

<script>
import { I8Dropdown, I8DropdownItem } from '@icons8/vue-kit'
import { mapState, mapActions } from 'vuex'
import { useFilter } from '@/composables/useFilter'
import DetailExpander from './details/DetailExpander.vue'
import DetailItem from './details/DetailItem.vue'

export default {
  name: 'AuthorsSelect',
  components: { I8Dropdown, I8DropdownItem, DetailExpander, DetailItem },
  data () {
    return {
      options: [
        {
          value: undefined,
          label: this.$t('WEB_APP.SEO.FILTERS.AUTHORS.ALL')
        },
        {
          value: 'icons8',
          label: this.$t('WEB_APP.SEO.FILTERS.AUTHORS.ICONS8')
        },
        {
          value: 'external',
          label: this.$t('WEB_APP.SEO.FILTERS.AUTHORS.EXTERNAL')
        }
      ]
    }
  },
  computed: {
    ...mapState({
      authors: state => state.filters.authors, // has 3 values - [undefined | icons8 | external]
      color: state => state.filters.color, // has 5 values - [black | blue | green | red | white]
      isAnimated: state => state.filters.isAnimated,
      mobileFilterActive: state => state.ui.mobileFilterActive,
      currentPlatform: state => state.platform
    }),
    dropdownValue () {
      const selectedOption = this.options.find(option => option.value === this.authors)
      return selectedOption ? selectedOption.label : undefined
    },
    areAllTypesSelected () {
      const allTypesOption = this.options.find(option => option.value === undefined)
      return this.dropdownValue === allTypesOption.label
    }
  },
  methods: {
    ...mapActions([
      'setFilterAuthors',
      'setFilterIsAnimated'
    ]),
    handleDropdownInput (author) {
      this.$router.push(useFilter(this.$store).changeFilters({
        request: null,
        currentFilter: this.authorParamsNormalize(author),
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authorParamsNormalize(author),
        color: this.color,
        platform: this.currentPlatform.seoCode,
        isPlatformColor: null
      }))
    },

    authorParamsNormalize(value) {
      let authorParams = null

      if (value && value ===  'Independent' ) {
        authorParams = 'external'
      } else if (value && value ===  'Icons8') {
        authorParams = 'icons8'
      } else {
        authorParams = undefined
      }

      return authorParams
    },
    animatedParamsNormalize(value) {
      let animatedParams = null
      if (value) {
        animatedParams = 'animated'
      } else if (value === false) {
        animatedParams = 'static'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    },
  }
}
</script>
