<template>
  <div :class="['animation-select', { 'is-all-types-selected': isAllTypesSelected }]">
    <I8Dropdown
      :value="dropdownValue"
      class="desktop-filter"
      mode="outline"
      size="large"
      :select="true"
      @input="handleDropdownInput"
    >
      <I8DropdownItem
        v-for="(option, index) in options"
        :key="index"
        :value="option.label"
      />
    </I8Dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.FILTERS.ICON_TYPE')"
      class="mobile-filter"
    >
      <template #summary-addon>
        {{ dropdownValue }}
      </template>
      <template #content>
        <DetailItem
          v-for="(option, index) in options"
          :key="index"
          :is-active="option.label === dropdownValue"
          @toggle="handleDropdownInput(option.label)"
        >
          <template #title>
            {{ option.label }}
          </template>
        </DetailItem>
      </template>
    </DetailExpander>
  </div>
</template>

<script>
import { I8Dropdown, I8DropdownItem } from '@icons8/vue-kit'
import { mapState } from 'vuex'
import { useFilter } from '@/composables/useFilter'
import DetailExpander from './details/DetailExpander.vue'
import DetailItem from './details/DetailItem.vue'

export default {
  name: 'AnimationSelect',
  props: {
    isColor: { type: Boolean, default: false}
  },
  components: { I8Dropdown, I8DropdownItem, DetailExpander, DetailItem },
  data () {
    return {
      options: [
        {
          value: undefined,
          label: this.$t('WEB_APP.SEO.FILTERS.ANIMATION.ALL')
        },
        {
          value: true,
          label: this.$t('WEB_APP.SEO.FILTERS.ANIMATION.ANIMATED')
        },
        {
          value: false,
          label: this.$t('WEB_APP.SEO.FILTERS.ANIMATION.STATIC')
        }
      ]
    }
  },
  computed: {
    ...mapState({
      isAnimated: state => state.filters.isAnimated, // has 3 values - [undefined | true | false]
      mobileFilterActive: state => state.ui.mobileFilterActive,
      authors: state => state.filters.authors,
      color: state => state.filters.color,
      currentPlatform: state => state.platform
    }),
    dropdownValue () {
      const selectedOption = this.options.find(option => option.value === this.isAnimated)
      return selectedOption ? selectedOption.label : undefined
    },
    isAllTypesSelected () {
      const allTypesOption = this.options.find(option => option.value === undefined)
      return this.dropdownValue === allTypesOption.label
    }
  },
  methods: {
    handleDropdownInput (animated) {
      this.$router.push(useFilter(this.$store).changeFilters({
        request: null,
        currentFilter: this.animatedParamsNormalize(animated),
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(animated),
        authors: this.authors,
        color: this.color,
        platform: this.currentPlatform.seoCode,
        isPlatformColor: null
      }))
    },
    animatedParamsNormalize(animated) {
      let animatedParams = null
      if (animated && animated === 'Static') {
        animatedParams = 'static'
      } else if (animated && animated ===  'Animated') {
        animatedParams = 'animated'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    }
  }
}
</script>

<style lang="scss">
.animation-select.is-all-types-selected .i8-dropdown__chosen-close {
  display: none;
}
</style>
