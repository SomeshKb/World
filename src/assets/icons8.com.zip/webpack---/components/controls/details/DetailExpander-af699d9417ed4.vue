<template>
  <div
    class="detail-expander"
    :class="{ 'is-active': isShow }"
  >
    <div
      class="summary"
      tabindex="0"
      @click="handleToggle"
    >
      <I8Icon
        class="summary-chevron"
        icon="chevron"
        family="simpleSmall"
        size="16px"
      />
      <div class="summary-title">
        {{ title }}
      </div>

      <div class="summary-addon">
        <slot name="summary-addon" />
      </div>
    </div>
    <div
      v-show="isShow"
      class="content"
    >
      <slot name="content" />
    </div>
  </div>
</template>

<script>
import { I8Icon } from '@icons8/vue-kit'

export default {
  name: 'DetailExpander',
  components: { I8Icon },
  props: {
    open: {
      type: Boolean,
      default: false
    },
    title: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      isShow: this.open
    }
  },
  methods: {
    handleToggle () {
      this.isShow = !this.isShow
    }
  }
}
</script>

<style lang="scss" scoped>
.detail-expander {
  display: block;
  border-bottom: 1px solid var(--c-black_200);
}
.summary {
  position: relative;
  display: flex;
  align-items: center;
  padding-top: 10px;
  padding-bottom: 10px;
  cursor: pointer;
}
.summary-chevron {
  position: absolute;
  left: 0;
  transform: rotate(90deg);
  transition: transform .15s ease;

  .is-active & {
    transform: rotate(180deg);
  }
}
.summary-addon {
  margin-left: auto;
  font-size: 12px;
  white-space: nowrap;
  color: var(--c-black_600);
  &:empty {
    display: none;
  }
}
.summary-title {
  padding-left: 22px;
  margin-right: 8px;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  white-space: nowrap;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.content {
  padding-left: 22px;
}
</style>
