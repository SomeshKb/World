import { render, staticRenderFns } from "./DetailItem.vue?vue&type=template&id=167e0b64&scoped=true&"
import script from "./DetailItem.vue?vue&type=script&lang=js&"
export * from "./DetailItem.vue?vue&type=script&lang=js&"
import style0 from "./DetailItem.vue?vue&type=style&index=0&id=167e0b64&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "167e0b64",
  null
  
)

export default component.exports