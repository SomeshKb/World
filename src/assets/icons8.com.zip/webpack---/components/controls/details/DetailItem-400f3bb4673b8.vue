<template>
  <div
    class="detail-item"
    :class="{ 'is-active': isActive }"
    @click="handleToggle"
  >
    <div class="title">
      <div
        v-if="hasTitleBeforeSlot"
        class="title-before"
      >
        <slot name="title-before" />
      </div>
      <slot name="title" />
    </div>
    <I8Icon
      v-if="isActive"
      class="icon-selected"
      icon="checkmark"
      family="simpleSmall"
      size="16px"
    />
  </div>
</template>

<script>
import { I8Icon } from '@icons8/vue-kit'

export default {
  name: 'DetailItem',
  components: {
    I8Icon
  },
  props: {
    isActive: {
      type: Boolean,
      default: false
    }
  },
  computed: {
    hasTitleBeforeSlot () {
      return !!this.$slots['title-before']
    }
  },
  methods: {
    handleToggle () {
      this.$emit('toggle')
    }
  }
}
</script>

<style lang="scss" scoped>
.detail-item {
  display: flex;
  padding: 4px 10px;
  border-radius: 4px;
  cursor: pointer;

  &.is-active {
    font-weight: 600;
    background-color: var(--c-transparent-black_100);
  }
}
.title {
  display: flex;
  align-items: center;
  margin-right: 5px;
  white-space: nowrap;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
}
.title-before {
  margin-right: 8px;
}
.icon-selected {
  display: block;
  margin-left: auto;
}
</style>
