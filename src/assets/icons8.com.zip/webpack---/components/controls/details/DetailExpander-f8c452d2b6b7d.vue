// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-2a8aa8eb]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-2a8aa8eb]{display:none!important}}.detail-expander[data-v-2a8aa8eb]{display:block;border-bottom:1px solid var(--c-black_200)}.summary[data-v-2a8aa8eb]{position:relative;display:flex;align-items:center;padding-top:10px;padding-bottom:10px;cursor:pointer}.summary-chevron[data-v-2a8aa8eb]{position:absolute;left:0;transform:rotate(90deg);transition:transform .15s ease}.is-active .summary-chevron[data-v-2a8aa8eb]{transform:rotate(180deg)}.summary-addon[data-v-2a8aa8eb]{margin-left:auto;font-size:12px;white-space:nowrap;color:var(--c-black_600)}.summary-addon[data-v-2a8aa8eb]:empty{display:none}.summary-title[data-v-2a8aa8eb]{margin-right:8px;font-weight:600;font-size:14px;line-height:20px;white-space:nowrap;width:100%;overflow:hidden;text-overflow:ellipsis}.content[data-v-2a8aa8eb],.summary-title[data-v-2a8aa8eb]{padding-left:22px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
