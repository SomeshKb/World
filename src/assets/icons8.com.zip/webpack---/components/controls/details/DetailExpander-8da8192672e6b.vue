import { render, staticRenderFns } from "./DetailExpander.vue?vue&type=template&id=2a8aa8eb&scoped=true&"
import script from "./DetailExpander.vue?vue&type=script&lang=js&"
export * from "./DetailExpander.vue?vue&type=script&lang=js&"
import style0 from "./DetailExpander.vue?vue&type=style&index=0&id=2a8aa8eb&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "2a8aa8eb",
  null
  
)

export default component.exports