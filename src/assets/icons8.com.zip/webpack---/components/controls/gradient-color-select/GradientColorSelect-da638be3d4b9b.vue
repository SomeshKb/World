import { render, staticRenderFns } from "./GradientColorSelect.vue?vue&type=template&id=761a6052&scoped=true&"
import script from "./GradientColorSelect.vue?vue&type=script&lang=js&"
export * from "./GradientColorSelect.vue?vue&type=script&lang=js&"
import style0 from "./GradientColorSelect.vue?vue&type=style&index=0&id=761a6052&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "761a6052",
  null
  
)

export default component.exports