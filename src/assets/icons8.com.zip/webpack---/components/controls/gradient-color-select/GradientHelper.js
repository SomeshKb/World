/**
 * Returns palette of gradient colors
 * @returns {Array}
 */
export function getGradientColorList () {
  return [
    {
      id: 1,
      value: 'linear-gradient(180deg, #1A6DFF -0.42%, #C822FF 100.42%)',
      start: '#1A6DFF',
      end: '#C822FF',
      active: false,
      ord: 1
    },
    {
      id: 2,
      value: 'linear-gradient(0deg, #7028E4 0%, #E5B2CA 100%)',
      start: '#E5B2CA',
      end: '#7028E4',
      active: false,
      ord: 9
    },
    {
      id: 3,
      value: 'linear-gradient(0deg, #B12A5B 0%, #FF8177 100%)',
      start: '#FF8177',
      end: '#B12A5B',
      active: false,
      ord: 4
    },
    {
      id: 4,
      value: 'linear-gradient(0deg, #009EFD 0%, #2AF598 100%)',
      start: '#2AF598',
      end: '#009EFD',
      active: false,
      ord: 8
    },
    {
      id: 5,
      value: 'linear-gradient(360deg, #0072FF 0%, #00C6FF 100%)',
      start: '#00C6FF',
      end: '#0072FF',
      active: false,
      ord: 3
    },
    {
      id: 6,
      value: 'linear-gradient(180deg, #E6E6E6 0%, #808080 100%)',
      start: '#E6E6E6',
      end: '#808080',
      active: false,
      ord: 6
    },
    {
      id: 7,
      value: 'linear-gradient(180deg, #D9E021 0%, #FB872B 100%)',
      start: '#D9E021',
      end: '#FB872B',
      active: false,
      ord: 7
    },
    {
      id: 8,
      value: 'linear-gradient(180deg, #A3A1FF 0%, #3A3897 100%)',
      start: '#A3A1FF',
      end: '#3A3897',
      active: false,
      ord: 10
    },
    {
      id: 9,
      value: 'linear-gradient(180deg, #FF5300 0%, #45145A 100%)',
      start: '#FF5300',
      end: '#45145A',
      active: false,
      ord: 14
    },
    {
      id: 10,
      value: 'linear-gradient(180deg, #E090F0 0%, #05BDF5 100%)',
      start: '#E090F0',
      end: '#05BDF5',
      active: false,
      ord: 15
    },
    {
      id: 11,
      value: 'linear-gradient(180deg, #ECC84E 0%, #45C595 100%)',
      start: '#ECC84E',
      end: '#45C595',
      active: false,
      ord: 12
    },
    {
      id: 12,
      value: 'linear-gradient(180deg, #FEE195 0%, #5912AB 100%)',
      start: '#FEE195',
      end: '#5912AB',
      active: false,
      ord: 13
    },
    {
      id: 13,
      value: 'linear-gradient(180deg, #FFE29F 0%, #FF719A 100%)',
      start: '#FFE29F',
      end: '#FF719A',
      active: false,
      ord: 11
    },
    {
      id: 14,
      value: 'linear-gradient(180deg, #B0B0B0 0%, #2E2E2E 100%)',
      start: '#B0B0B0',
      end: '#2E2E2E',
      active: false,
      ord: 5
    },
    {
      id: 15,
      value: 'linear-gradient(0deg, #0BA360 0%, #7DE3C3 100%)',
      start: '#7DE3C3',
      end: '#0BA360',
      active: false,
      ord: 2
    }
  ].sort((a, b) => {
    if (a.ord < b.ord) {
      return -1
    }
    if (a.ord > b.ord) {
      return 1
    }
    return 0
  })
}
