import { PARENT_STYLE_MAPPING } from '@/constants'

/**
 * Returns platform list for desktop dropdown of style (platform) filter
 * @param {Object} vm - context
 * @returns {Array}
 */
export function getDesktopPlatformList (vm) {
  if (!vm.platforms) {
    return undefined
  }

  const mainSearch = vm.$route.params.term
  const styles = []

  Object.keys(vm.platforms).forEach(pl => {
    const platform = vm.platforms[pl] || {}
    const hide = platform.apiCode === 'emoji' && vm.$route.name === 'icon-pack-pack-platform'

    // check if current style is substyle
    const isSubstyle = Object.keys(PARENT_STYLE_MAPPING).some(key => {
      const mapping = PARENT_STYLE_MAPPING[key]

      const substyle = mapping.substyles.find(sub => sub.apiCode === platform.apiCode)

      if (substyle) { // if it is substyle
        let styleParent = styles.find(pl => pl.id === key)
        // if parent style doesn't exist yet create it
        if (!styleParent) {
          styleParent = {
            id: key,
            title: mapping.title,
            seoCode: mapping.seoCode,
            order: platform.order,
            preview: platform.preview,
            substyles: []
          }
          styles.push(styleParent)
        }
        // add substyle to parent style
        styleParent.substyles.push({
          id: platform.apiCode,
          seoCode: platform.seoCode,
          title: platform.fullTitle || substyle.title,
          order: platform.order,
          preview: platform.preview,
          hide,
        })
        return true
      }
      return false
    })
    // if it is substyle => leave (because at this point substyle was added it to its parent already)
    if (isSubstyle) return

    // add style to common style list
    styles.push({
      id: platform.apiCode,
      seoCode: platform.seoCode,
      title: platform.title,
      order: platform.order,
      preview: platform.preview,
      hide,
    })
  })

  // add translation for title of default ("All styles") style
  const defaultPlatform = styles.find(pl => pl.id === 'all')
  if (defaultPlatform) {
    defaultPlatform.title = vm.$t('WEB_APP.SEO.FILTERS.STYLE.ALL')
  }

  // sort styles by order
  styles.sort((a, b) => {
    if (!a || !b) return 0
    if (a.order < b.order) return -1
    return 1
  })
  // sort substyles by order
  styles.filter(style => style.substyles && style.substyles.length)
    .forEach(style => {
      style.substyles.sort((a, b) => {
        if (!a || !b) return 0
        return (a.order < b.order) ? -1 : 1
      })
    })
  return styles
}
