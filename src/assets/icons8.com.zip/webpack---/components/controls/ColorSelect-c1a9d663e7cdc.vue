// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-c5e90810]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-c5e90810]{display:none!important}}.color-list[data-v-c5e90810]{--dropdown-content-padding:16px;--dropdown-content-width:202px;--dropdown-label-padding-large:0 var(--spacer-sm) 0 var(--spacer-xs);--dropdown-outline-width:100%}.color-wrap[data-v-c5e90810]{display:flex}.color-item[data-v-c5e90810]{width:30px;height:30px;cursor:pointer;border-radius:4px;border:.5px solid rgba(0,0,0,.2)}.color-item[data-v-c5e90810]:not(:last-child){margin-right:5px}.color-item.is-active[data-v-c5e90810]{box-shadow:0 0 0 .5px rgba(0,0,0,.2),0 0 0 1px var(--c-white),0 0 0 3px var(--c-blue_500)}.detail-color-item[data-v-c5e90810]{display:block;width:16px;height:16px;border:1px solid var(--c-black_300);border-radius:50%}.color-icon[data-v-c5e90810]{display:flex}.color-icon[data-v-c5e90810],.color-icon img[data-v-c5e90810]{height:24px;width:24px}.color-icon.has-color[data-v-c5e90810]{width:20px;height:20px;border-radius:50%;border:.5px solid rgba(0,0,0,.2)}.mobile-color-wrap[data-v-c5e90810]{display:flex;margin-bottom:8px}.mobile-color-wrap .color-item[data-v-c5e90810]{height:52px;flex:1 0 52px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
