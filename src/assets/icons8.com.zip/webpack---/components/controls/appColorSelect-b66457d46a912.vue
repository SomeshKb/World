<template>
  <div class="app-color-picker" :class="isUppercase">
    <I8Dropdown
      class="desktop-filter"
      :value="colorValue"
      mode="outline"
      size="large"
      :select="true"
      :is-open="isOpen"
      :cleanable="isColor"
      @click="handleClick"
      @clear="handleDropdownClear"
    >
      <template slot="leftIcon">
        <div
          v-if="isColor"
          class="color-icon has-color"
          :style="{ 'background': `${currentColor.value}`}"
        >
        </div>
        <div v-else class="color-icon">
          <img :src="`${staticUrl}/vue-static/icon/color-wheel.png`" alt="Color wheel">
        </div>
      </template>
      <client-only>
        <appColorPalette
          v-model="currentColor"
          @change="changeColor"
          @enter="handleClose"
        >
        </appColorPalette>
      </client-only>
    </I8Dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.SEO.FILTERS.RECOLOR')"
      class="mobile-filter"
    >
      <template #summary-addon>
        <div v-if="currentColor.value" class="detail-color-block">
          <div
              class="detail-color-item"
              :style="{ 'background': `${currentColor.value}` }"
          />
          <div class="detail-color-title"> {{ currentColor.value }}</div>
        </div>
        <div
          v-else
          class="color-icon"
        >
          <img
            :src="`${staticUrl}/vue-static/icon/color-wheel.png`"
            alt="Color wheel"
          >
        </div>
      </template>
      <template #content>
        <div class="mobile-color-wrap">
          <appColorPalette
            v-model="currentColor"
            @change="changeColor"
            @enter="handleClose">
          </appColorPalette>
        </div>
      </template>
    </DetailExpander>
  </div>
</template>
<script>
import { I8Dropdown } from '@icons8/vue-kit'
import appColorPalette from '@/components/app/appColorPalette'
import { COLOR_EMPTY } from '@/constants';
import DetailExpander from './details/DetailExpander.vue'
import { mapState } from 'vuex';

export default {
  props: {
    value: { type: Object, default:() => {}}
  },
  components: {
    appColorPalette,
    I8Dropdown,
    DetailExpander
  },
  data() {
    return {
      isOpen: false,
      currentColor: COLOR_EMPTY
    }
  },
  created() {
    this.currentColor = this.value
  },
  watch: {
    value(value) {
      this.currentColor = value
    }
  },
  computed: {
    ...mapState({
      mobileFilterActive: state => state.ui.mobileFilterActive,
    }),
    staticUrl() {
      return process.env.staticUrl ?? ''
    },
    colorValue() {
      if (this.isColor) {
        return this.currentColor.title
      } else if (this.isColor && !this.currentColor.title) {
        return this.currentColor.value
      }
      return this.$t('WEB_APP.SEO.FILTERS.RECOLOR')
    },
    isColor() {
      return !!this.currentColor.value
    },
    isUppercase() {
      return {
        'app-color-picker_uppercase': this.currentColor?.title?.includes('#')
      }
    },
  },
  methods: {
    handleClick () {
      this.isOpen = true
    },
    handleDropdownClear () {
      this.currentColor = COLOR_EMPTY
      this.$emit('input', this.currentColor)
      this.$emit('change', this.currentColor)
    },
    handleClose () {
      this.isOpen = false
    },
    changeColor() {
      this.isOpen = false
      this.$emit('input', this.currentColor)
      this.$emit('change', this.currentColor)
    }
  }
}
</script>
<style lang="scss" scoped>
.app-color-picker {
  display: flex;
  &__input {
    height: 100%;
  }
}

.desktop-filter {
  --dropdown-z-index: auto
}

.detail-color-item {
  display: block;
  width: 16px;
  height: 16px;
  border: 1px solid var(--c-black_300);
  border-radius: 50%;
}
.color-icon {
  height: 24px;
  width: 24px;
  display: flex;
  img {
    height: 24px;
    width: 24px;
  }
  &.has-color {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 0.5px solid rgba(0, 0, 0, 0.2);
  }
}
.detail-color-block {
  display: flex;
}
.detail-color-title {
  margin-left: 8px;
}
:deep(.i8-dropdown__content) {
  width: auto;
  padding: 0;
}
.app-color-picker_uppercase :deep(.i8-dropdown__chosen) {
  text-transform: uppercase;
}
.color-icon {
  height: 24px;
  width: 24px;
  display: flex;
  img {
    height: 24px;
    width: 24px;
  }
  &.has-color {
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 0.5px solid rgba(0, 0, 0, 0.2);
  }
}
:deep(.i8-dropdown__label) {
  padding: 0px 12px 0px 8px;
}
</style>
