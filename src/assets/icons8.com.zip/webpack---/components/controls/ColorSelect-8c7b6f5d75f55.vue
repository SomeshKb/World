<template>
  <div class="color-select">
    <I8Dropdown
      :value="colorText"
      class="color-list desktop-filter"
      mode="outline"
      size="large"
      :select="true"
      :cleanable="false"
      :is-open="isOpen"
      @click="handleClick"
    >
      <template slot="leftIcon">
        <div
          v-if="filterColor && activeColor"
          class="color-icon has-color"
          :style="{ 'background': `#${activeColor.value}` }"
        />
        <div
          v-else
          class="color-icon"
        >
          <img
            :src="`${staticUrl}/vue-static/icon/color-wheel.png`"
            alt="Color wheel"
          >
        </div>
      </template>

      <div class="color-wrap">
        <div
          v-for="color in colorList"
          :key="`ci-${color.code}`"
          :class="colorItemClass(color.code)"
          :style="{ 'background': `#${color.value}` }"
          @click="changeColor(color.code)"
        />
      </div>
    </I8Dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.SEO.FILTERS.RECOLOR')"
      class="mobile-filter"
    >
      <template #summary-addon>
        <div
          v-if="filterColor && activeColor"
          class="detail-color-item"
          :style="{ 'background': `#${activeColor.value}` }"
        />
        <div
          v-else
          class="color-icon"
        >
          <img
            :src="`${staticUrl}/vue-static/icon/color-wheel.png`"
            alt="Color wheel"
          >
        </div>
      </template>
      <template #content>
        <div class="mobile-color-wrap">
          <div
            v-for="color in colorList"
            :key="`ci-${color.code}`"
            :class="colorItemClass(color.code)"
            :style="{ 'background': `#${color.value}` }"
            @click="changeColor(color.code)"
          />
        </div>
      </template>
    </DetailExpander>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import { I8Dropdown } from '@icons8/vue-kit'
import { useFilter } from '@/composables/useFilter'
import DetailExpander from './details/DetailExpander.vue'

export default {
  name: 'ColorSelect',
  props: {
    isColor: { type: Boolean, default: false }
  },
  components: { DetailExpander, I8Dropdown },
  data () {
    return {
      isOpen: false,
      staticUrl: process.env.staticUrl ?? ''
    }
  },
  computed: {
    ...mapState({
      isAnimated: state => state.filters.isAnimated,
      authors: state => state.filters.authors,
      colors: state => state.filters.colorsList,
      color: state => state.filters.color,
      baseColor: state => state.color,
      filters: state => state.filters,
      mobileFilterActive: state => state.ui.mobileFilterActive,
      currentPlatform: state => state.platform
    }),
    filterColor () {
      return this.filters.color
    },
    activeColor () {
      const activeColor = this.colorList.find(color => {
        return color.code === this.filterColor
      })
      return activeColor || this.colorList[0]
    },
    colorText () {
      return this.filterColor && this.activeColor
        ? this.activeColor.title
        : this.$t('WEB_APP.SEO.FILTERS.RECOLOR')
    },
    colorList () {
      if (!this.colors) return null
      return Object.keys(this.colors).map(color => {
        return {
          ...this.colors[color],
          title: this.$t(
            `WEB_APP.SEO.FILTERS.${this.colors[color].code.toUpperCase()}`,
            `${this.colors[color].title}`
          )
        }
      })
    }
  },
  methods: {
    handleClick () {
      this.isOpen = !this.isOpen
    },
    changeColor (color) {
      const colorParams = color === this.color ? undefined : color

      this.$router.push(useFilter(this.$store).changeFilters({
        request: colorParams,
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authors,
        color: colorParams,
        platform: this.currentPlatform.apiCode,
        isPlatformColor: null
      }))
    },
    colorItemClass (colorCode) {
      return ['color-item', { 'is-active': this.filterColor === colorCode }]
    },
    animatedParamsNormalize(value) {
      let animatedParams = null
      if (value) {
        animatedParams = 'animated'
      } else if (value === false) {
        animatedParams = 'static'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    },
  }
}
</script>

<style lang="scss">
  .mobile-filter .content {
    padding: 0;
  }
</style>

<style lang="scss" scoped>
  .color-list {
    --dropdown-content-padding: 16px;
    --dropdown-content-width: 202px;
    --dropdown-label-padding-large: 0 var(--spacer-sm) 0 var(--spacer-xs);
    --dropdown-outline-width: 100%;
  }
  .color-wrap {
    display: flex;
  }
  .color-item {
    width: 30px;
    height: 30px;
    cursor: pointer;
    border-radius: 4px;
    border: 0.5px solid rgba(0, 0, 0, 0.2);
    &:not(:last-child) {
      margin-right: 5px;
    }
    &.is-active {
      box-shadow: 0 0 0 .5px rgba(0, 0, 0, 0.2), 0 0 0 1px var(--c-white), 0 0 0 3px var(--c-blue_500);
    }
  }
  .detail-color-item {
    display: block;
    width: 16px;
    height: 16px;
    border: 1px solid var(--c-black_300);
    border-radius: 50%;
  }
  .color-icon {
    height: 24px;
    width: 24px;
    display: flex;
    img {
      height: 24px;
      width: 24px;
    }
    &.has-color {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      border: 0.5px solid rgba(0, 0, 0, 0.2);
    }
  }

  .mobile-color-wrap {
    display: flex;
    margin-bottom: 8px;
    .color-item {
      height: 52px;
      flex: 1 0 52px;
    }
  }
</style>
