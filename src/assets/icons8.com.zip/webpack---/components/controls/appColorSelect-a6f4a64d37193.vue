// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-ab3810a0]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-ab3810a0]{display:none!important}}.app-color-picker[data-v-ab3810a0]{display:flex}.app-color-picker__input[data-v-ab3810a0]{height:100%}.desktop-filter[data-v-ab3810a0]{--dropdown-z-index:auto }.detail-color-item[data-v-ab3810a0]{display:block;width:16px;height:16px;border:1px solid var(--c-black_300);border-radius:50%}.detail-color-block[data-v-ab3810a0]{display:flex}.detail-color-title[data-v-ab3810a0]{margin-left:8px}[data-v-ab3810a0] .i8-dropdown__content{width:auto;padding:0}.app-color-picker_uppercase[data-v-ab3810a0] .i8-dropdown__chosen{text-transform:uppercase}.color-icon[data-v-ab3810a0]{display:flex}.color-icon[data-v-ab3810a0],.color-icon img[data-v-ab3810a0]{height:24px;width:24px}.color-icon.has-color[data-v-ab3810a0]{width:20px;height:20px;border-radius:50%;border:.5px solid rgba(0,0,0,.2)}[data-v-ab3810a0] .i8-dropdown__label{padding:0 12px 0 8px}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
