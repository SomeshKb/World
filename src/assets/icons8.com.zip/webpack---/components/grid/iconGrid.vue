var render = function render(){var _vm=this,_c=_vm._self._c;return (_vm.icons && _vm.icons.length)?_c('div',{ref:"gridList",staticClass:"grid-icons"},[_vm._t("prepend"),_vm._v(" "),_vm._l((_vm.icons),function(icon,index){return _c('GridIcon',{key:index,ref:`icon-${icon.id}`,refInFor:true,staticClass:"grid-icons__item",attrs:{"icon":icon,"is-lazy":index >= 30,"observer-params":_vm.intersectionObserverParams,"selected":_vm.selectedIconIndex === index + 1},on:{"clickOnGridIcon":function($event){return _vm.iconAction(icon, index)}}})}),_vm._v(" "),_c('client-only',[(_vm.getAdsPosition)?_c('div',{staticClass:"ads-ss",style:({
        'grid-row-start': _vm.getAdsPosition + 1,
        'grid-row-end': _vm.getAdsPosition + 2
      })},[_c('ShutterstockAds',{attrs:{"ad-params":{
        query: _vm.adsParams.term,
        platform: _vm.adsParams.platform,
        locale: _vm.foundLanguage
      }}})],1):_vm._e(),_vm._v(" "),(_vm.carbonAd)?_c('CarbonHorizontalAd',{staticClass:"ads-carbon-horizontal",class:{'ads-carbon-horizontal_fixed': !_vm.isCarbonLast},on:{"rejectAds":function($event){_vm.carbonAdLoaded = false},"approveAds":function($event){_vm.carbonAdLoaded = true}}}):_vm._e()],1),_vm._v(" "),_c('client-only',[(_vm.action === 'select' && _vm.isAccordionShown)?_c('AppAccordionV2',{ref:"accordion",style:({
        'grid-row-start': _vm.accordionRow,
        'grid-row-end': _vm.accordionRow + 3
      }),attrs:{"id":"app-accordion","modelValue":_vm.isAccordionShown},on:{"close":function($event){return _vm.closeAccordion(true)}}}):_vm._e()],1)],2):_vm._e()
}
var staticRenderFns = []

export { render, staticRenderFns }