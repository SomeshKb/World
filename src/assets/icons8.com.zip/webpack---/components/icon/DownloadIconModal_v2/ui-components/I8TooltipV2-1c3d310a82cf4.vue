import { render, staticRenderFns } from "./I8TooltipV2.vue?vue&type=template&id=58cd4ab7&scoped=true&"
import script from "./I8TooltipV2.vue?vue&type=script&lang=js&"
export * from "./I8TooltipV2.vue?vue&type=script&lang=js&"
import style0 from "./I8TooltipV2.vue?vue&type=style&index=0&id=58cd4ab7&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "58cd4ab7",
  null
  
)

export default component.exports