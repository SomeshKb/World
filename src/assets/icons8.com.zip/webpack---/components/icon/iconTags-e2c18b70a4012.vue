<template>
  <div class="icon-tags">
    <div
      v-if="shortTags.length && showTitle"
      class="icon-tags-title"
    >
      {{ $t('WEB_APP.VIEW_ICONS.BROWSE_TAG') }}
    </div><a
      v-for="tag in shortTags"
      :key="tag"
      class="tag"
      :href="`/icons/set/${tag ? tag.toLowerCase().split(' ').join('-') : ''}`"
    >{{ tag }}</a>
    <template v-if="othersTags">
      <app-popup
        ref="othrs-tags-popup"
        position="bottom-right"
        :show-toggle="false"
      >
        <div class="app-popup-btn">
          <i /><i /><i />
        </div>
        <div slot="content">
          <div class="icon-tags">
            <a
              v-for="otherTag in othersTags"
              :key="otherTag"
              class="tag"
              :href="`/icons/set/${otherTag ? otherTag.toLowerCase().split(' ').join('-') : ''}`"
            >{{ otherTag }}</a>
          </div>
        </div>
      </app-popup>
    </template>
  </div>
</template>

<script>
export default {
  name: 'IconTags',
  props: {
    tags: {
      type: Array,
      default: () => []
    },
    showTitle: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    shortTags () {
      return this.tags ? [...new Set(this.tags)].slice(0, 23) : []
    },
    othersTags () {
      return (this.tags.length > 23) ? this.tags.slice(23, 100) : null
    }
  }
}
</script>

<style lang="scss">
  .icon-tags {
    font-size: 15px;
    line-height: 20px;
    .icon-tags-title {
      display: inline-block;
      margin-right: 0.5rem;
    }

    .tag {
      height: 37px;
      border-radius: 20px;
      background-color: #ffffff;
      border: 1px solid rgba(#333333, .2);
      color: #333333;
      line-height: 31px;
      text-transform: capitalize;
    }

    .app-popup {
      display: inline-block;;
    }

    div.app-popup div.app-popup-content {
      width: 30rem;
      padding: 8px 0 0 8px;
      @media (max-width: 1170px) {
        width: 25rem;
        right: 0;
        transform: translateX(50%)
      }
    }

    .app-popup-btn {
      display: flex;
      align-items: center;
      justify-content: space-around;
      width: 48px;
      height: 26px;
      margin-bottom: 8px;
      background-color: #f4f4f4;
      border-radius: 5px;
      color: #9b9b9b;
      padding: 0 8px;
      border: 1px solid hsla(0, 0%, 61%, 0);
      text-decoration: none;
      cursor: pointer;
      transition: 0.3s all ease;
      i {
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background-color: #000000;
      }
    }
  }

</style>
