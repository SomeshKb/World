import { render, staticRenderFns } from "./appIcon.vue?vue&type=template&id=66995bac&"
import script from "./appIcon.vue?vue&type=script&lang=js&"
export * from "./appIcon.vue?vue&type=script&lang=js&"
import style0 from "./appIcon.vue?vue&type=style&index=0&id=66995bac&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports