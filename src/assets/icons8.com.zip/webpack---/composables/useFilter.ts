import type { ComponentPublicInstance } from '#app'
import {
  COLOR_LIST,
  AUTHORS_MAP,
  ANIMATION_MAP,
  COLOR_EMPTY
} from '@/constants'

const EXCLUDE_URL = {
  noStaticIfIsColor: [
    'icons-authors-authorId-alias',
    'icons-authors-authorId-alias-platform',
    'icons-authors-authorId-alias-platform-pack',
  ]
}

export interface FiltersParams {
  fullPath: string

  animated?: 'animated' | 'static'
  authorPlatform?: string
  authors?: string
  color?: string
  isPlatformColor?: boolean
  namePack?: string
  platform?: string
  request?: string
}

export interface ChangeFiltersParams extends FiltersParams {
  currentFilter: string
  routeName: string | null | undefined
}

export function useFilter (store: ComponentPublicInstance['$store']) {

  // Utils
  function clearParams (url: string): string | undefined {
    return url.split('--')[0]
  }
  /**
   * Clears the request of first part before /
   */
  function clearRequest (url: string): string {
    const [, part, type ] = url.split('/')
    return `/${part}/${type}`
  }
  function createIconURL (params: FiltersParams): string {

    let {
      fullPath,
      animated,
      authors,
      color,
      platform,
    } = params

    let clearUrl = clearParams(fullPath)
    let currentPlatform = store.state.platform.seoCode
    let filterUrl = ''

    if (platform && platform !== 'all' && currentPlatform !== platform) {
      clearUrl = `/icons`
      filterUrl = `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixParam(authors)}${prefixColorParam(color)}`
      return filterUrl
    } else if (currentPlatform && !platform ){
      filterUrl = `/icons#styles`
      return filterUrl
    }
    filterUrl = `${clearUrl}`
    return filterUrl
  }
  function createNewIconsURL (params: FiltersParams): string {
    let {
      fullPath,
      authors,
      color,
      platform,
      request,
    } = params

    let clearUrl = clearParams(fullPath)
    let clearUrlRequest = clearRequest(clearUrl)

    clearUrl = clearUrlRequest

    if (request && (platform && platform !== 'all')) {
      clearUrl = `/icon/set`
      const urlParams = `${request !== color ? prefixColorParam(color): ``}${request !== authors ? prefixParam(authors): ``}`
      const urlRequest = `${clearUrl}${requestNormalize(request)}${normalizePlatform(platform)}`
      return `${urlRequest}${urlParams}`
    }

    if (platform && platform !== 'all' && !request) {
      clearUrl = '/icon/new-icons'
      request = platform
    }

    if (request && (!platform || platform === 'all')) {
      clearUrl = `/icons/set`
    }

    if (!request) {
      clearUrl = '/icons/new'
      if (authors) {
        request = authors
      } else if (color) {
        request = color
      }
    }

    const urlParams = `${request !== color ? prefixColorParam(color): ``}${request !== authors ? prefixParam(authors): ``}`
    const urlRequest = `${clearUrl}${requestNormalize(request)}`
    return `${urlRequest}${urlParams}`
  }
  function createPlatformURL (params: FiltersParams): string {
    let {
      fullPath,
      animated,
      authors,
      color,
      platform
    } = params

    let clearUrl = clearParams(fullPath)

    if (platform && platform !== 'all') {
      clearUrl = `/icons`
    }

    let filterUrl = `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixParam(authors)}${prefixColorParam(color)}`

    if (platform === undefined || platform === 'all') {
      filterUrl = `/icons#styles`
    }
    return filterUrl
  }
  function createUrl (routeName: string | null, params: FiltersParams): string {
    if (
        [
          'icons-new',
          'icons-new-filter',
          'icon-new-icons-platform'
        ].includes(routeName)) {
      return createNewIconsURL(params)
    }

    if (
        [
          'icons-set-term',
          'icon-set-term-platform'
        ].includes(routeName) || routeName === null) {
      return createIconsURL(params)
    }

    if (
        [
          'icon-id-name'
        ].includes(routeName) || routeName === null) {
      return createIconURL(params)
    }

    if (
        [
          'icons-authors-authorId-alias',
          'icons-authors-authorId-alias-platform',
          'icons-authors-authorId-alias-platform-pack',
        ].includes(routeName)) {
      return createAuthorsURL(params)
    }

    if (
        ['create-menu-url'].includes(routeName)
    ) {
      return createMenuURL(params)
    }

    return createPlatformURL(params)
  }
  function normalizePlatform (value: string): string {
    return value && value !== 'all' ? `/${value}`: ''
  }
  function prefixColorParam (value: string): string {
    return value
        ? value.includes('#')
            ? `--c-${value.replace('#', '')}`
            : `--${value}`
        : ''
  }
  function prefixParam (value: string): string {
    return value ? `--${value}`: ''
  }
  function requestNormalize (value: string): string {
    if (value && value.includes('#')) {
      return `/c-${value.replace('#', '')}`
    }
    return value ? `/${value}`: ''
  }


  /**
   * Creates a URL for authors page
   */
  function createAuthorsURL (params: FiltersParams): string {
    const {
      fullPath,
      animated,
      namePack,
      color,
      authors,
      platform,
      authorPlatform
    } = params

    let clearUrl = clearParams(fullPath)
    let filterUrl = `${clearUrl}${normalizePlatform(authorPlatform)}${normalizePlatform(namePack)}${prefixParam(animated)}${prefixColorParam(color)}`

    if (platform && platform !== 'all') {
      filterUrl = `/icons${normalizePlatform(platform)}${prefixParam(animated)}${prefixParam(authors)}${prefixColorParam(color)}`
    }

    return filterUrl
  }
  /**
   * Creates a URL for icons
   */
  function createIconsURL (params: FiltersParams): string {
    let {
      fullPath,
      animated,
      authors,
      color,
      platform,
      request
    } = params

    let clearUrl = clearParams(fullPath)
    let [,,, pageUrl] = fullPath.split('/')

    if (request) { pageUrl = request }

    if (platform && platform !== 'all') {
      clearUrl = `/icon/set/${clearParams(pageUrl)}`
    } else if (platform == undefined || platform === 'all') {
      clearUrl = `/icons/set/${clearParams(pageUrl)}`
    } else if (request) {
      clearUrl = `/icons/set/${request}`
    }

    return `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixColorParam(color)}${prefixParam(authors)}`
  }
  /**
   * Creates a URL for a menu entry
   */
  function createMenuURL (params: FiltersParams): string {
    let {
      request,
      fullPath,
      animated,
      authors,
      color,
      platform
    } = params

    let clearUrl = fullPath
    if (authors === AUTHORS_MAP.EXTERNAL) authors = undefined
    // if (isPlatform) isPlatform = undefined

    if (request === 'emoji') {
      clearUrl = `/icon/set/${request}/${request}`
    }

    if (platform && platform !== 'all') {
      clearUrl = `/icon/set/${request}`
    }

    return `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixColorParam(color)}${prefixParam(authors)}`
  }
  /**
   * Creates a URL for the pack
   */
  function createPackURL (params: FiltersParams): string {
    let {
      fullPath,
      animated,
      authors,
      color,
      platform,
      isPlatformColor
    } = params

    const clearUrl = clearParams(fullPath)

    return isPlatformColor
        ? `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixParam(authors)}`
        : `${clearUrl}${normalizePlatform(platform)}${prefixParam(animated)}${prefixColorParam(color)}${prefixParam(authors)}`
  }
  /**
   * Changes filters based on params, commits to store and returns a URL
   */
  function changeFilters (params: ChangeFiltersParams): string {
    const {
      fullPath,
      isPlatformColor,
      animated,
      authors,
      color,
      platform,
      request,
      currentFilter,
      routeName
    } = params

    let animatedParams = animated
    let colorParams = color
    let authorsParams = authors
    let isGradient = store.state.filters.colorGradient

    const isExclude = !!routeName && EXCLUDE_URL.noStaticIfIsColor.includes(routeName)
    const isRequestColor = COLOR_LIST.map(it => it.code).includes(currentFilter) || (!!currentFilter && currentFilter.includes('#'))

    if (currentFilter === ANIMATION_MAP.ANIMATED && authorsParams === AUTHORS_MAP.EXTERNAL) {
      authorsParams = undefined
      colorParams = undefined
    } else if (currentFilter === ANIMATION_MAP.ANIMATED && colorParams) {
      colorParams = undefined
    } else if (currentFilter === AUTHORS_MAP.EXTERNAL && animatedParams === ANIMATION_MAP.ANIMATED) {
      animatedParams = undefined
    } else if (platform !== 'all' && isPlatformColor) {
      colorParams = undefined
    } else if (animatedParams === ANIMATION_MAP.ANIMATED && isGradient) {
      isGradient = undefined
    } else if (isRequestColor && !isExclude) {
      animatedParams = ANIMATION_MAP.STATIC as 'static'
    }

    /*
     * Set filters
     */

    const lowercaseColor = colorParams && colorParams.toLowerCase()

    const isAnimatedFilter = (
        animatedParams === ANIMATION_MAP.ANIMATED ? true
            : animatedParams === ANIMATION_MAP.STATIC ? false
                : undefined
    )

    store.dispatch('setFilterColor', lowercaseColor)
    store.dispatch('setFilterAuthors', authorsParams)
    store.dispatch('setFilterIsAnimated', isAnimatedFilter)
    store.dispatch('setFilterColorGradient', isGradient)

    const predefinedColor = COLOR_LIST.find(item => item.code === lowercaseColor)

    if (predefinedColor) {
      store.dispatch('icon/changeColor', predefinedColor.value)
      store.dispatch('setSearchColor', predefinedColor)
    } else if (lowercaseColor) {
      store.dispatch('icon/changeColor', lowercaseColor)
      store.dispatch('setSearchColor', { title: lowercaseColor, code: null, value: lowercaseColor })
    } else {
      store.dispatch('icon/changeColor', '000000')
      store.dispatch('setSearchColor', COLOR_EMPTY)
    }

    return createUrl(
        routeName,
        {
          fullPath,
          request,
          platform,
          animated: animatedParams,
          color: lowercaseColor,
          authors: authorsParams
        }
    )
  }

  return {
    createAuthorsURL,
    createIconsURL,
    createMenuURL,
    createPackURL,
    changeFilters
  }
}
