import { defaultState } from './_constants'
export default () => (defaultState)
