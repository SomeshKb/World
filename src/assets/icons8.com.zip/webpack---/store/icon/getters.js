import { wasIconDownloaded } from '@/api/user'

export default {
  getRecolorGradient: (state) => {
    return state.recolorGradient ? state.recolorGradient : undefined
  },

  /**
   * Get icon download size limit depending on user license
   * @param state
   * @param getters
   * @param rootState
   * @return (icon: object) => number
   */
  getSizeLimit: (state, getters, rootState) => (icon = {}) => {
    if (icon === undefined || icon.id === undefined) {
      return state.freeUserSizeLimit
    }

    const checkLimits = (alreadyDownloaded) => {
      if (alreadyDownloaded || icon.free) {
        return state.paidIconSizeLimit
      } else {
        return state.freeUserSizeLimit
      }
    }

    if (icon.alreadyDownloaded !== undefined) {
      return checkLimits(icon.alreadyDownloaded)
    } else {
      wasIconDownloaded(icon.id, rootState.auth.user).then((alreadyDownloaded) => {
        return checkLimits(alreadyDownloaded)
      })
    }
  },

  /**
   * Check if user can download given icon.
   * @param state
   * @param getters
   * @param rootState
   * @return {function({icon: object, format: string, size: number}): boolean}
   */
  isIconAvailable: (state, getters, rootState) => ({
    icon,
    format,
    size
  }) => {
    // license checking
    const user = rootState.auth.user
    let license
    if (user.allowances && user.allowances.length) {
      license = user.allowances.find(allowance => allowance.resource === 'icon') || null
    }
    // license checking

    let isPngAvailable
    if (format === 'png') {
      isPngAvailable = format === 'png' && size <= getters.getSizeLimit(icon)
    }
    return Boolean(
      !!license ||
      isPngAvailable ||
      format === 'gif' ||
      icon.free ||
      icon.isFree ||
      icon.imported ||
      icon.isUserSource
    )
  },

  /**
   * Check if current user can download given icons.
   * @param state
   * @param getters
   * @param rootState
   * @return (object) => object[] | Boolean
   */
  areIconsAvailable: (state, getters, rootState) => ({
    icons,
    icon = state.selectedIcon,
    user = rootState.auth.user,
    options = {}
  }) => {
    icons = icons || [icon]

    // if user has active license on icons
    // he has all rights

    // license checking
    let license
    if (user.allowances && user.allowances.length) {
      license = user.allowances.find(allowance => allowance.resource === 'icon') || null
    }
    // license checking

    if (license) {
      return true
    }

    // compare with format or current icon state format
    const format = options.format || state.format
    // compare with size or current icon state size
    const size = options.size || state.size

    // noinspection JSCheckFunctionSignatures
    return icons.every(icon => getters.isIconAvailable({
      icon, format, size
    }))
  },

  /**
   * Get available icons from given list
   * @param state
   * @param getters
   * @param rootState
   * @template T
   * @return ({icons: T[], format: string, size: number}) => T[]
   */
  getAvailableIcons: (state, getters, rootState) => ({
    icons,
    format = state.format,
    size = state.size
  }) => {
    // license checking
    const user = rootState.auth.user
    let license
    if (user.allowances && user.allowances.length) {
      license = user.allowances.find(allowance => allowance.resource === 'icon') || null
    }
    // license checking

    if (license) { return icons }

    // noinspection JSCheckFunctionSignatures
    return icons.filter(icon => getters.isIconAvailable({
      icon, format, size
    }))
  },

  /**
   * Is full icon loaded
   * @param state
   * @return boolean
   */
  fullIconLoading: (state) => {
    return state.selectedIcon.id !== state.fullIcon.id
  },

  /**
   * Has icon svg format
   * @param state
   * @return boolean
   */
  hasSvgFormat: (state) => {
    return state.fullIcon.formats ? state.fullIcon.formats.includes('svg') : true
  }
}
