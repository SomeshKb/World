export const LOCALSTORAGE_KEY = 'options'

export const DEFAULT_ICON = {
  category: undefined,
  categoryApiCode: undefined,
  commonId: undefined,
  commonName: undefined,
  filled: undefined,
  formats: undefined,
  free: undefined,
  jsonAnimateIcon: undefined,
  id: undefined,
  mainId: undefined,
  name: undefined,
  platform: undefined,
  pngSize: undefined,
  resolutions: undefined,
  subcategory: undefined,
  svg: undefined,
  svgBase64: undefined,
  svgCurrentResolution: undefined,
  svgEffect: undefined,
  timestamp: undefined,
  url: undefined,
  variants: undefined
}

export const DEFAULT_COLOR = '000000'
export const DEFAULT_RESOLUTION = 40
export const DEFAULT_FREE_USER_SIZE_LIMIT = 100
export const DEFAULT_PAID_ICON_SIZE_LIMIT = 1600
export const DEFAULT_RECOLOR_GRADIENT = {
  active: 'presetGradient',
  customGradient: {change: false},
  presetGradient: {change: false, init: false}
}

export const defaultState = {
  selectedIcon: {...DEFAULT_ICON},
  fullIcon: {...DEFAULT_ICON},
  isMultiSize: false,
  isSimplified: true,
  color: DEFAULT_COLOR,
  resolution: DEFAULT_RESOLUTION,
  freeUserSizeLimit: DEFAULT_FREE_USER_SIZE_LIMIT,
  paidIconSizeLimit: DEFAULT_PAID_ICON_SIZE_LIMIT,
  recolorGradient: DEFAULT_RECOLOR_GRADIENT,
  accordion: {
    activeEffect: '',
    project: {
      id: undefined,
      size: undefined
    }
  }
}

export const propsToSyncWithLS = [
  'selectedIcon',
  'color',
  'resolution',
  'isSimplified'
]
