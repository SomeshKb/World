import * as types from './_mutationTypes'
import { getIcon } from '../../api/icon'
import { wasIconDownloaded } from '../../api/user'
import {defaultState} from "~/store/icon/_constants";

export default {
  /**
   * @param commit
   * @param {string} format
   */
  changeFormat ({ commit }, format) {
    commit(types.CHANGE_FORMAT, format)
  },

  /**
   * @param commit
   * @param {number} size
   */
  changeSize ({ commit }, size) {
    commit(types.CHANGE_SIZE, size)
  },

  /**
   * @param commit
   * @param {number} sizeIndex
   */
  changeSizeIndex ({ commit }, sizeIndex) {
    commit(types.CHANGE_SIZE_INDEX, sizeIndex)
  },

  /**
   * @param commit
   * @param {string} color
   */
  changeColor ({ commit }, color) {
    commit(types.CHANGE_COLOR, color)
  },

  /**
   * @param commit
   * @param {object} colorMap TODO: strict type
   * TODO: change signature where used
   */
  changeColorMap ({ commit }, colorMap) {
    commit(types.CHANGE_COLOR_MAP, colorMap)
  },

  /**
   * Select icon, load it and set fullIcon.
   * @param commit
   * @param dispatch
   * @param rootState
   * @param {Object} icon
   * @param {Boolean} svg
   * @return {Promise<Error | undefined>}
   */
  async selectIcon ({ commit, dispatch, rootState }, { icon, svg = false }) {
    commit(types.SELECT_ICON, icon)
    const fullIcon = {...icon}

    try {
      const response = await getIcon({ id: icon.id, language: this.$i18n.localeProperties.iso, svg })
      Object.assign(fullIcon, response.icon)
    } catch (e) {
      console.warn('Could not get full icon on select')
      console.error(e)
    }

    commit(types.SET_FULL_ICON, fullIcon)
  },

  /**
   * Reset both selectedIcon and fullIcon.
   * @param commit
   */
  unselectIcon ({ commit }) {
    commit(types.RESET_ICON)
  },

  /**
   * @param commit
   * @param {boolean} isMultiSize
   */
  setMultiSize ({ commit }, isMultiSize) {
    commit(types.SET_MULTI_SIZE, isMultiSize)
  },

  /**
   * @param commit
   * @param {boolean} isSimplified
   */
  setSimplified ({ commit }, isSimplified) {
    commit(types.SET_SIMPLIFIED, isSimplified)
  },

  /**
   * @param commit
   * @param {number | undefined} resolution
   */
  changeResolution ({ commit }, resolution) {
    commit(types.CHANGE_RESOLUTION, resolution)
  },

  /**
   * Patch fullIcon with given object
   * @param commit
   * @param dispatch
   * @param {object} data
   */
  extendFullIcon ({ commit, dispatch }, data) {
    commit(types.EXTEND_FULL_ICON, data)
  },

  /**
   * @param commit
   * @param {object} data
   */
  setFullIconSvg ({ commit }, data) {
    commit(types.SET_FULL_ICON_SVG_EFFECT, data)
  },

  /**
   * @param commit
   */
  removeFullIconSvg ({ commit }) {
    commit(types.SET_FULL_ICON_SVG_EFFECT, undefined)
  },

  /**
   * @param commit
   * @param {string} data
   */
  setFullIconSvgBase64 ({ commit }, data) {
    commit(types.SET_FULL_ICON_SVG_B64, data)
  },

  /**
   * @param commit
   */
  removeFullIconSvgBase64 ({ commit }) {
    commit(types.SET_FULL_ICON_SVG_B64, undefined)
  },

  /**
   * @param commit
   * @param {string} effectName
   */
  setActiveEffect ({ commit }, effectName) {
    if (effectName) {
      commit(types.SET_ACTIVE_EFFECT, effectName)
    } else {
      commit(types.SET_ACTIVE_EFFECT, defaultState.accordion.activeEffect)
    }
  },

  /**
   * @param commit
   * @param {object} project
   */
  setCanvasProject ({ commit }, project) {
    if (project) {
      commit(types.SET_CANVAS_PROJECT, project)
    } else {
      commit(types.SET_CANVAS_PROJECT, defaultState.accordion.project)
    }
  }
}
