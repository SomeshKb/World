'use strict'

const SET_DESIGNERS = 'SET_DESIGNERS'
const SET_MAKERS = 'SET_MAKERS'

export const state = () => ({
  designers: null,
  makers: null
})

export const mutations = {
  [SET_DESIGNERS] (state, designers) {
    if (designers.length === 0) return
    state.designers = designers
  },

  [SET_MAKERS] (state, makers) {
    state.makers = makers
  }
}

export const actions = {
  setDesigners ({ commit }, designers) {
    commit(SET_DESIGNERS, designers)
  }
}

export const getters = {
  getDesigners: (state) => () => {
    return state.designers
  },
  getSorting: (state) => () => {
    if (!state.makers || !state.makers.docs) return null
    const makers = JSON.parse(JSON.stringify(state.makers))

    const result = makers.docs.map(el => {
      const item = { ...el }
      item.name = el.name || el.email
      return item
    })

    return result.sort((a, b) => {
      return a.name.toLowerCase().localeCompare(b.name.toLowerCase())
    })
  }
}
