export const INVALID_NAME_ERROR = (name) => new Error(`${name} is invalid name for the collection.`)

export const DELETE_COLLECTION_FAILED = (id) => new Error(`Deleting collection with id=${id} has failed.`)

export const CREATE_COLLECTION_FAILED = (name) => new Error(`Creating collection with name=${name} has failed.`)

export const UPDATE_COLLECTION_FAILED = (id) => new Error(`Updating collection with id=${id} has failed.`)

export const OPEN_COLLECTION_FAILED = (id) => new Error(`Opening collection with id=${id} has failed.`)

export const ADD_ICON_TO_COLLECTION_FAILED = (collectionId, iconId) => {
  return new Error(`Adding icon with id=${iconId} to collection with id=${collectionId} has failed.`)
}

export const UPDATE_ICON_IN_COLLECTION_FAILED = (collectionId, iconId) => {
  return new Error(`Updating icon with id=${iconId} to collection with id=${collectionId} has failed.`)
}

export const DELETE_ICON_FROM_COLLECTION_FAILED = (collectionId, iconId) => {
  return new Error(`Delete icon with id=${iconId} from collection with id=${collectionId} has failed.`)
}

export const GET_COLLECTIONS_FAILED = new Error('Loading collections has failed.')

export const COLLECTION_IS_FULL = new Error('Collection is full.')
