import {COLOR_EMPTY} from "@/constants";

export const ICONS_LIMIT = 1000
export const DOWNLOADED_COLLECTION_NAME = 'Downloaded'
export const FAVORITES_COLLECTION_NAME = 'Favorites'
export const PROHIBITED_COLLECTION_NAMES = [
  DOWNLOADED_COLLECTION_NAME,
  FAVORITES_COLLECTION_NAME
]

export const defaultState = {
  collections: [],
  areCollectionsLoaded: false,
  areCollectionsLoading: false,
  simulatedDeletedCollectionId: null,
  openCollectionId: null,
  color: COLOR_EMPTY,
  alreadyDownloadedIconsIds: [],
  downloadErrors: [],
  downloadProgress: 0
}
