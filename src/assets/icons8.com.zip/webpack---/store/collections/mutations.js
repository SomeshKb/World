import * as types from './_mutationTypes'
import { updateIconInCollection, updateIconsList } from './_helpers'

export default {
  /**
   * @param state
   * @param {boolean} areCollectionsLoading
   */
  [types.SET_ARE_COLLECTIONS_LOADING] (state, areCollectionsLoading) {
    state.areCollectionsLoading = areCollectionsLoading
  },

  /**
   * @param state
   * @param {boolean} areCollectionsLoaded
   */
  [types.SET_ARE_COLLECTIONS_LOADED] (state, areCollectionsLoaded) {
    state.areCollectionsLoaded = areCollectionsLoaded
  },

  /**
   * @param state
   * @param {Object[]} collections
   */
  [types.SET_COLLECTIONS] (state, collections) {
    state.collections = collections
  },

  /**
   * @param state
   * @param {number|string} collectionId
   * @param {boolean} value
   */
  [types.SET_IS_COLLECTION_LOADING] (state, { collectionId, value }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return {
        ...el,
        loading: value
      }
    })
  },

  /**
   * @param state
   * @param {number|string} collectionId
   * @param {Object} newCollection
   */
  [types.SET_COLLECTION_BY_ID] (state, { collectionId, newCollection }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return {
        ...el,
        ...newCollection
      }
    })
  },


  [types.SET_SIMULATED_DELETED_COLLECTION_ID] (state, id) {
    state.simulatedDeletedCollectionId = id
  },

  /**
   * @param state
   * @param {number|string} id
   */
  [types.SET_OPEN_COLLECTION_ID] (state, id) {
    state.openCollectionId = id
  },

  /**
   * @param state
   * @param {Array<number|string>} ids
   */
  [types.SET_ALREADY_DOWNLOADED_ICONS_IDS] (state, ids) {
    state.alreadyDownloadedIconsIds = ids
  },

  // following mutations are mainly used for beautiful addition of icons.
  /**
   * TODO: refactor in terms of ADD_ICONS_TO_COLLECTION
   * @param state
   * @param {number|string} collectionId
   * @param {Object} icon
   */
  [types.ADD_ICON_TO_COLLECTION] (state, { collectionId, icon }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return {
        ...el,
        icons: [...el.icons, {
          id: icon.id,
          name: icon.name,
          isFree: icon.free,
          url: icon.url
        }],
        iconsTotal: el.iconsTotal + 1
      }
    })
  },

  /**
   * Add multiple icons to collection
   * @param state
   * @param collectionId
   * @param icons
   */
  [types.ADD_ICONS_TO_COLLECTION] (state, { collectionId, icons }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return {
        ...el,
        icons: [...el.icons, ...icons],
        iconsTotal: el.iconsTotal + icons.length
      }
    })
  },

  [types.UPDATE_ICON_IN_COLLECTION] (state, { collectionId, icon, data }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return updateIconInCollection(el, icon, data)
    })
  },

  /**
   * Update list of icons in collection.
   * If some icon is not already in collection, performs nothing.
   * @param state
   * @param collectionId
   * @param icons
   */
  [types.UPDATE_ICONS_IN_COLLECTION] (state, { collectionId, icons }) {
    state.collections = state.collections.map(el => {
      if (el.id !== collectionId) { return el }
      return {
        ...el,
        icons: updateIconsList(el.icons, icons)
      }
    })
  },

  /**
   * @param state
   * @param {string|number} collectionId
   * @param {(string|number)[]} iconIds
   */
  [types.REMOVE_ICON_FROM_COLLECTION] (state, { collectionId, iconIds }) {
    state.collections = state.collections.map(collection => {
      if (collection.id !== collectionId) { return collection }
      const filteredIcons = collection.icons.filter(icon => !iconIds.includes(icon.id))
      return {
        ...collection,
        icons: filteredIcons,
        iconsTotal: collection.iconsTotal
          ? collection.iconsTotal - iconIds.length
          : filteredIcons.length
      }
    })
  },

  [types.SET_COLOR] (state, { color }) {
    state.color = color
  },

  [types.ADD_DOWNLOAD_ERROR] (state, error) {
    state.downloadErrors = [...state.downloadErrors, error]
  },

  [types.INCREMENT_PROGRESS] (state) {
    state.downloadProgress += 1
  },

  [types.RESET_DOWNLOAD_PROCESS] (state) {
    state.downloadProgress = 0
    state.downloadErrors = []
  }
}
