import { DOWNLOADED_COLLECTION_NAME } from './_constants'

export default {
  /**
   * @param state
   * @returns {function(number|string): {}|undefined}
   */
  getCollectionById: (state) => (id) => state.collections.find(el => el.id === id),

  /**
   * Return collection of downloaded icons.
   * If there is no collection with `isDownloaded` field,
   * return collection with DOWNLOADED_COLLECTION_NAME.
   * @param state
   * @returns {{}|undefined}
   */
  getDownloadedCollection: (state) => {
    return state.collections.find(el => el.isDownloaded) ||
      state.collections.find(el => el.name === DOWNLOADED_COLLECTION_NAME)
  },

  /**
   * @param state
   * @returns {{}|undefined}
   */
  getDefaultCollection: (state) => state.collections.find(el => el.isDefault),

  /**
   * Get currently open in menu collection.
   * @param state
   * @returns {*}
   */
  getOpenCollection: (state) => (
    state.collections.find(el => el.id === state.openCollectionId)
  ),

  /**
   * As icon can be added before any action on collections was performed,
   * we provide user with a default collection to which he can add icons
   * not even knowing about the collection itself.
   * @param state
   * @param getters
   * @returns {{}}
   */
  getCurrentCollection: (state, getters) => (
    getters.getOpenCollection || getters.getPinnedCollection
  ),

  /**
   * Check if given icon is in current collection
   * @param state
   * @param getters
   * @returns {function (icon: Object): Boolean}
   */
  isIconInCollection: (state, getters) => (icon) => {
    if (!icon) { return true }
    const collection = getters.getCurrentCollection
    if (collection?.icons) {
      return collection.icons.some(el => el.id === icon.id && !icon.user_icon_id)
    }
    return false
  },
}
