import {
  DOWNLOADED_COLLECTION_NAME,
  FAVORITES_COLLECTION_NAME,
  ICONS_LIMIT,
  PROHIBITED_COLLECTION_NAMES
} from './_constants'

export function canAddIconToCollection (collection) {
  return collection.icons.length < ICONS_LIMIT
}

export function canAddIconsToCollection (collection, icons) {
  return collection.icons.length + icons.length - 1 < ICONS_LIMIT
}

/**
 * Check if icon can be added to collection.
 * @param {Object} icon
 * @returns {*|boolean}
 */
export function isIconValidForCollection (icon) {
  return Boolean(
    (icon.id || icon.name) &&
    (!isUserSourceIcon(icon) || icon.svg)
  )
}

export function isCollectionNameValid (name) {
  return !PROHIBITED_COLLECTION_NAMES.includes(name)
}

export function generateCollectionName (idx) {
  return `Collection ${idx}`
}

export function isCollectionValid (collection) {
  return Boolean(
    isCollectionNameValid(collection.name) ||
    (collection.name === DOWNLOADED_COLLECTION_NAME && collection.isDownloaded) ||
    (collection.name === FAVORITES_COLLECTION_NAME && collection.isDefault)
  )
}

/**
 * Prepare collection to be created.
 * This step is needed to prevent errors regarding absence of required fields.
 * @param draft
 * @param collectionsLength
 * @returns {{name: (*|string)}}
 */
export function prepareCollectionForCreation (draft, collectionsLength) {
  return {
    ...draft,
    name: draft.name || generateCollectionName(collectionsLength + 1)
  }
}

/**
 * Update icon with given id in given collection.
 * @param {{icons: Object[]}} collection
 * @param {object} icon
 * @param {Object} iconData
 * @returns {{icons: Object[]}}
 */
export function updateIconInCollection (collection, icon, iconData) {
  return {
    ...collection,
    icons: collection.icons.map(el => {
      if (!iconEq(el, icon)) { return el }
      return {
        ...el,
        ...iconData
      }
    })
  }
}

export const isUserSourceIcon = (icon) => icon.isUserSource

const nonUserSourceIconEq = (left, right) => left.id === right.id

const userSourceIconEq = (left, right) => {
  return (
    (left.id && right.id && left.id === right.id) ||
    (left.name === right.name) ||
    (left.svg && right.svg && left.svg === right.svg)
  )
}

export function iconEq (left, right) {
  if (isUserSourceIcon(left) && isUserSourceIcon(right)) {
    return userSourceIconEq(left, right)
  }
  return nonUserSourceIconEq(left, right)
}

export function updateIconsList (currentIcons, newIcons) {
  return currentIcons.map(icon => {
    const newData = newIcons.find(el => iconEq(el, icon))
    return newData || icon
  })
}

export function isSystemCollection (collection) {
  return collection.isDefault || collection.isDownloaded
}

export function translateCollectionName (vm, collection) {
  if (collection.isDefault) {
    return vm.$t('COLLECTIONS.FAVORITES')
  }
  if (collection.isDownloaded) {
    return vm.$t('COLLECTIONS.DOWNLOADED')
  }
  return collection.name
}
