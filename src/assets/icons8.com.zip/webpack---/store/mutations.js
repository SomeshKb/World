'use strict'

import { normalizeValue } from '@icons8/frontend-utils'
import * as types from './mutation-types'

export default {
  [types.SERVER_FAILED] (state, serverError) {
    state.serverError = serverError
  },
  [types.API_FAILED] (state, apiError) {
    state.apiError = apiError
  },
  [types.APP_INFO_LOADED] (state, appInfo) {
    state.appInfo = appInfo
    state.appInfo.packs.forEach(pack => {
      pack.code = normalizeValue(pack.code)
    })
  },
  [types.PLATFORM_CHANGED] (state, platformCode) {
    state.platform = state.appInfo.platforms[platformCode]
    if (!state.platform) {
      Object.keys(state.appInfo.platforms).some(key => {
        const platform = state.appInfo.platforms[key]
        if (platform.seoCode === platformCode) {
          state.platform = platform
          platformCode = platform.apiCode
          return true
        }
      })
    }
    if (!state.platform) {
      state.platform = { }
    }
  },
  [types.PACK_CHANGED] (state, packCode) {
    packCode = normalizeValue(packCode)
    const packs = state.appInfo.packs

    let currentPack = packs.find(pack => pack.code === packCode)
    if (!currentPack) {
      currentPack = packs.find(pack => pack.code === 'free-icons')
    }
    state.pack = currentPack
  },
  [types.SEO_PACK_CHANGED] (state, packCode) {
    packCode = normalizeValue(packCode)
    state.seoPack = state.appInfo.seoPacks.find(pack => pack.code === packCode)
  },
  [types.SEARCH_COLOR_CHANGED] (state, color) {
    state.color = color
  },
  [types.SEARCH_SHAPE_CHANGED] (state, shape) {
    state.shape = shape
  },
  [types.SET_SEARCH_MAIN] (state, search) {
    state.mainSearch = search
  },

  // around app ui
  [types.CORNER_AD_SHOWN] (state) {
    state.ui.cornerAd = true
  },
  [types.CORNER_AD_HIDDEN] (state) {
    state.ui.cornerAd = false
  },
  [types.FALLBACK_AD_SHOWN] (state) {
    state.ui.fallbackAd = true
  },
  [types.SET_SIDEBAR_CHAPTER] (state, chapter) {
    state.ui.sidebarChapter = chapter
  },

  // filters
  [types.SET_FILTER_COLOR] (state, color) {
    state.filters.color = color
  },

  [types.SET_FILTER_COLOR_GRADIENT] (state, color) {
    state.filters.colorGradient = color
  },

  [types.SET_FILTER_IS_ANIMATED] (state, isAnimated) {
    state.filters.isAnimated = isAnimated
  },
  [types.SET_FILTER_AUTHORS] (state, authors) {
    state.filters.authors = authors
  },

  // platform filter
  [types.CHOOSE_PLATFORMS_STRING] (state, selectedPlatforms) {
    state.selectedPlatforms.string = selectedPlatforms
  },

  [types.FILL_PLATFORMS_ARRAY] (state, platforms) {
    Object.keys(platforms).map(pl => {
      const platform = platforms[pl] || {}
      if (platform.apiCode !== 'all') {
        state.selectedPlatforms.array.push(platform.seoCode)
      }
    })
  },

  [types.UPDATE_PLATFORMS_ARRAY] (state, newPlatformArray) {
    state.selectedPlatforms.array = newPlatformArray.slice()
  },

  [types.SET_PLATFORMS_LIST_LENGTH] (state, length) {
    state.fullPlatformList.length = length
  },

  // around sidebars
  [types.IS_CONTENT_LOADED] (state, payload) {
    state.ui.isContentLoaded = payload
  },
  [types.IS_PAGE_LOADED] (state, payload) {
    state.ui.isPageLoaded = payload
  },
  [types.IS_PAGE_LOADING] (state, payload) {
    state.ui.isPageLoading = payload
  },
  [types.LEFT_SIDEBAR_ENABLED] (state) {
    state.ui.sidebars.left.enabled = true
  },
  [types.LEFT_SIDEBAR_DISABLED] (state) {
    state.ui.sidebars.left.enabled = false
  },
  [types.LEFT_SIDEBAR_SHOWN] (state) {
    state.ui.sidebars.left.active = true
  },
  [types.LEFT_SIDEBAR_HIDDEN] (state) {
    state.ui.sidebars.left.active = false
  },
  [types.RIGHT_SIDEBAR_ENABLED] (state) {
    state.ui.sidebars.right.enabled = true
  },
  [types.RIGHT_SIDEBAR_DISABLED] (state) {
    state.ui.sidebars.right.enabled = false
  },
  [types.RIGHT_SIDEBAR_SHOWN] (state) {
    state.ui.sidebars.right.active = true
  },
  [types.RIGHT_SIDEBAR_HIDDEN] (state) {
    state.ui.sidebars.right.active = false
  },
  [types.MOBILE_SEARCH_SHOWN] (state) {
    state.ui.mobileSearchActive = true
  },
  [types.MOBILE_SEARCH_HIDDEN] (state) {
    state.ui.mobileSearchActive = false
  },
  [types.SELECT_PLATFORM_CHANGED] (state) {
    state.ui.selectPlatformChanged = true
  },
  [types.SELECT_PLATFORM_RESET] (state) {
    state.ui.selectPlatformChanged = false
  },
  [types.LINK_COPY_BAR_SHOWN] (state) {
    if (state.ui.linkCopyBar.needShow) {
      state.ui.linkCopyBar.active = true
    }
  },
  [types.LINK_COPY_BAR_HIDDEN] (state) {
    state.ui.linkCopyBar.active = false
  },
  [types.LINK_COPY_BAR_SET_NEEDSHOW] (state, needShow) {
    state.ui.linkCopyBar.needShow = needShow
  },
  [types.LINK_COPY_BAR_SET_LINKTEXT] (state, linkText) {
    state.ui.linkCopyBar.linkText = linkText
  },
  [types.TOGGLE_MOBILE_FILTER] (state, isOpen) {
    state.ui.mobileFilterActive = isOpen
    document?.body?.classList?.toggle('mobile-filter-active', isOpen)
  }
}
