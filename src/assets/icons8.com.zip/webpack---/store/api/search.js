'use strict'

import { search } from '@/api/search'

export default function searchVuex (
  { rootState },
  {
    term,
    platform = rootState.platform ? rootState.platform.apiCode : 'all',
    page = 1,
    amount = 60,
    language = this.$i18n.localeProperties.iso,
    options = {},
    isAnimated = undefined,
    authors = 'all',
    isColor
  } = {}
) {
  return search({
    term,
    platform,
    page,
    amount,
    language,
    options,
    isAnimated,
    authors,
    isColor,
  })
}
