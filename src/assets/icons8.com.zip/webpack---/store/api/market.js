'use strict'

import axios from '../../plugins/axios'

export function getAuthor({ rootState }, { authorId = '' } = {}) {
  const url = `/siteApi/market/demo/authors/${authorId}`
  const params = {
    authorId
  }
  const headers = {
    Authorization: `Bearer ${rootState.auth.user.authToken}`
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params,
    headers
  }).then(response => {
    const result = response.data
    result.authorId = authorId
    return result
  })
}

export function getAuthorPacks({ rootState }, { authorId = '', page = 1, limit = 50 } = {}) {
  const url = `/siteApi/market/demo/packs`
  const params = {
    limit,
    page,
    author: authorId
  }
  const headers = {
    Authorization: `Bearer ${rootState.auth.user.authToken}`
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params,
    headers
  }).then(res => res.data)
}

export function getAuthorPack({ rootState }, { packId = '' } = {}) {
  const url = `/siteApi/market/demo/packs/${packId}`
  const params = {
    // limit: 100,
  }
  const headers = {
    Authorization: `Bearer ${rootState.auth.user.authToken}`
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params,
    headers
  }).then(res => res.data)
}

export function getAuthorPackIcons({ rootState }, { packId = '', page = 1, limit = 50 } = {}) {
  const url = `/siteApi/market/demo/packs/${packId}/icons`
  const params = {
    limit,
    page
  }
  const headers = {
    Authorization: `Bearer ${rootState.auth.user.authToken}`
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params,
    headers
  }).then(res => res.data)
}

export function uploadAuthorIconsArchive({ rootState }, sourceFile) {
  const formData = new FormData()
  formData.append('file', sourceFile)
  return axios.post(
    `${process.env.apiUrl}/siteApi/market/demo/upload/upload`,
    formData,
    {
      headers: {
        'Content-Type': 'multipart/form-data',
        Authorization: `Bearer ${rootState.auth.user.authToken}`
      }
    }
  )
}

export function removeAuthorIconsArchive({ rootState }, archiveId) {
  return axios.post(
    `${process.env.apiUrl}/siteApi/market/demo/upload/cancel`,
    { filename: archiveId },
    {
      headers: {
        Authorization: `Bearer ${rootState.auth.user.authToken}`
      }
    }
  )
}

export function sumbitAuthorIconsArchive({ rootState }, { archiveName = '',  authorId = ''} = {}) {
  return axios.post(
    `${process.env.apiUrl}/siteApi/market/demo/authors/${authorId}/submit`,
    { filename: archiveName },
    {
      headers: {
        Authorization: `Bearer ${rootState.auth.user.authToken}`
      }
    }
  )
}

export function sumbitAuthorIconsPackArchive({ rootState }, { archiveName = '',  packId = ''} = {}) {
  return axios.post(
    `${process.env.apiUrl}/siteApi/market/demo/packs/${packId}/submit`,
    { filename: archiveName },
    {
      headers: {
        Authorization: `Bearer ${rootState.auth.user.authToken}`
      }
    }
  )
}
