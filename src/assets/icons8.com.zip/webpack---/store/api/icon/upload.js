'use strict'

import axios from '../../../plugins/axios'

const api = {
  uploadIcons
}

function uploadIcons (context, allData) {
  const data = allData[0]
  const collectionId = allData[1]
  const token = allData[2]
  const files = allData[3]

  return new Promise(function (resolve, reject) {
    let error = false
    files.forEach(file => {
      if (error) {
        return
      }
      if (!/\.svg$/.test(file.name)) {
        error = true
        reject({message: `File ${file.name} must be SVG.`})
        return
      }
      if (file.size > 102400) {
        error = true
        reject({message: `File ${file.name} must be less then 100 Kb`})
        return
      }
    })
    if (error) {
      return
    }
    axios
      .request({
        url: `/siteApi/icons/collections/${collectionId}/icons`,
        baseURL: process.env.apiUrl,
        method: 'put',
        data,
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
      .then(response => {
        if (response.data.success) {
          const icons = response.data.icons
          // decode svg
          icons.forEach(icon => {
            icon.svg = icon.svg ? atob(icon.svg) : icon.svg
            icon.imported = true
            icon.platform = 'color'
          })
          resolve(icons)
        } else {
          reject({ message: response.data.message || 'Something went wrong' })
        }
      })
      .catch(error => {
        reject(error)
      })
  })
}

export default api
