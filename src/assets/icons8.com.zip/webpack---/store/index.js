'use strict'

import { COLOR_EMPTY } from '@/constants';

export const state = () => ({
  serverError: false,
  apiError: '',
  // it's just default appInfo, real data loaded in nuxtServerInit
  appInfo: {
    apiUrl: '',
    backendUrl: '',
    blogUrl: '',
    version: '0',
    stripePublicKey: '',
    activeLanguages: [],
    iconsCount: 0,
    iconsCounts: {},
    platforms: {},
    packs: [],
    packsPreview: {},
    seoPacks: [],
    seoPacksForCategories: {},
    parseAnalytics: {
      appId: '',
      javascriptKey: '',
      serverURL: ''
    }
  },
  fullPlatformList: {
    length: undefined
  },
  selectedPlatforms: {
    array: [],
    string: ''
  },
  platform: {},
  pack: {},
  seoPack: {},
  color: COLOR_EMPTY,
  filters: {
    isAnimated: undefined,
    authors: undefined,
    colorGradient: undefined,
    color: undefined,
    colorsList: {
      black: {
        title: 'Black',
        code: 'black',
        value: '000000'
      },
      white: {
        title: 'White',
        code: 'white',
        value: 'ffffff'
      },
      blue: {
        title: 'Blue',
        code: 'blue',
        value: '4a90e2'
      },
      red: {
        title: 'Red',
        code: 'red',
        value: 'fa314a'
      },
      green: {
        title: 'Green',
        code: 'green',
        value: '26e07f'
      }
    }
  },
  mainSearch: '',
  ui: {
    isContentLoaded: false,
    isPageLoaded: false,
    isPageLoading: false,
    cornerAd: false,
    fallbackAd: false,
    sidebarChapter: null,
    sidebars: {
      left: {
        enabled: true,
        active: false
      },
      right: {
        enabled: true,
        active: false
      }
    },
    mobileSearchActive: false,
    mobileFilterActive: false,
    selectPlatformChanged: false,
    linkCopyBar: {
      active: false,
      needShow: false,
      linkText: ''
    }
  },
  isFound: null,
})
