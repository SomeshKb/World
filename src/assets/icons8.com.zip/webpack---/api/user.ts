import { AxiosInstance } from 'axios'
import { axiosFactory } from 'icons8-common/src/api/helpers'

type IconId = string | number

export const downloadedIconIds: Record<string, IconId[]> = {
  /*
  user.id: [ iconIds ]
   */
}

const api: AxiosInstance = axiosFactory({
  baseURL: `${process.env.apiUrl}/user/v1`
})

/**
 * Filter those ids, for which corresponding icons were already downloaded by current user
 * TODO: unit testing.
 * @param {Array<string | number>} ids
 * @param {String} userId
 * @return {Promise<Array<string | number>>}
 */
export async function filterDownloadedIconIds (ids: IconId[], userId = undefined) {
  const { data } = await api.get('/paidDownloadIds', {
    params: {
      type: 'iconDownload',
      objectIds: ids.join(',')
    }
  })
  if (userId) {
    if (downloadedIconIds[userId]) {
      downloadedIconIds[userId] = [...downloadedIconIds[userId], ...data.ids]
    } else {
      downloadedIconIds[userId] = data.ids
    }
  }
  return data.ids
}

/**
 * Check if icon with given id was already downloaded by current user
 * TODO: unit testing.
 * @param {string | number} id
 * @param {Object} user
 * @return {Promise<boolean>}
 */
export async function wasIconDownloaded (id: IconId, user = undefined): Promise<boolean> {
  try {
    if (id === undefined) {
      return false
    }
    let ids
    if (user) {
      if (user.isGuest) {
        return false
      }
      if (downloadedIconIds[user.id]?.includes(id)) {
        return true
      }
      ids = await filterDownloadedIconIds([id], user.id)
    } else {
      ids = await filterDownloadedIconIds([id])
    }
    return ids.includes(id)
  } catch (e) {
    console.error('Error checking if icon was downloaded', e)
    return false
  }
}

/**
 * Return ids for those icons from given collection, which were already downloaded by current user.
 * TODO: unit testing.
 * @param {string | number} collectionId
 * @return {Promise<Array<string | number>>}
 */
export async function getDownloadedIconsIdsForCollection (
  collectionId: string | number
): Promise<IconId[]> {
  const { data } = await api.get('/paidDownloadIds', {
    params: {
      type: 'iconDownload',
      collectionId
    }
  })
  return data.ids
}
