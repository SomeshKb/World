import { collectionsLocalStorageAPI } from './localStorageAPI'
import { collectionsServerAPI } from './serverAPI'

export function collectionsService (isGuest) {
  return isGuest
    ? collectionsLocalStorageAPI
    : collectionsServerAPI
}
