export const NO_ICON_IN_COLLECTION = (collectionId, iconId) => {
  return new Error(`There is no icon with id=${iconId} in collection with id=${collectionId}.`)
}

export const NO_SUCH_COLLECTION = (id) => new Error(`There is no collection with id=${id}.`)
