import { api } from '@/plugins/axios'
import {chooseFormat, getDownloadUrl, getHeaders, isFreePurchase} from '@/api/icon/utils'

export async function downloadIconById (id, options, userEmail, apiToken, responseType = 'blob') {
  const { format, size, color, isSimplified, name } = options
  const params = {
    id,
    format: chooseFormat(format, isSimplified),
    size,
    name,
    fromSite: true
  }
  if (color) params.color = color
  if (!isFreePurchase(options.free || options.isFree, size, format)) params.token = apiToken

  return await api.request({
    url: getDownloadUrl(options.free || options.isFree, size, format),
    method: 'GET',
    params,
    responseType,
    headers: getHeaders(userEmail)
  })
}
