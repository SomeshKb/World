import { downloadIconById } from '@/api/icon/download/byId'
import { downloadIconBySVG } from '@/api/icon/download/bySvg'
import { generateIconName, saveAsExt } from '@/api/icon/utils'

export async function downloadAndSaveIcon (icon, options, userEmail, apiToken) {
  const name = generateIconName(icon, options)
  const response = await downloadIcon(icon, options, userEmail, apiToken)
  return await saveAsExt(response.data, name)
}

export async function downloadIcon (icon, options, userEmail, apiToken) {
  const name = generateIconName(icon, options)
  return await download(icon, { ...options, name }, userEmail, apiToken)
}

async function download (icon, options, userEmail, apiToken) {
  if (icon.sfSymbolsSvg) {
    return downloadIconFromSvg(icon.sfSymbolsSvg)
  }
  if (icon.svgEffect) {
    return downloadIconBySVG(icon.svgEffect, options, userEmail, apiToken, icon.id, icon.free || icon.isFree)
  }
  if (icon.svgCurrentResolution) {
    return downloadIconBySVG(icon.svgCurrentResolution, options, userEmail, apiToken, icon.id, icon.free || icon.isFree)
  }
  if (icon.id) {
    return downloadIconById(icon.id, { ...icon, ...options }, userEmail, apiToken)
  }
  return downloadIconBySVG(icon.svg, options, userEmail, apiToken, undefined, icon.free || icon.isFree)
}

function downloadIconFromSvg (svg) {
  const blob = new Blob([svg], { type: 'image/svg+xml' })
  return { data: blob }
}
