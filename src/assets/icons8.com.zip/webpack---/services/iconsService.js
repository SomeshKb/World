import {
  FULL_NAME_MONTH,
  FULL_NAME_DAYS
} from '@/constants'

import { search } from '@/api/search'
import SeoService from '@/services/seoService';
import { searchWithPlatform as SEO } from '@/plugins/seo/search';
import { clearFilterParams } from '@/utils';
import { getGradientColorList } from '@/components/controls/gradient-color-select/GradientHelper'
import {SET_FILTER_COLOR_GRADIENT} from '@/store/mutation-types'

export default class iconsService {
  constructor(store, app, route) {
    this.store = store
    this.app = app
    this.route = route
    this.seoService = new SeoService(store, app)
  }

  // Icons
  async fetchDataIcons(params) {

    const isAnimated = this.store.state.filters.isAnimated
    const authors = this.store.state.filters.authors
    const platform = this.store.state.platform.apiCode
    const platformName = this.store.state.platform.title
    let isColor = this.isColor()

    const queryParams = {
      ...params,
      page: 1,
      platform,
      platformName,
      isAnimated,
      authors,
      isColor
    }

    const locale = this.app.i18n.localeProperties.iso
    const response = await this.getIcons(queryParams, locale)


    if (platform === 'nolan') {
      const [ gradientDefault ] = getGradientColorList()

      const color = {
        end: gradientDefault.end,
        start: gradientDefault.start,
        id: gradientDefault.id
      }

      this.store.commit(SET_FILTER_COLOR_GRADIENT, color)
    }

    if (response.success && response.icons[0]) {
      Object.assign(queryParams, {
        platform: response.icons[0].platform,
        commonName: response.icons[0].commonName
      })
    }

    const iconsCount = response.icons.length
    const isLoadedAll = response.success && response.countAll <= iconsCount
    const isFound = response.success && iconsCount

    const term = clearFilterParams(this.route.params?.term, {
      isAnimated,
      authors: this.store.state.filters.authors,
      color: params.parsedParams?.color
    })

    const isKorean = /[\u3131-\u3162 | \uAC00-\uD7AF]/ugi.test(term)
    const needCanonical = isFound &&
      term.length <= 30 &&
      term.split('-').length <= 2 &&
      !isKorean

    const needHreflang = isFound &&
      term.length <= 30 &&
      term.split('-').length <= 2 &&
      !this.route.fullPath.includes('--static') &&
      !isKorean

    this.seoService.injectIconsSEO(queryParams, needCanonical)

    if (needHreflang) {
      let path = this.route.matched[0]?.path.split(':')[0]

      SEO.translateHreflang({
        app: this.app,
        store: this.store,
        path,
        locales: this.app.i18n.locales,
        routeParams: this.route.params,
        translations: response.searchTranslations
      })
    } else this.store.dispatch('deleteHreflang')

    const content = await this.seoService.injectIconsContent({ ...queryParams, amount: response.countAll })

    return {
      ...response,
      ...content,
      ...params,
      isFound,
      isLoadedAll,
      searchTemplate: 'icons'
    }

  }
  async getNewIcons (params) {
    return await this.store.dispatch('latest', params)
  }
  async getIcons (params, locale) {
    const searchParams = {
      term: params.term,
      platform: params.platform,
      page: params.page,
      isAnimated: params.isAnimated,
      authors: params.authors,
      language: locale,
      isColor: params.isColor,
    }
    return search(searchParams)
  }
  async getIcon (iconId) {

  }
  getIconsByDate (icons) {
    const days = FULL_NAME_DAYS
    const monthNames = FULL_NAME_MONTH
    const iconsByDate = {}

    icons.forEach(icon => {
      const date = humanizeDate(icon.timestamp * 1000)
      iconsByDate[date.date] = iconsByDate[date.date] || []
      iconsByDate[date.date].push(icon)
    })

    function humanizeDate (date) {
      const result = {
        date: '',
        code: ''
      }
      const iconTimestampObject = new Date(date)

      switch (when(date)) {
        case 'today':
          result.date = 'Today'
          result.code = 'today'
          break
        case 'yesterday':
          result.date = 'Yesterday'
          result.code = 'yesterday'
          break
        case 'this_week':
          result.date = days[iconTimestampObject.getDay()]
          result.code = result.date.toLowerCase()
          break
        case 'last_week':
          result.date = 'Last ' + days[iconTimestampObject.getDay()]
          result.code = 'last_' + result.date.toLowerCase()
          break
        case 'this_year':
          result.date = monthNames[iconTimestampObject.getMonth()]
          break
        default:
          result.date = `${
            monthNames[iconTimestampObject.getMonth()]
          } ${iconTimestampObject.getFullYear()}`
      }
      return result
    }
    function when ($date) {
      const oneDay = 86400000
      const $today = Date.now()
      const todayObject = new Date(Date.now())
      const iconTimestampObject = new Date($date)

      // if today
      if ($today - $date <= oneDay) {
        return 'today'

        // if yesterday
      } else if ($today - $date < oneDay * 2) {
        return 'yesterday'

        // if this week
      } else if (Math.ceil(($today - $date) / oneDay) <= todayObject.getDay()) {
        return 'this_week'

        // if last week
      } else if (
        Math.ceil(($today - $date) / oneDay) > todayObject.getDay() &&
        Math.ceil(($today - $date) / oneDay) <= todayObject.getDay() + 7
      ) {
        return 'last_week'

        // if this year
      } else if (todayObject.getFullYear() === iconTimestampObject.getFullYear()) {
        return 'this_year'

        // any other dates
      } else {
        return 'other'
      }
    }

    return iconsByDate

  }

  // Category
  async fetchDataCategory (params) {

    const pack = this.searchCategory(params.term)
    const platform = this.store.state.platform.apiCode
    const platformName = this.store.state.platform.title
    const isAnimated = this.store.state.filters.isAnimated

    if (!pack) return null

    this.store.dispatch('setPack', pack.code)

    const queryParams = {
      ...params,
      page: 1,
      platform,
      platformName,
      pack: pack.code,
      isAnimated
    }

    this.seoService.injectIconsSEO(params, true)

    if (!this.route.fullPath.includes('--static')) {
      let path = this.route.matched[0]?.path.split(':')[0]

      const seoParams = {
        app: this.app,
        store: this.store,
        path,
        locales: this.app.i18n.locales.filter(locale => locale.code !== this.app.i18n.locale),
        routeParams: this.route.params,
        translations: pack.name,
        isPack: true
      }

      SEO.translateHreflang(seoParams)

    } else this.store.dispatch('deleteHreflang')

    let res = {
      isFound: false
    }
    let content = {}
    let isSubcategoryIcons = false

    try {
      res = await this.getCategory(queryParams)
      const iconTotalCnt = res.category?.subcategory?.reduce((acc, subcat) => {
        acc += subcat.icons?.length
        return acc
      }, 0) ?? 0
      isSubcategoryIcons = iconTotalCnt >= 10
      content = await this.seoService.injectIconsContent( queryParams )
    } catch (e) {
      console.error(e)
    }

    return {
      ...res,
      ...params,
      ...content,
      isSubcategoryIcons,
      searchTemplate: 'category',
    }


  }
  async getCategory (params) {
    const paramsPack = {
      pack: params.pack,
      platform: params.platform,
      page: params.page,
      isAnimated: params.isAnimated
    }

    const res = await this.store.dispatch('getPack', paramsPack)
    const isSuccess = res.success
    const isLoaded = !!res && process.server
    const isFound = isSuccess && res.category?.subcategory?.length
    const isLoadedAll = (isLoaded && isSuccess === false)

    return {
      ...res,
      isFound,
      isLoaded,
      isLoadedAll
    }

  }
  searchCategory (term) {
    const query = term.replace(/-/g, ' ') // remove "-" from query (term)
    const preQuery = query.replace(/[/\\^$*+?.()|[\]{}]/g, '')
    const re = new RegExp(`^${preQuery}$`, 'i') // RegExp for searching category name matching
    const lang = this.app.i18n.localeProperties.iso
    const pack = this.store.state.appInfo.packs.find(pack => re.test(pack.name[lang])) // check if query (term) equals category name
    return pack
  }

  // Utils
  isColor() {
    // NEED because store.state.filters.color === 'green'

    let isColor = undefined
    if (!this.store.state.filters.color === false) {
      isColor = false
      return isColor
    }
  }
}

