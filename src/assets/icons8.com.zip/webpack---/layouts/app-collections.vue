<template>
  <div class="app-layouts">
    <app-icons-menu :locale="locale" />
    <div class="app-grid">
      <div class="app-content">
        <LeftSidebar
          :activeCollectionsTab="true"
          :links-in-collections="true"
          :locale="locale"
        />
        <app-page
          :sidebars="sidebars"
          :search-bar="false"
        >
          <nuxt />
          <client-only>
            <app-notify position="bottom" />
          </client-only>
        </app-page>
      </div>
    </div>
  </div>
</template>

<script>
import LeftSidebar from '../components/app/LeftSideBar'

import { mapState, mapActions } from 'vuex'
import { debounce } from '@icons8/frontend-utils'

export default {
  components: {
    LeftSidebar
  },
  head () {
    return {
      ...this.seo,
      bodyAttrs: {
        class: 'flex'
      }
    }
  },
  computed: {
    ...mapState({
      seo: state => state.seo.data,
      appInfo: state => state.appInfo,
      locale: state => state.i18n.locale,
      sidebars: state => state.ui.sidebars,
      rightSidebar: state => state.ui.sidebars.right.active,
      user: state => state.auth.user
    })
  },
  mounted() {
    this.resizeHandler()
    this.debouncedResizeHandler = debounce(() => {
      this.resizeHandler()
    }, 500)
    window.addEventListener('resize', this.debouncedResizeHandler)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.debouncedResizeHandler)
  },
  methods: {
    ...mapActions([
      'disableLeftSidebar',
      'enableLeftSidebar'
    ]),
    resizeHandler () {
      if (window.innerWidth < 980) {
        // 980 is $responsive-app-left-sidebars-new from `~assets/css/breakpoints`
        this.disableLeftSidebar()
      } else {
        this.enableLeftSidebar()
      }
    }
  }
}
</script>
