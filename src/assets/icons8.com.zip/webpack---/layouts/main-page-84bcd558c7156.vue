<template>
  <div class="main-page-layout">
    <nuxt />
    <I8Footer
      id="app-footer"
      footer-name="ICONS8"
      footer-icon="logoIcons"
      :locale="locale"
    />
    <crisp-helper />
  </div>
</template>

<script>
import I8Footer from 'icons8-common/src/components/I8Footer'
import { mapState } from 'vuex'

export default {
  components: {
    I8Footer
  },
  data () {
    return {}
  },
  computed: {
    ...mapState({
      seo: state => state.seo.data,
      locale: state => state.i18n.locale
    })
  },
  head () {
    return {
      ...this.seo
    }
  },
}
</script>

<style lang="scss">
  @import '~assets/css/mixins';
  .main-page-layout {

    font-size: 14px;
    color: #333;
    overflow-x: hidden;
    -webkit-font-smoothing: antialiased;
    @include max(480) {
      overflow-x: hidden;
    }

    p {
      margin: 0 0 15px;
    }

    a {
      text-decoration: none;
    }

    .container {
      max-width: 1040px;
      width: 100%;
      margin: auto;
    }

    .visually-hidden {
      position: absolute !important;
      width: 1px;
      height: 1px;
      padding: 0;
      overflow: hidden;
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      clip-path: inset(50%);
      border: 0;
    }
  }
  .overlay .app-modal {
    .close.is-outside {
      color: #eee;
    }
  }
</style>

<style lang="scss">
@import '~assets/css/mixins';

.main-page-layout {
  --container-width: 1265px;

  h2 {
    text-align: initial;
  }

  @include min(480) {
    footer a {
      font-size: 14px;
    }
  }

  .footer {
    --background: #f7f7f7;
    --container-width: 1265px;
  }
}
</style>
