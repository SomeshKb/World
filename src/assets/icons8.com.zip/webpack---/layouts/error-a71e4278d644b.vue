// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-8b23bcd2]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-8b23bcd2]{display:none!important}}.error-page[data-v-8b23bcd2]{background:#fff;word-spacing:1px;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;text-align:center;position:absolute;width:100%;top:82px;z-index:0;border-top-left-radius:8px;border-top-right-radius:8px}.error-page h1[data-v-8b23bcd2]{font-size:32px;margin-bottom:0}.error-page .not-found-pic[data-v-8b23bcd2]{margin:0 auto;width:170px}.error-page .error-info[data-v-8b23bcd2]{font-size:16px;font-weight:700;color:#4c4c4c}.error-page .container[data-v-8b23bcd2]{display:flex;justify-content:center;align-items:center;flex-direction:column;height:74vh;margin:0 auto;max-width:90%}.error-page .powered[data-v-8b23bcd2]{text-align:center;margin-top:10%}.error-page a[data-v-8b23bcd2]{color:#49a3ff!important}.error-page pre[data-v-8b23bcd2]{border-color:#42b983!important}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
