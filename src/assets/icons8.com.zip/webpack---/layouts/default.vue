<template>
  <div class="app-layouts">
    <app-icons-menu />
    <div class="app-grid">
      <div class="app-content">
        <client-only>
          <OpenedCollectionSidebar />
        </client-only>
        <LeftSidebar :locale="locale" />
        <app-page
          :sidebars="sidebars"
          @clicked="hideSidebars"
        >
          <nuxt />
        </app-page>
      </div>
    </div>
  </div>
</template>

<script>
import LeftSidebar from '../components/app/LeftSideBar'

import { mapState, mapActions } from 'vuex'
import OpenedCollectionSidebar from '../components/collections/OpenedCollectionSidebar'

export default {
  components: {
    LeftSidebar,
    OpenedCollectionSidebar
  },
  head () {
    return {
      ...this.seo,
      bodyAttrs: {
        class: 'flex'
      }
    }
  },
  computed: {
    ...mapState({
      seo: state => state.seo.data,
      appInfo: state => state.appInfo,
      locale: state => state.i18n.locale,
      sidebars: state => state.ui.sidebars,
      rightSidebar: state => state.ui.sidebars.right.active,
      user: state => state.auth.user
    })
  },
  created () {
    this.enableLeftSidebar()
    this.enableRightSidebar()
  },
  methods: {
    ...mapActions([
      'enableLeftSidebar',
      'enableRightSidebar',
      'hideLeftSidebar',
      'hideRightSidebar'
    ]),
    hideSidebars () {
      this.hideLeftSidebar()
      // this.hideRightSidebar()
    }
  }
}
</script>
