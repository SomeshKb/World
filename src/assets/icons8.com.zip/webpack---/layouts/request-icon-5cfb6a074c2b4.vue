import { render, staticRenderFns } from "./request-icon.vue?vue&type=template&id=0c999881&scoped=true&"
import script from "./request-icon.vue?vue&type=script&lang=js&"
export * from "./request-icon.vue?vue&type=script&lang=js&"
import style0 from "./request-icon.vue?vue&type=style&index=0&id=0c999881&prod&lang=scss&"
import style1 from "./request-icon.vue?vue&type=style&index=1&id=0c999881&prod&lang=scss&scoped=true&"
import style2 from "./request-icon.vue?vue&type=style&index=2&id=0c999881&prod&lang=scss&"


/* normalize component */
import normalizer from "!../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "0c999881",
  null
  
)

export default component.exports