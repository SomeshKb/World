<template>
  <div class="app-layouts">
    <app-icons-menu />

    <div class="app-grid">
      <div class="app-content">
        <client-only>
          <OpenedCollectionSidebar />
        </client-only>

        <LeftSidebar />

        <!-- Content -->
        <nuxt />
      </div>

      <client-only>
        <app-notify position="bottom" />
      </client-only>
    </div>
  </div>
</template>

<script>
import LeftSidebar from '../components/app/LeftSideBar'
import OpenedCollectionSidebar from '../components/collections/OpenedCollectionSidebar'

export default {
  components: {
    LeftSidebar,
    OpenedCollectionSidebar
  },

  created () {
    this.$store.dispatch('enableLeftSidebar')
    this.$store.dispatch('enableRightSidebar')
  },

  head () {
    return {
      ...(this.$store.state.seo.data),
      bodyAttrs: {
        class: 'flex'
      }
    }
  }
}
</script>
