import Vue from 'vue'
// import { defineNuxtPlugin, isVue2 } from '#app'
import appModal from 'icons8-common/src/components/appModal'
import appNotify from 'icons8-common/src/components/appNotify'

import AppInfiniteScroll from 'icons8-common/src/components/appInfiniteScroll.vue'
import AppPopup from 'icons8-common/src/components/appPopup.vue'
import AppSelect from 'icons8-common/src/components/appSelect.vue'
import AppVideoPopup from 'icons8-common/src/components/appVideoPopup.vue'

// I have no idea why, but it is needed
import 'icons8-common/src/assets/css/common.scss'

const isVue2 = true // will come from bridge

// export default defineNuxtPlugin((ctx) => {
export default (ctx) => {
  /** @type {import('vue')['default']} */
  const vue = isVue2 ? Vue : ctx.vueApp

  /* Components */
  vue.component('app-infinite-scroll', AppInfiniteScroll)
  vue.component('app-popup', AppPopup)
  vue.component('app-select', AppSelect)
  vue.component('app-video-popup', AppVideoPopup)

  vue.use(appModal)
  vue.use(appNotify)
}
