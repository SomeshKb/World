'use strict'

import LRU from 'lru-cache'
const axios = require('axios')

let appInfoJson = {}
if (process.server) {
  appInfoJson = require('../cache/appInfo.json')
}

const cache = new LRU({
  max: 10000,
  ttl: 1000 * 60 * 60 // 1 hour
})

const $jsonTimestamp = new Date()

async function getAppInfo () {
  let appInfo = cache.get('appInfo')

  if (!appInfo) {
    try {
      const { data } = await axios.request({
        url: '/siteApi/icons-info',
        baseURL: process.env.apiUrl,
        method: 'get'
      })
      if (data.success) {
        appInfo = data
        const date = new Date()
        appInfo.$source = 'api'
        appInfo.$apiTimestamp = date
        appInfo.$cacheTimestamp = date
        cache.set('appInfo', appInfo)
      }
    } catch (error) {}
  }

  if (!appInfo) {
    appInfo = Object.assign({}, appInfoJson)
    appInfo.$source = 'file'
    appInfo.$jsonTimestamp = $jsonTimestamp
    appInfo.$cacheTimestamp = new Date()
    cache.set('appInfo', appInfo)
  }

  return appInfo
}

export default {
  getAppInfo
}
