export default (context) => {
  return new Promise(function (resolve, reject) {
    window.onNuxtReady((nuxt) => {
      window.delayIconGridClickCleanup()
      const event = new CustomEvent('nuxtReady')
      document.dispatchEvent(event)
    })
    if (context.isHMR) {
      resolve()
      return
    }
    resolve()
  })
}
