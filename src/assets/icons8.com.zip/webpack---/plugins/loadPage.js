import * as types from '@/store/mutation-types'
export default ({ store }) => {
  window.addEventListener('load', () => {
    console.log('--- loaded page ---')
    store.commit(types.IS_PAGE_LOADED, true)
  })
}
