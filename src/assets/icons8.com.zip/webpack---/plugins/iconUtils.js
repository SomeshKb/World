'use strict'

// convert to string, lowerCase, replace all spaces and '_' to '-'
// usage example: url params
function normalizeValue (value) {
  return ('' + value)
    .trim()
    .toLowerCase()
    .split(' ')
    .join('-')
    .split('_')
    .join('-')
    .split('/')
    .join('-')
    .split('\\')
    .join('-')
    .split('%')
    .join('-')
}

const isSafari = !process.browser
  ? false
  : navigator.userAgent.indexOf('Safari') !== -1 &&
    navigator.userAgent.indexOf('Chrome') === -1

function saveAsExt (data, fileName) {
  if (window.navigator.msSaveOrOpenBlob) { // Edge
    window.navigator.msSaveOrOpenBlob(data, fileName)
    return
  }
  return new Promise(function (resolve) {
    const fr = new FileReader()
    fr.onloadend = function () {
      const a = document.createElement('a')
      a.download = fileName
      a.href = fr.result
      document.body.appendChild(a)
      a.click()
      a.remove()
      resolve()
    }
    fr.readAsDataURL(data)
  })
}

function downloadUrl (url, filename) {
  if (isSafari) {
    const iframe = document.createElement('iframe')
    iframe.setAttribute('width', '1')
    iframe.setAttribute('height', '1')
    iframe.setAttribute('frameborder', '0')
    iframe.setAttribute('src', url)

    document.body.appendChild(iframe)
    return true
  } else {
    const a = document.createElement('a')
    a.href = url
    a.setAttribute('target', '_blank')
    if (a.download !== undefined) {
      // Set HTML5 download attribute. This will prevent file from opening if supported.
      a.download = filename
    }
    // a.style.display = 'none'

    document.body.appendChild(a)

    if (document.createEvent) {
      const e = document.createEvent('MouseEvents')
      e.initEvent('click', true, true)
      a.dispatchEvent(e)
      return true
    } else {
      a.click()
    }

    return true
  }
}

function getSVGNode (svg) {
  if (svg) {
    svg = svg.substr(svg.indexOf('<svg'))
  } else {
    return
  }
  const container = document.createElement('div')
  container.insertAdjacentHTML('afterbegin', svg)
  return container.childNodes[0]
}

function getSVGData (svg, options) {
  const $svg = getSVGNode(svg)
  if (!$svg) {
    return
  }
  $svg.setAttribute('width', options.size)
  $svg.setAttribute('height', options.size)
  $svg.setAttribute('fill', options.color)

  return new XMLSerializer().serializeToString($svg)
}

function getIconUrl (icon) {
  if (!icon) { return '/icon' }
  if (icon.url) { return icon.url }
  const name = decodeURIComponent(normalizeValue(icon.commonName))
    .replace('%25', '')
  return `/icon/${icon.id}/${name}`
}

function getPackUrl (category) {
  const pack = encodeURIComponent(normalizeValue(category))
  return `/icon/set/${pack}`
}

const locales = {
  'zh-CN': {
    name: '繁體中文',
    url: 'https://icons8.cn',
    icon: require('../assets/icons/locale/zh-CN.png'),
    countries: ['CN', 'TW'],
    locale: 'zh-CN',
    code: 'zh',
    apiUrl: 'https://api.icons8.cn'
  },
  'en-US': {
    name: 'English',
    url: 'https://icons8.com',
    icon: require('../assets/icons/locale/en-US.png'),
    countries: ['US', 'GB', 'CA', 'AU', 'NZ', 'IE'],
    locale: 'en-US',
    code: 'en',
    apiUrl: 'https://api.icons8.com'
  },
  'fr-FR': {
    name: 'Français',
    url: 'https://icones8.fr',
    icon: require('../assets/icons/locale/fr-FR.png'),
    countries: ['FR', 'BE', 'LU', 'BJ', 'MA', 'MD', 'TN', 'CM'],
    locale: 'fr-FR',
    code: 'fr',
    apiUrl: 'https://api.icones8.fr'
  },
  'de-DE': {
    name: 'Deutsch',
    url: 'https://icons8.de',
    icon: require('../assets/icons/locale/de-DE.png'),
    countries: ['DE', 'AT', 'CH', 'LI'],
    locale: 'de-DE',
    code: 'de',
    apiUrl: 'https://api.icons8.de'
  },
  'it-IT': {
    name: 'Italiano',
    url: 'https://it.icons8.com',
    icon: require('../assets/icons/locale/it-IT.png'),
    countries: ['IT', 'SM'],
    locale: 'it-IT',
    code: 'it',
    apiUrl: 'https://api.icons8.it'
  },
  'ja-JP': {
    name: '日本語',
    url: 'https://icons8.jp',
    icon: require('../assets/icons/locale/ja-JP.png'),
    countries: ['JP'],
    locale: 'ja-JP',
    code: 'ja',
    apiUrl: 'https://api.icons8.jp'
  },
  'pt-BR': {
    name: 'Português',
    url: 'https://icons8.com.br',
    icon: require('../assets/icons/locale/pt-BR.png'),
    countries: ['PT', 'BR'],
    locale: 'pt-BR',
    code: 'pt',
    apiUrl: 'https://api.icons8.com.br'
  },
  'ru-RU': {
    name: 'Русский',
    url: 'https://icons8.ru',
    icon: require('../assets/icons/locale/ru-RU.png'),
    countries: ['UA', 'RU', 'BY', 'KZ'],
    locale: 'ru-RU',
    code: 'ru',
    apiUrl: 'https://api.icons8.ru'
  },
  'es-ES': {
    name: 'Español',
    url: 'https://iconos8.es',
    icon: require('../assets/icons/locale/es-ES.png'),
    countries: ['AR', 'ES', 'MX', 'CO', 'CL', 'BO'],
    locale: 'es-ES',
    code: 'es',
    apiUrl: 'https://api.iconos8.es'
  },
  'ko-KR': {
    name: '한국어',
    url: 'https://icons8.kr',
    icon: require('../assets/icons/locale/ko-KR.png'),
    countries: ['KR'],
    locale: 'ko-KR',
    code: 'ko'
  }
}

function detectLanguage (req) {
  // req is undefined when we use nuxt generate
  if (!req) {
    return locales['en-US']
  }
  if (req.url.indexOf('crowdin-overlay') >= 0) {
    return {
      ...locales['en-US'],
      locale: 'zu-ZA'
    }
  }
  const hostname = req.hostname || req.headers.host
  const origin = `https://${hostname}`
  const languages = locales
  let locale
  if (
    !(
      process.env.NODE_ENV === 'production' ||
      process.env.NODE_ENV === 'dev' ||
      process.env.NODE_ENV === 'pre'
    )
  ) {
    const isRu = hostname.indexOf('.ru')
    const isIt = hostname.indexOf('.it')
    const isDe = hostname.indexOf('.de')
    if (isRu > 0) {
      locale = 'ru-RU'
    }
    if (isIt > 0) {
      locale = 'it-IT'
    }
    if (isDe > 0) {
      locale = 'de-DE'
    }
  }
  const languageList = Object.values(languages)
  let lang = languageList.find(language => language.url === origin)
  if (!lang) {
    locale = locale || process.env.language
    lang = languageList.find(language => language.locale === locale)
  }
  if (!lang) {
    lang = languages['en-US']
  }
  return lang
}

function UniqueNames () {
  this.names = {}

  this.getName = function (name) {
    let newName = name
    const counter = this.names[name] || 1
    if (counter > 1) {
      newName = `${name}-${counter}`
    }
    this.names[name] = counter + 1
    return newName
  }
}

function getCookie (name) {
  const nameEQ = name + '='
  const ca = document.cookie.split(';')
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i]
    while (c.charAt(0) === ' ') c = c.substring(1, c.length)
    if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
  }
  return null
}

function parseServerCookies (request) {
  const rc = request.headers.cookie
  if (rc) {
    return rc.split(';').reduce((accum, cookie) => {
      const parts = cookie.split('=')
      accum[parts.shift().trim()] = decodeURI(parts.join('='))
      return accum
    }, {})
  }
  return {}
}

/*
 * abbrNumber(1000, 0) => 1K
 * @param {number} number - число
 * @param {number} decFixed - кол-во цифр после точки
 */
function abbrNumber (number, decFixed = 0) {
  const abbrev = ['k', 'm', 'b', 't']
  decFixed = Math.pow(10, decFixed)

  for (let i = abbrev.length - 1; i >= 0; i--) {
    const size = Math.pow(10, (i + 1) * 3)
    if (size <= number) {
      number = Math.round(number * decFixed / size) / decFixed

      if ((number === 1000) && (i < abbrev.length - 1)) {
        number = 1
        i++
      }
      number += abbrev[i]
      break
    }
  }
  return number
}

export default {
  normalizeValue,
  saveAsExt,
  downloadUrl, // useless
  getSVGNode,
  getSVGData, // useless
  getIconUrl,
  getPackUrl,
  locales,
  detectLanguage, // useless
  UniqueNames,
  getCookie,
  parseServerCookies,
  abbrNumber
}
