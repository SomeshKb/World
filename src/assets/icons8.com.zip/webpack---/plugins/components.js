import Vue from 'vue'
import VueClipboard from 'vue-clipboard2'

import Vue2TouchEvents from 'vue2-touch-events'

import appIconsMenu from '@/components/app/appIconsMenu'
import appHeader from '@/components/app/appHeader'
import AppBottomInfo from '@/components/app/AppBottomInfo'
import appIcon from '@/components/icon/appIcon'
import iconTags from '@/components/icon/iconTags'
import appIconLogo from '@/components/app/appIconLogo'
import iconGrid from '@/components/grid/iconGrid'
import appPage from '@/components/app/appPage'
import IconPlaceholder from '@/components/app/iconPlaceholder'
import crispHelper from '@/components/app/crispHelper'

import Ripple from './ripple'

export default ({ store }) => {
  Vue.component('app-icons-menu', appIconsMenu)
  Vue.component('app-header', appHeader)
  Vue.component('app-bottom-info', AppBottomInfo)
  Vue.component('app-page', appPage)
  Vue.component('app-icon', appIcon)
  Vue.component('icon-tags', iconTags)
  Vue.component('app-icon-logo', appIconLogo)
  Vue.component('icon-grid', iconGrid)
  Vue.component('iconPlaceholder', IconPlaceholder)
  Vue.component('crisp-helper', crispHelper)

  Vue.use(Vue2TouchEvents)
  Vue.use(VueClipboard)

  Vue.directive('ripple', Ripple)
}
