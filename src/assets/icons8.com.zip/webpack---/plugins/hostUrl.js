export default (function (ctx, inject) {
  inject('hostUrl', process.server ? "https://".concat(ctx.req.headers.host) : "https://".concat(window.location.host));
});