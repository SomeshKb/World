import Vue from 'vue'
import VueMask from 'v-mask'

import { REGEX_IS_HEX } from '@/constants'

Vue.use(VueMask, {
  placeholders: {
    '#': null,
    '*': REGEX_IS_HEX,
  }
})

Vue.directive('uppercase', {
  update: function (el) {
    el.value = el.value.toUpperCase()
  }
})
