import _asyncToGenerator from "@babel/runtime/helpers/esm/asyncToGenerator";
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }
import "core-js/modules/es.array.map.js";
import "core-js/modules/es.object.to-string.js";
import "core-js/modules/es.string.iterator.js";
import "core-js/modules/web.dom-collections.iterator.js";
import "core-js/modules/es.array.slice.js";
import "core-js/modules/es.function.name.js";
import "core-js/modules/es.array.from.js";
import "core-js/modules/es.regexp.exec.js";
import "core-js/modules/es.symbol.js";
import "core-js/modules/es.symbol.description.js";
import "core-js/modules/es.symbol.iterator.js";
import "regenerator-runtime/runtime.js";
import Vue from 'vue';
import { getMatchedComponentsInstances, getChildrenComponentInstancesUsingFetch, promisify, globalHandleError, sanitizeComponent } from './utils';
import NuxtError from '../layouts/error.vue';
import NuxtLoading from './components/nuxt-loading.vue';
import '../node_modules/normalize-css/normalize.css';
import _8f145d9a from '../layouts/app-collections.vue';
import _3b673696 from '../layouts/app-landing.vue';
import _1a3ae26b from '../layouts/app.vue';
import _6f6c098b from '../layouts/default.vue';
import _e7409a26 from '../layouts/main-page.vue';
import _13fef7ed from '../layouts/request-icon.vue';
import _781747a5 from '../layouts/tools.vue';
var layouts = {
  "_app-collections": sanitizeComponent(_8f145d9a),
  "_app-landing": sanitizeComponent(_3b673696),
  "_app": sanitizeComponent(_1a3ae26b),
  "_default": sanitizeComponent(_6f6c098b),
  "_main-page": sanitizeComponent(_e7409a26),
  "_request-icon": sanitizeComponent(_13fef7ed),
  "_tools": sanitizeComponent(_781747a5)
};
export default {
  render: function render(h, props) {
    var loadingEl = h('NuxtLoading', {
      ref: 'loading'
    });
    var layoutEl = h(this.layout || 'nuxt');
    var templateEl = h('div', {
      domProps: {
        id: '__layout'
      },
      key: this.layoutName
    }, [layoutEl]);
    var transitionEl = h('transition', {
      props: {
        name: 'layout',
        mode: 'out-in'
      },
      on: {
        beforeEnter: function beforeEnter(el) {
          // Ensure to trigger scroll event after calling scrollBehavior
          window.$nuxt.$nextTick(function () {
            window.$nuxt.$emit('triggerScroll');
          });
        }
      }
    }, [templateEl]);
    return h('div', {
      domProps: {
        id: '__nuxt'
      }
    }, [loadingEl, transitionEl]);
  },
  data: function data() {
    return {
      isOnline: true,
      layout: null,
      layoutName: '',
      nbFetching: 0
    };
  },
  beforeCreate: function beforeCreate() {
    Vue.util.defineReactive(this, 'nuxt', this.$options.nuxt);
  },
  created: function created() {
    // Add this.$nuxt in child instances
    this.$root.$options.$nuxt = this;
    if (process.client) {
      // add to window so we can listen when ready
      window.$nuxt = this;
      this.refreshOnlineStatus();
      // Setup the listeners
      window.addEventListener('online', this.refreshOnlineStatus);
      window.addEventListener('offline', this.refreshOnlineStatus);
    }
    // Add $nuxt.error()
    this.error = this.nuxt.error;
    // Add $nuxt.context
    this.context = this.$options.context;
  },
  mounted: function mounted() {
    var _this = this;
    return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
      return regeneratorRuntime.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _this.$loading = _this.$refs.loading;
            case 1:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }))();
  },
  watch: {
    'nuxt.err': 'errorChanged'
  },
  computed: {
    isOffline: function isOffline() {
      return !this.isOnline;
    },
    isFetching: function isFetching() {
      return this.nbFetching > 0;
    }
  },
  methods: {
    refreshOnlineStatus: function refreshOnlineStatus() {
      if (process.client) {
        if (typeof window.navigator.onLine === 'undefined') {
          // If the browser doesn't support connection status reports
          // assume that we are online because most apps' only react
          // when they now that the connection has been interrupted
          this.isOnline = true;
        } else {
          this.isOnline = window.navigator.onLine;
        }
      }
    },
    refresh: function refresh() {
      var _this2 = this;
      return _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
        var pages, promises;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                pages = getMatchedComponentsInstances(_this2.$route);
                if (pages.length) {
                  _context3.next = 3;
                  break;
                }
                return _context3.abrupt("return");
              case 3:
                _this2.$loading.start();
                promises = pages.map( /*#__PURE__*/function () {
                  var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(page) {
                    var p, _iterator, _step, component;
                    return regeneratorRuntime.wrap(function _callee2$(_context2) {
                      while (1) {
                        switch (_context2.prev = _context2.next) {
                          case 0:
                            p = []; // Old fetch
                            if (page.$options.fetch && page.$options.fetch.length) {
                              p.push(promisify(page.$options.fetch, _this2.context));
                            }
                            if (page.$options.asyncData) {
                              p.push(promisify(page.$options.asyncData, _this2.context).then(function (newData) {
                                for (var key in newData) {
                                  Vue.set(page.$data, key, newData[key]);
                                }
                              }));
                            }

                            // Wait for asyncData & old fetch to finish
                            _context2.next = 5;
                            return Promise.all(p);
                          case 5:
                            // Cleanup refs
                            p = [];
                            if (page.$fetch) {
                              p.push(page.$fetch());
                            }
                            // Get all component instance to call $fetch
                            _iterator = _createForOfIteratorHelper(getChildrenComponentInstancesUsingFetch(page.$vnode.componentInstance));
                            try {
                              for (_iterator.s(); !(_step = _iterator.n()).done;) {
                                component = _step.value;
                                p.push(component.$fetch());
                              }
                            } catch (err) {
                              _iterator.e(err);
                            } finally {
                              _iterator.f();
                            }
                            return _context2.abrupt("return", Promise.all(p));
                          case 10:
                          case "end":
                            return _context2.stop();
                        }
                      }
                    }, _callee2);
                  }));
                  return function (_x) {
                    return _ref.apply(this, arguments);
                  };
                }());
                _context3.prev = 5;
                _context3.next = 8;
                return Promise.all(promises);
              case 8:
                _context3.next = 15;
                break;
              case 10:
                _context3.prev = 10;
                _context3.t0 = _context3["catch"](5);
                _this2.$loading.fail(_context3.t0);
                globalHandleError(_context3.t0);
                _this2.error(_context3.t0);
              case 15:
                _this2.$loading.finish();
              case 16:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[5, 10]]);
      }))();
    },
    errorChanged: function errorChanged() {
      if (this.nuxt.err) {
        if (this.$loading) {
          if (this.$loading.fail) {
            this.$loading.fail(this.nuxt.err);
          }
          if (this.$loading.finish) {
            this.$loading.finish();
          }
        }
        var errorLayout = (NuxtError.options || NuxtError).layout;
        if (typeof errorLayout === 'function') {
          errorLayout = errorLayout(this.context);
        }
        this.setLayout(errorLayout);
      }
    },
    setLayout: function setLayout(layout) {
      if (!layout || !layouts['_' + layout]) {
        layout = 'default';
      }
      this.layoutName = layout;
      this.layout = layouts['_' + layout];
      return this.layout;
    },
    loadLayout: function loadLayout(layout) {
      if (!layout || !layouts['_' + layout]) {
        layout = 'default';
      }
      return Promise.resolve(layouts['_' + layout]);
    }
  },
  components: {
    NuxtLoading: NuxtLoading
  }
};