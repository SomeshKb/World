'use strict';

import "core-js/modules/es.function.name.js";
export default (function (_ref, inject) {
  var app = _ref.app;
  if (!process.browser) return;

  // Этот плагин выполняет роль заглушки, и заменяет vue-analytics
  // https://matteogabriele.gitbooks.io/vue-analytics/content/docs/event-tracking.html
  //
  // Для Google analytics лучше использовать стандартные методы
  // https://developers.google.com/analytics/devguides/collection/analyticsjs/sending-hits
  var $ga = {
    hasGA: function hasGA() {
      return !!window.ga && typeof window.ga === 'function';
    },
    event: function event(category, action, label) {
      if (!$ga.hasGA()) {
        console.warn('event: google analytics is not defined!');
        return;
      }
      var params = {
        hitType: 'event'
      };
      if (category) params.eventCategory = category;else return;
      if (action) params.eventAction = action;
      if (label) params.eventLabel = label;
      window.ga('send', params);
    },
    page: function page(_page, title, location) {
      if (!$ga.hasGA()) {
        console.warn('page: google analytics is not defined!');
        return;
      }
      var params = {
        hitType: 'pageview'
      };
      if (_page) params.page = _page;else return;
      if (title) params.title = title;
      if (location) params.location = location;
      window.ga('send', params);
    },
    require: function require(payload) {
      if (!$ga.hasGA()) {
        console.warn('require: google analytics is not defined!');
        return;
      }
      if (!payload) return;
      window.ga('require', payload);
    },
    ecommerce: {
      addItem: function addItem() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        if (!$ga.hasGA()) {
          console.warn('ecommerce.addItem: google analytics is not defined!');
          return;
        }
        if (!params.id || !params.name) return;
        window.ga('ecommerce:addItem', params);
      },
      addTransaction: function addTransaction() {
        var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
        if (!$ga.hasGA()) {
          console.warn('ecommerce.addTransaction: google analytics is not defined!');
          return;
        }
        if (!params.id) return;
        window.ga('ecommerce:addTransaction', params);
      },
      send: function send() {
        if (!$ga.hasGA()) {
          console.warn('ecommerce.send: google analytics is not defined!');
          return;
        }
        window.ga('ecommerce:send');
      },
      addProduct: function addProduct() {},
      addImpression: function addImpression() {},
      setAction: function setAction() {},
      addPromo: function addPromo() {}
    },
    set: function set() {},
    query: function query() {},
    screenview: function screenview() {},
    time: function time() {},
    exception: function exception() {},
    social: function social() {}
  };
  inject('ga', $ga);
});