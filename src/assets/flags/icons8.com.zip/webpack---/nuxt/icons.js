'use strict';

import "core-js/modules/es.object.to-string.js";
import "core-js/modules/web.dom-collections.for-each.js";
import "core-js/modules/web.dom-collections.iterator.js";
import "core-js/modules/es.array.join.js";
import "core-js/modules/es.array.slice.js";
function importAll(plugin, r) {
  r.keys().forEach(function (key) {
    var id = key.split('./').join('').split('.svg').join('');
    var href = r(key).default.id;
    plugin[id] = "<svg width=\"100%\" height=\"100%\"><use href=\"#".concat(href, "\"></use></svg>");
  });
}
export default (function (context, inject) {
  var $icons = {};
  if (['below.svg', 'constructionCarpenterRuler.svg', 'paintPalette.svg', 'paintRoller.svg', 'palette.svg']) {
    var staticSvgs = ['below.svg', 'constructionCarpenterRuler.svg', 'paintPalette.svg', 'paintRoller.svg', 'palette.svg'];
    staticSvgs.forEach(function (i) {
      $icons[i.slice(0, -4)] = "<svg width=\"100%\" height=\"100%\"><image width=\"100%\" height=\"100%\" href=\"/vue-static/icon/svg/".concat(i, "\"/></svg>");
    });
  }
  importAll($icons, require.context("!!svg-sprite-loader!/app/assets/svg", true, /\.*$/));
  inject('icons', $icons);
});