import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _79a46b23 = () => interopDefault(import('../pages/icons/index.vue' /* webpackChunkName: "pages/icons/index" */))
const _414f2418 = () => interopDefault(import('../pages/server_status.vue' /* webpackChunkName: "pages/server_status" */))
const _f6d45cae = () => interopDefault(import('../pages/icons/collections/index.vue' /* webpackChunkName: "pages/icons/collections/index" */))
const _4c1d4cf4 = () => interopDefault(import('../pages/icons/new/index.vue' /* webpackChunkName: "pages/icons/new/index" */))
const _5a38a78d = () => interopDefault(import('../pages/icons/presentation-clip-art/index.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/index" */))
const _af11118e = () => interopDefault(import('../pages/icons/request-icon/index.vue' /* webpackChunkName: "pages/icons/request-icon/index" */))
const _0c60683e = () => interopDefault(import('../pages/icons/search-by-image/index.vue' /* webpackChunkName: "pages/icons/search-by-image/index" */))
const _91441ade = () => interopDefault(import('../pages/icons/presentation-clip-art/clipart/index.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/clipart/index" */))
const _1609445e = () => interopDefault(import('../pages/icons/presentation-clip-art/new/index.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/new/index" */))
const _223b8ee5 = () => interopDefault(import('../pages/icons/presentation-clip-art/clipart/_clipart.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/clipart/_clipart" */))
const _e81266ba = () => interopDefault(import('../pages/icons/presentation-clip-art/new/_filter.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/new/_filter" */))
const _3b883452 = () => interopDefault(import('../pages/icons/presentation-clip-art/pack/_pack.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/pack/_pack" */))
const _220186ce = () => interopDefault(import('../pages/icons/presentation-clip-art/set/_term.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/set/_term" */))
const _2ad96ed8 = () => interopDefault(import('../pages/icon/collections/_id.vue' /* webpackChunkName: "pages/icon/collections/_id" */))
const _3952d272 = () => interopDefault(import('../pages/icon/new-icons/_platform/index.vue' /* webpackChunkName: "pages/icon/new-icons/_platform/index" */))
const _66865be1 = () => interopDefault(import('../pages/icon/pack/_pack/index.vue' /* webpackChunkName: "pages/icon/pack/_pack/index" */))
const _9a2c931c = () => interopDefault(import('../pages/icons/authors/_authorId/index.vue' /* webpackChunkName: "pages/icons/authors/_authorId/index" */))
const _2187c90f = () => interopDefault(import('../pages/icons/collections/_collectionId.vue' /* webpackChunkName: "pages/icons/collections/_collectionId" */))
const _56cd08ec = () => interopDefault(import('../pages/icons/new-authors/_author/index.vue' /* webpackChunkName: "pages/icons/new-authors/_author/index" */))
const _e5a9f08e = () => interopDefault(import('../pages/icons/new/_filter.vue' /* webpackChunkName: "pages/icons/new/_filter" */))
const _6ea8f001 = () => interopDefault(import('../pages/icons/pack/_pack.vue' /* webpackChunkName: "pages/icons/pack/_pack" */))
const _3ce24f0d = () => interopDefault(import('../pages/icons/presentation-clip-art/_platform.vue' /* webpackChunkName: "pages/icons/presentation-clip-art/_platform" */))
const _77bbf3e1 = () => interopDefault(import('../pages/icons/request-icon/_id.vue' /* webpackChunkName: "pages/icons/request-icon/_id" */))
const _2513452f = () => interopDefault(import('../pages/icons/set/_term.vue' /* webpackChunkName: "pages/icons/set/_term" */))
const _47d5b961 = () => interopDefault(import('../pages/icon/pack/_pack/_platform.vue' /* webpackChunkName: "pages/icon/pack/_pack/_platform" */))
const _2d544396 = () => interopDefault(import('../pages/icon/set/_term/_platform.vue' /* webpackChunkName: "pages/icon/set/_term/_platform" */))
const _67468224 = () => interopDefault(import('../pages/icons/authors/_authorId/_alias/index.vue' /* webpackChunkName: "pages/icons/authors/_authorId/_alias/index" */))
const _36dbeab0 = () => interopDefault(import('../pages/icons/new-authors/_author/_pack.vue' /* webpackChunkName: "pages/icons/new-authors/_author/_pack" */))
const _61d93cb2 = () => interopDefault(import('../pages/icons/authors/_authorId/_alias/_platform/index.vue' /* webpackChunkName: "pages/icons/authors/_authorId/_alias/_platform/index" */))
const _3155d0cd = () => interopDefault(import('../pages/icons/authors/_authorId/_alias/_platform/_pack.vue' /* webpackChunkName: "pages/icons/authors/_authorId/_alias/_platform/_pack" */))
const _72f657a3 = () => interopDefault(import('../pages/icons/_platform.vue' /* webpackChunkName: "pages/icons/_platform" */))
const _9d412928 = () => interopDefault(import('../pages/icon/_id/_name/index.vue' /* webpackChunkName: "pages/icon/_id/_name/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'is-active',
  linkExactActiveClass: 'is-exact-active',
  scrollBehavior,

  routes: [{
    path: "/icons",
    component: _79a46b23,
    name: "icons"
  }, {
    path: "/server_status",
    component: _414f2418,
    name: "server_status"
  }, {
    path: "/icons/collections",
    component: _f6d45cae,
    name: "icons-collections"
  }, {
    path: "/icons/new",
    component: _4c1d4cf4,
    name: "icons-new"
  }, {
    path: "/icons/presentation-clip-art",
    component: _5a38a78d,
    name: "icons-presentation-clip-art"
  }, {
    path: "/icons/request-icon",
    component: _af11118e,
    name: "icons-request-icon"
  }, {
    path: "/icons/search-by-image",
    component: _0c60683e,
    name: "icons-search-by-image"
  }, {
    path: "/icons/presentation-clip-art/clipart",
    component: _91441ade,
    name: "icons-presentation-clip-art-clipart"
  }, {
    path: "/icons/presentation-clip-art/new",
    component: _1609445e,
    name: "icons-presentation-clip-art-new"
  }, {
    path: "/icons/presentation-clip-art/clipart/:clipart?",
    component: _223b8ee5,
    name: "icons-presentation-clip-art-clipart-clipart"
  }, {
    path: "/icons/presentation-clip-art/new/:filter?",
    component: _e81266ba,
    name: "icons-presentation-clip-art-new-filter"
  }, {
    path: "/icons/presentation-clip-art/pack/:pack?",
    component: _3b883452,
    name: "icons-presentation-clip-art-pack-pack"
  }, {
    path: "/icons/presentation-clip-art/set/:term?",
    component: _220186ce,
    name: "icons-presentation-clip-art-set-term"
  }, {
    path: "/icon/collections/:id?",
    component: _2ad96ed8,
    name: "icon-collections-id"
  }, {
    path: "/icon/new-icons/:platform",
    component: _3952d272,
    name: "icon-new-icons-platform"
  }, {
    path: "/icon/pack/:pack",
    component: _66865be1,
    name: "icon-pack-pack"
  }, {
    path: "/icons/authors/:authorId",
    component: _9a2c931c,
    name: "icons-authors-authorId"
  }, {
    path: "/icons/collections/:collectionId",
    component: _2187c90f,
    name: "icons-collections-collectionId"
  }, {
    path: "/icons/new-authors/:author",
    component: _56cd08ec,
    name: "icons-new-authors-author"
  }, {
    path: "/icons/new/:filter",
    component: _e5a9f08e,
    name: "icons-new-filter"
  }, {
    path: "/icons/pack/:pack?",
    component: _6ea8f001,
    name: "icons-pack-pack"
  }, {
    path: "/icons/presentation-clip-art/:platform?",
    component: _3ce24f0d,
    name: "icons-presentation-clip-art-platform"
  }, {
    path: "/icons/request-icon/:id?",
    component: _77bbf3e1,
    name: "icons-request-icon-id"
  }, {
    path: "/icons/set/:term?",
    component: _2513452f,
    name: "icons-set-term"
  }, {
    path: "/icon/pack/:pack?/:platform",
    component: _47d5b961,
    name: "icon-pack-pack-platform"
  }, {
    path: "/icon/set/:term?/:platform?",
    component: _2d544396,
    name: "icon-set-term-platform"
  }, {
    path: "/icons/authors/:authorId?/:alias",
    component: _67468224,
    name: "icons-authors-authorId-alias"
  }, {
    path: "/icons/new-authors/:author/:pack?",
    component: _36dbeab0,
    name: "icons-new-authors-author-pack"
  }, {
    path: "/icons/authors/:authorId?/:alias/:platform",
    component: _61d93cb2,
    name: "icons-authors-authorId-alias-platform"
  }, {
    path: "/icons/authors/:authorId?/:alias/:platform/:pack",
    component: _3155d0cd,
    name: "icons-authors-authorId-alias-platform-pack"
  }, {
    path: "/icons/:platform",
    component: _72f657a3,
    name: "icons-platform"
  }, {
    path: "/icon/:id?/:name",
    component: _9d412928,
    name: "icon-id-name"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
