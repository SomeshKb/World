import { api } from '@/plugins/axios'

export function generateFont ({ collection, namePrefix, appendHash }, token) {
  return new Promise(function (resolve, reject) {
    const data = {
      fontName: collection.name,
      collectionId: collection.id,
      namePrefix,
      appendHash
    }
    api
      .request({
        url: 'siteApi/tasks/webfonts',
        baseURL: process.env.apiUrl,
        method: 'PUT',
        data,
        responseType: 'blob',
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      .then(response => {
        saveFont(response.data, `${collection.name}.zip`)
        resolve()
      })
      .catch(error => {
        reject(error)
      })
  })
}

export function saveFont (data, filename, mime) {
  const blob = new Blob([data], { type: mime || 'application/octet-stream' })
  if (typeof window.navigator.msSaveBlob !== 'undefined') {
    // IE workaround for "HTML7007: One or more blob URLs were
    // revoked by closing the blob for which they were created.
    // These URLs will no longer resolve as the data backing
    // the URL has been freed."
    window.navigator.msSaveBlob(blob, filename)
  } else {
    const blobURL = window.URL.createObjectURL(blob)
    const tempLink = document.createElement('a')
    tempLink.style.display = 'none'
    tempLink.href = blobURL
    tempLink.setAttribute('download', filename)

    // Safari thinks _blank anchor are pop ups. We only want to set _blank
    // target if the browser does not support the HTML5 download attribute.
    // This allows you to download files in desktop safari if pop up blocking
    // is enabled.
    if (typeof tempLink.download === 'undefined') {
      tempLink.setAttribute('target', '_blank')
    }

    document.body.appendChild(tempLink)
    tempLink.click()
    document.body.removeChild(tempLink)
    window.URL.revokeObjectURL(blobURL)
  }
}

export function generateIconSet (collectionId, name, token, size) {
  return new Promise(function (resolve, reject) {
    const data = {
      iconsInRow: 6,
      name,
      size,
      collectionId,
      type: 'symbol',
      padding: size * 2
    }
    api
      .request({
        url: '/siteApi/icons/sprite/',
        baseURL: process.env.apiUrl,
        method: 'post',
        responseType: 'blob',
        data,
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      .then(response => {
        saveFont(response.data, `${name}.zip`)
        // iconUtils.saveAsExt(response.data, `${name}.svg`)
        resolve()
      })
      .catch(error => {
        reject(error)
      })
  })
}
