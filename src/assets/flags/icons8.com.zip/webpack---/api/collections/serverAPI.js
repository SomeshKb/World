import { axiosFactory, getToken } from 'icons8-common/src/api/helpers'
import { isCollectionValid } from '../../store/collections/_helpers'
import { INVALID_NAME_ERROR } from '../../store/collections/_errors'

const api = axiosFactory({
  baseURL: `${process.env.apiUrl}/siteApi/icons/collections`
})

export async function getCollectionsPreview () {
  const { data } = await api.get('/default')
  if (!data.success) { throw new Error('Error fetching collections preview') }
  return data
}

export async function getCollections (limit, page, iconsLimit = 7) {
  const { data } = await api.get('', {
    params: { limit, page, iconsLimit }
  })
  if (!data.success) { throw new Error('Error fetching collections') }
  return data.docs
}

export async function getCollection (id) {
  const { data } = await api.get(`/${id}`)
  if (!data.success) { throw new Error('Error fetching collection') }
  data.loaded = true
  return data
}

/**
 * @param {{
 *   name: string,
 *   description: string | undefined,
 *   isDefault: boolean | undefined,
 *   isDownloaded: boolean | undefined,
 *   icons: Object[]
 * }} collection
 * @returns {Promise<{}>}
 */
export async function createCollection (collection) {
  if (collection.forceCreate || (!collection.name || isCollectionValid(collection))) {
    const { data } = await api.put('', collection)
    return data
  } else {
    throw INVALID_NAME_ERROR(collection.name)
  }
}

export async function deleteCollection (id, keepAlive = false) {
  if (keepAlive) {
    const { data } = await fetch(`${api.getUri()}/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${getToken()}` },
      keepalive: true
    })
    return data
  } else {
    const { data } = await api.delete(`/${id}`)
    return data
  }
}

export async function updateCollection (id, collectionData) {
  const { data } = await api.post(`/${id}`, collectionData)
  return data
}

export async function shareCollection (id) {
  const { data } = await api.post(`/share/${id}`)
  return data
}

export async function addIconsToCollection (collectionId, icons, onUploadProgress) {
  const config = {}
  if (onUploadProgress) {
    config.onUploadProgress = onUploadProgress
  }
  const { data } = await api.put(`${collectionId}/icons`, icons, config)
  return data.icons
}

export async function updateIconInCollection (collectionId, iconId, iconData) {
  const { data } = await api.post(`/${collectionId}/icons/${iconId}`, iconData)
  return data
}

export async function deleteIconFromCollection (collectionId, iconId) {
  const { data } = await api.delete(`/${collectionId}/icons/${iconId}`)
  return data
}

export const collectionsServerAPI = {
  getCollections,
  getCollection,
  createCollection,
  updateCollection,
  deleteCollection,
  shareCollection,
  addIconsToCollection,
  updateIconInCollection,
  deleteIconFromCollection
}
