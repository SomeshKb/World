import {
  getFromLocalStorage,
  setToLocalStorage
} from '../../utils'
import { NO_ICON_IN_COLLECTION, NO_SUCH_COLLECTION } from './errors'

const COLLECTIONS_LOCAL_STORAGE_KEY = 'collections'

/**
 * @returns {Promise<Array<Object>>}
 */
export async function getCollectionsFromLS () {
  return getFromLocalStorage(COLLECTIONS_LOCAL_STORAGE_KEY) || []
}

/**
 * @param {number | string} collectionId
 * @returns {Promise<Object | undefined>}
 */
export async function getCollectionFromLS (collectionId) {
  return getCollectionsFromLS().find(el => el.id === collectionId)
}

/**
 * @param {Array<Object>} collections
 * @returns {Promise<void>}
 */
export async function setCollectionsToLS (collections) {
  return setToLocalStorage(COLLECTIONS_LOCAL_STORAGE_KEY, collections)
}

/**
 * @param {Object} collection
 * @returns {Promise<void>}
 */
export async function setCollectionToLS (collection) {
  const currentCollections = await getCollectionsFromLS()
  return await setCollectionsToLS([...currentCollections, collection])
}

/**
 * @param {number | string} collectionId
 * @param {Object} collectionData
 * @returns {Promise<void>}
 */
export async function updateCollectionInLS (collectionId, collectionData) {
  const currentCollection = getCollectionFromLS(collectionId)
  if (!currentCollection) {
    throw NO_SUCH_COLLECTION(collectionId)
  }
  const newCollection = { ...currentCollection, ...collectionData }
  let collections = await getCollectionsFromLS()
  collections[collections.findIndex(el => el.id === collectionId)] = newCollection
  return setCollectionsToLS(collections)
}

/**
 * @param {number | string} collectionId
 * @param {boolean} keepAlive
 * @returns {Promise<void>}
 */
export async function deleteCollectionFromLS (collectionId, keepAlive=false) {
  return await setCollectionsToLS(
    (await getCollectionsFromLS())
      .filter(el => el.id !== collectionId)
  )
}

/**
 * @param {number | string} collectionId
 * @param {Array<Object>} icons
 * @returns {Promise<void>}
 */
export async function addIconsToCollectionInLS (collectionId, icons) {
  return await updateCollectionInLS(collectionId, { icons })
}

/**
 * @param {number | string} collectionId
 * @param {number | string} iconId
 * @param {Object} iconData
 * @returns {Promise<void>}
 */
export async function updateIconInCollectionInLS (collectionId, iconId, iconData) {
  let collectionIcons = await getCollectionFromLS(collectionId).icons
  const iconIdx = collectionIcons[collectionIcons.findIndex(el => el.id === iconId)]
  if (!icon) {
    throw NO_ICON_IN_COLLECTION(collectionId, iconId)
  }
  collectionIcons[iconIdx] = { ...collectionIcons[iconIdx], ...iconData }
  return await updateCollectionInLS(collectionId, {
    icons: collectionIcons
  })
}

/**
 * @param {number | string} collectionId
 * @param {number | string} iconId
 * @returns {Promise<void>}
 */
export async function deleteIconFromCollectionInLS (collectionId, iconId) {
  return await updateCollectionInLS(collectionId, {
    icons: (await getCollectionFromLS(collectionId)).icons.filter(el => el.id !== iconId)
  })
}

export const collectionsLocalStorageAPI = {
  getCollections: getCollectionsFromLS,
  getCollection: getCollectionFromLS,
  createCollection: setCollectionToLS,
  updateCollection: updateCollectionInLS,
  deleteCollection: deleteCollectionFromLS,
  shareCollection: async () => { throw new Error('Functionality is not implemented for localStorage.') },
  addIconsToCollection: addIconsToCollectionInLS,
  updateIconInCollection: updateIconInCollectionInLS,
  deleteIconFromCollection: deleteIconFromCollectionInLS
}
