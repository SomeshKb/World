import { getCookie } from '@icons8/frontend-utils'
import http from '@/plugins/axios'

export interface SearchByImageResponse {
  page: number
  limit: number
  total: number
  pages: number

  icons: {
    id: string
    name: string
    commonName: string
    platform: string
    isFree: boolean
  }[]
}

export interface UserSearchHistory {
  success: boolean
  id: string
  name: string
  email: string
  searchHistory: string[]
}

/**
 * Does a search
 * @param {{
 *  term: string,
 *  language: string,
 *  platform?: string,
 *  page?: number,
 *  amount?: number,
 *  options?: object,
 *  isAnimated?: boolean,
 *  authors?: string
 * }} param0 Params
 * @returns {Promise<{
 *  success: boolean,
 *  icons: {
 *    id: number,
 *    name: string
 *    commonName: string
 *    category: string
 *    platform: string
 *    isColor: boolean
 *    sourceFormat: string
 *  }[],
 *  countAll: number,
 *  foundLanguage: string,
 *  searchTranslations: Record<string, string>
 * }>}
 */
export async function search (
  {
    term = undefined,
    platform = 'all',
    page = 1,
    amount = 60,
    language = undefined,
    options = {},
    isAnimated = undefined,
    authors = 'all',
    isColor = undefined
  } = {}
) {
  const params = {
    term,
    amount,
    offset: (page - 1) * amount,
    platform,
    language,
    authors,
    isColor,
    ...options,
    isOuch: true
  }
  if (isAnimated !== undefined) { // because isAnimated has 3 values - [undefined | true | false]
    (params as any).isAnimated = isAnimated
  }

  const response = await http.get(
    'api/iconsets/v5/search',
    {
      baseURL: process.env.searchUrl,
      params,
      withCredentials: false,
      headers: addAuthorizationHeader({})
    }
  )

  if (!response.data.icons) {
    throw new Error('Server error')
  }

  const { icons, success, message, translations } = response.data
  const searchTranslations = response.data.parameters.searchTranslations
  const countAll = response.data.parameters.countAll
  const foundLanguage = response.data.parameters.foundLanguage

  return { icons, success, message, translations, countAll, searchTranslations, foundLanguage }
}

/**
 * Executes a search by image
 * @param {string} imageData The image to search by
 * @param {string} filename The image filename, this is needed to properly construct FormData
 */
export async function searchByImage (
  imageData: string,
  filetype: string,
  filename: string,
  pagination = {
    page: 1,
    limit: 100
  }
): Promise<SearchByImageResponse> {
  /* Create form data */
  let data: FormData | import('form-data')

  // Use polyfill on server
  if (process.server) {
    const FormData = await import('form-data').then(m => m.default)
    data = new FormData()
    data.append('file', Buffer.from(imageData, 'latin1'), filename)
  } else {
    data = new FormData()
    // idk why, but Buffer somehow works in browser...
    data.append('file', new Blob([Buffer.from(imageData, 'latin1')], { type: filetype }), filename)
  }

  const response = await http.post(
    'api/iconsets/vector/search/file',
    data,
    {
      baseURL: process.env.searchUrl,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      params: pagination,
      withCredentials: false
    }
  )

  return response.data
}

/**
 * Gets the search history of an authenticated user
 */
export async function getSearchHistory (): Promise<UserSearchHistory> {
  // trailing slash is important due to a backend bug
  return (await http.get('/api/users/history/', {
    baseURL: process.env.apiUrl,
    headers: addAuthorizationHeader({})
  })).data
}

function addAuthorizationHeader (headers: Record<string, string | number | boolean>) {
  const userToken = (process.browser && getCookie('i8token')) || undefined
  if (userToken) {
    headers.Authorization = `Bearer ${userToken}`
  }
  return headers
}
