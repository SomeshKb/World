import { api } from '@/plugins/axios'
import {getDownloadUrl, isFreePurchase} from '@/api/icon/utils'

export async function downloadIconBySVG (svg, options, userEmail, apiToken, iconId, isIconFree) {
  const { format, size, color } = options
  return await getIconContentBySVG(svg, format, size, color, apiToken, iconId, isIconFree)
}

export function getIconContentBySVG (svg, format, size, color, apiToken, iconId, isIconFree) {
  const data = {
    svg,
    format,
    size
  }
  if (iconId) data.id = iconId
  if (color && (color !== '000000' && color !=='#000000') && !color.includes(',')) data.color = color

  const params = {
    fromSite: true
  }
  if (apiToken && !isFreePurchase(isIconFree, size, format)) params.token = apiToken

  return api.request({
    url: `${getDownloadUrl(isIconFree, size, format)}plainConverter`,
    method: 'POST',
    data,
    params,
    responseType: 'blob'
  })
}
