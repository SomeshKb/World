import { getCookie } from 'icons8-common/src/utils/helpers'
import { DEFAULT_FREE_USER_SIZE_LIMIT } from '@/store/icon/_constants'

export function saveAsExt (data, fileName) {
  return new Promise(function (resolve) {
    const fr = new FileReader()
    fr.onloadend = function () {
      const a = document.createElement('a')
      a.download = fileName
      a.href = fr.result
      document.body.appendChild(a)
      a.click()
      a.remove()
      resolve()
    }
    fr.readAsDataURL(data)
  })
}

export function chooseFormat (format, simplified) {
  return format === 'svg' && !simplified
    ? 'svg.editable'
    : format
}

export function getDownloadUrl (isIconFree, size, format) {
  const paidURL = (process.env.paidAvenueUrl || process.env.avenueApiUrl || process.env.iconsUrl) + '/'
  const freeURL = (process.env.freeAvenueUrl || process.env.avenueApiUrl || process.env.iconsUrl) + '/'
  return isFreePurchase(isIconFree, size, format) ? freeURL : paidURL
}

export function isFreePurchase(isIconFree, size, format) {
  // 1. Для бесплатных иконок в любых форматах/размерах -  бесплатный урл
  // 2. Для платных и купленных иконок в бесплатных форматах/размерах - бесплатный урл
  // 3. Для платных и купленных иконок в платных форматах/размерах - платный урл
  return !!(isIconFree || (format === 'png' && size <= DEFAULT_FREE_USER_SIZE_LIMIT) || format === 'gif' || format === 'ico')
}

export function getHeaders (userEmail) {
  const noTrack = getCookie('x-icons8-no-track')
  return userEmail === noTrack
    ? { 'x-icons8-no-track': userEmail === noTrack }
    : {}
}

const FILLED_SUFFIX = '-filled'

export function generateIconName (icon, options) {
  let name = normalizeValue(icon.name)
  if (icon.filled && !name.endsWith(FILLED_SUFFIX)) { name = appendFilledSuffix(name) }
  if (options.format === 'png') {
    name = `icons8-${name}-${options.size}.${options.format}`
  } else {
    name = `icons8-${name}.${options.format}`
  }
  return name
}

const appendFilledSuffix = (str) => str + FILLED_SUFFIX

/**
 * Convert given value to lower case string,
 * replace all spaces and '_' to '-'.
 * @param {any} value
 * @return {string}
 */
export function normalizeValue (value) {
  return ('' + value)
    .trim()
    .toLowerCase()
    .split(' ')
    .join('-')
    .split('_')
    .join('-')
    .split('/')
    .join('-')
    .split('\\')
    .join('-')
    .split('%')
    .join('-')
}
