import { axiosFactory } from 'icons8-common/src/api/helpers'
import { preprocessIcon } from '../../utils/icon'

const api = axiosFactory({
  baseURL: `${process.env.apiUrl}/siteApi/icons`
})

/**
 * Get and preprocess icon object.
 * @param { string | number } id
 * @param { string | undefined } info
 * @param { string | undefined } language
 * @param { boolean } svg is svg fetching needed
 * @return {Promise<{icon: {svgCurrentResolution: null, svgEffect: null, svg: *, mainId: (string|number|null)}}>}
 */
export async function getIcon ({ id, info, language, svg = false }) {
  const params = { id, info, language }
  if (svg) {
    params.svg = svg
  }
  const { data } = await api.get('/icon', { params })
  if (!data.success) { throw new Error('Error fetching icon.') }
  return { icon: preprocessIcon(data.icon) }
}
