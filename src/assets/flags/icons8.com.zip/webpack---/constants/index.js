export const PLATFORM_SORT_ORDER_API_CODES = [
  'p1em', // Simple Small
  'ios11', // iOS Glyph
  'office40', // Office M
  'Dusk_Wired', // Cute Outline
  'androidL', // Material Filled
  'm_outlined', // Material Outlined
  'cotton', // Pastel
  'ios7', // iOS
  'doodle', // Doodle
  'nolan', // Gradient
  'ultraviolet', // Blue UI
  'color', // Color
  'clouds', // Cloud
  'bubbles', // Circle Bubbles
  'dusk', // Cute Color
  'win10', // Windows 10
  'flat_round', // Infographic
  'plasticine', // Color Hand Drawn
  'cool', // Cute Clipart
  'dotty', // Dotted
  'carbon_copy', // Hand Drawn
  'android', // Ice Cream
  'ios_filled', // iOS Filled
  'm_rounded', // Material Rounded
  'm_sharp', // Material Sharp
  'm_two_tone', // Material Two Tone
  'office16', // Office XS
  'office30', // Office S
  'office80', // Office L
  'pastel_glyph', // Pastel Glyph
  'win8', // Windows Metro
  'stickers' // Stickers
]

export const REGEX_IS_HEX = /^[0-9A-Fa-f]+$/

export const COLOR_LIST = [
  {
    title: 'Black',
    code: 'black',
    value: '#1A1A1A'
  },
  {
    title: 'Dark gray',
    code: 'dark-gray',
    value: '#4D4D4D'
  },
  {
    title: 'Middle gray',
    code: 'middle-gray',
    value: '#737373'
  },
  {
    title: 'Light gray',
    code: 'light-gray',
    value: '#EBEBEB'
  },
  {
    title: 'White',
    code: 'white',
    value: '#FFFFFF'
  },
  {
    title: 'Red',
    code: 'red',
    value: '#FA5252'
  },
  {
    title: 'Orange',
    code: 'orange',
    value: '#FD7E14'
  },
  {
    title: 'Yellow',
    code: 'yellow',
    value: '#FAB005'
  },
  {
    title: 'Green',
    code: 'green',
    value: '#40C057'
  },
  {
    title: 'Mint',
    code: 'mint',
    value: '#12B886'
  },
  {
    title: 'Cyan',
    code: 'cyan',
    value: '#22C3E6'
  },
  {
    title: 'Blue',
    code: 'blue',
    value: '#228BE6'
  },
  {
    title: 'Purple',
    code: 'purple',
    value: '#7950F2'
  },
  {
    title: 'Magenta',
    code: 'magenta',
    value: '#C850F2'
  },
  {
    title: 'Pink',
    code: 'pink',
    value: '#F25081'
  },
]

export const COLOR_EMPTY = {
  title: null,
  code: null,
  value: null
}

export const AUTHORS_MAP = {
  EXTERNAL: 'external',
  ICONS8: 'icons8',
  ALL: undefined
}

export const ANIMATION_MAP = {
  ANIMATED: 'animated',
  STATIC: 'static',
  ALL: undefined
}

export const PLATFORM_TYPE = {
  SINGLE: 'single',
  SUB_STYLE: 'subStyle'
}

export const PARENT_STYLE_MAPPING = {
  ios: {
    title: 'iOS 16',
    seoCode: 'ios-glyphs',
    substyles: [
      { apiCode: 'ios11', title: 'Glyph' },
      { apiCode: 'ios7', title: 'Outlined' },
      { apiCode: 'ios_filled', title: 'Filled' }
    ],
    apiCode: 'ios'
  },
  material: {
    title: 'Material',
    seoCode: 'material',
    substyles: [
      { apiCode: 'androidL', title: 'Filled' },
      { apiCode: 'm_outlined', title: 'Outlined' },
      { apiCode: 'm_rounded', title: 'Rounded' },
      { apiCode: 'm_two_tone', title: ' Two Tone' },
      { apiCode: 'm_sharp', title: 'Sharp' }
    ],
    apiCode: 'material'
  },
  office: {
    title: 'Office',
    seoCode: 'officexs',
    substyles: [
      { apiCode: 'office16', title: 'XS' },
      { apiCode: 'office30', title: 'S' },
      { apiCode: 'office40', title: 'M' },
      { apiCode: 'office80', title: 'L' }
    ],
    apiCode: 'office'
  },
  cute: {
    title: 'Cute',
    seoCode: 'dusk',
    substyles: [
      { apiCode: 'dusk', title: 'Color' },
      { apiCode: 'cool', title: 'Clipart' },
      { apiCode: 'Dusk_Wired', title: 'Outline' }
    ],
    apiCode: 'cute'
  },
  pastel: {
    title: 'Pastel',
    seoCode: 'cotton',
    substyles: [
      { apiCode: 'cotton', title: 'Outlined' },
      { apiCode: 'pastel_glyph', title: 'Glyph' }
    ],
    apiCode: 'pastel'
  },
  windows: {
    title: 'Windows',
    seoCode: 'fluent',
    substyles: [
      { apiCode: 'fluent', title: 'Windows 11 Color' },
      { apiCode: 'fluent-systems-regular', title: 'Windows 11 Outline' },
      { apiCode: 'fluent-systems-filled', title: 'Windows 11 Filled' },
      { apiCode: 'win10', title: '10' },
      { apiCode: 'win8', title: 'Metro' }
    ],
    apiCode: 'windows'
  },
  'hand-drawn': {
    title: 'Hand Drawn',
    seoCode: 'carbon-copy',
    substyles: [
      { apiCode: 'carbon_copy', title: 'Outlined' },
      { apiCode: 'plasticine', title: 'Color' }
    ],
    apiCode: 'carbon_copy'
  },
  'sf-symbols': {
    title: 'SF Symbols',
    seoCode: 'sf-symbols',
    substyles: [
      { apiCode: 'sf-ultralight', title: 'Ultralight' },
      { apiCode: 'sf-regular', title: 'Regular' },
      { apiCode: 'sf-black', title: 'Black' },
      { apiCode: 'sf-ultralight-filled', title: 'Ultralight Filled' },
      { apiCode: 'sf-regular-filled', title: 'Regular Filled' },
      { apiCode: 'sf-black-filled', title: 'Black Filled' }
    ]
  }
}

export const SHAPES_MAP = {
  CIRCLE: 'circle',
  SQUARE: 'square',
}

export const FORMATS_MAP = {
  PNG: 'png',
  VECTOR: 'vector',
}

export const FULL_NAME_MONTH = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December'
]

export const FULL_NAME_DAYS = [
  'Sunday',
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday'
]

export const SHORT_NAMES_MONTH = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'June',
  'July',
  'Aug',
  'Sept',
  'Oct',
  'Nov',
  'Dec'
]

