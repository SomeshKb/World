export default async (context) => {
  return context.store.state.i18n.messages
}
