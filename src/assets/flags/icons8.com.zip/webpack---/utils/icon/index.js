/**
 * Decode SVG from Base64 (or not).
 * @param {any} svg
 * @return {any}
 */

let atob
if (process.browser) {
  atob = window.atob
} else {
  atob = require('atob')
}

export function getRawSVG (svg) {
  return typeof svg === 'string' ? atob(svg) : svg
}

/**
 * Prepare icon for usage on frontend.
 * @param {object} icon
 * @return {{svgCurrentResolution: null, svgEffect: null, svg: *, mainId: (string|number|null)}}
 */
export function preprocessIcon (icon) {
  return {
    ...preprocessIconObject(icon),
    svgEffect: null,
    svgCurrentResolution: null,
    mainId: findIconMainId(icon)
  }
}

function preprocessIconObject (iconObject) {
  const newObj = {
    ...iconObject
  }
  if (iconObject.svg) {
    newObj.svg = getRawSVG(iconObject.svg)
  }
  if (iconObject.resolutions) {
    newObj.resolutions = preprocessIconObjects(iconObject.resolutions)
  }
  if (iconObject.variants) {
    newObj.variants = preprocessIconObjects(iconObject.variants)
  }
  return newObj
}

/**
 * @param {Array<object> | undefined} icons
 * @return {Array<object> | undefined}
 */
function preprocessIconObjects (icons) {
  if (icons && Array.isArray(icons)) { return icons.map(preprocessIconObject) } else { return undefined }
}

/**
 * @param {object} icon
 * @return {string | number | null}
 */
function findIconMainId (icon) {
  if (icon.mainId) { return icon.mainId }
  if (icon.variants && icon.variants.length > 0 && Array.isArray(icon.variants)) {
    const iosVariant = icon.variants.find(variant => variant.platform === 'ios7')
    return iosVariant ? iosVariant.id : icon.variants[0].id
  }
  return null
}
