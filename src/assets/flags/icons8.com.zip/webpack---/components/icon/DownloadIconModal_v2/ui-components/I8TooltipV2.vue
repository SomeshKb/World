var render = function render(){var _vm=this,_c=_vm._self._c;return _c('div',{directives:[{name:"i8-click-outside",rawName:"v-i8-click-outside",value:(_vm.hide),expression:"hide"},{name:"touch",rawName:"v-touch:touchhold",value:(_vm.open),expression:"open",arg:"touchhold"}],staticClass:"i8-tooltip-container",attrs:{"id":"i8-tooltip-container"},on:{"mouseover":_vm.onMouseOver,"mouseleave":_vm.onMouseLeave}},[_c('Portal',[_c('div',{ref:"tooltip",staticClass:"i8-tooltip",class:_vm.tooltipClasses,style:({
        ..._vm.tooltipStyle,
        opacity: _vm.tooltipOpacity,
        zIndex: _vm.tooltipZIndex,
      }),attrs:{"id":_vm.computedId}},[_vm._t("default"),_vm._v(" "),_c('div',{ref:"arrow",staticClass:"i8-tooltip-arrow",style:(_vm.arrowStyle)})],2)]),_vm._v(" "),_vm._t("activator",null,null,{ open: _vm.open, hide: _vm.hide })],2)
}
var staticRenderFns = []

export { render, staticRenderFns }