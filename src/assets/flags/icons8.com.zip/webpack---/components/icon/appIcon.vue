<!--suppress ALL -->
<template>
  <div
      v-if="isSVG"
      class="app-icon"
      :draggable="hasDraggable"
      :style="iconStyle"
      :class="iconClasses"
      @dragstart="handleDragStart"
      @drop="handleDrop"
      @mousedown="handleMouseDown"
      v-html="content"
  />
  <div
      v-else
      class="app-icon"
      :draggable="hasDraggable"
      :class="iconClasses"
      :style="iconStyle"
      @mousedown="handleMouseDown"
      @dragstart="handleDragStart"
      @drop="handleDrop"
  >
    <template v-if="lazy">
      <template v-if="needIconLoader">
        <img
            :srcset="iconUrl"
            :alt="alt || (name + ' icon')"
            :style="imgStyle"
            loading="lazy"
            onload="this.setAttribute('lazy', 'loaded')"
            onerror="this.setAttribute('lazy', 'error')"
        >
        <icon-placeholder
            class="loading-icon"
            :count="1"
            :type="'loading'"
        />
      </template>
      <template v-else>
        <img
            :srcset="iconUrl"
            :alt="alt || (name + ' icon')"
            :style="imgStyle"
            loading="lazy"
        >
      </template>
    </template>
    <template v-else>
      <img
          :alt="alt || (name + ' icon')"
          :style="imgStyle"
          :srcset="iconUrl"
      >
    </template>
    <div
        v-if="user.isAdmin && showPurge"
        class="purge-icon"
        @click.stop="purgeIcon"
    >
      purge
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import axios from '~/plugins/axios'
import ColorPngService from '@/utils/colorPngService';

export default {
  name: 'AppIcon',
  props: {
    id: {
      type: [Number, String],
      default: null
    },
    svg: {
      type: String,
      default: null
    },
    url: {
      type: String,
      default: null
    },
    color: {
      type: String,
      default: null
    },
    colorGradient: {
      type: Object,
      default: undefined
    },
    platform: {
      type: String,
      default: null
    },
    alt: {
      type: String,
      default: null
    },
    icon: {
      type: Object,
      default: null
    },
    lazy: {
      type: Boolean,
      default: true
    },
    isCollection: {
      type: Boolean,
      default: false
    },
    customSize: {
      type: [Number, Boolean],
      default: false
    },
    forcePng: {
      type: Boolean,
      default: false
    },
    showPurge: {
      type: Boolean,
      default: false
    },
    effects: {
      type: Array,
      default () {
        return []
      }
    },
    needIconLoader: {
      type: Boolean,
      default: false
    },
    isIconHover: {
      type: Boolean,
      default: false
    },
    forceColor: {
      type: Boolean,
      default: false
    },
  },
  data () {
    return {
      isSVG: false,
      isDragging: false
    }
  },
  computed: {
    ...mapState({
      platforms: state => (state.appInfo ? state.appInfo.platforms : {}),
      user: state => state.auth.user,
      currentPlatform: state => state.platform.apiCode
    }),
    hasDraggable () {
      return this.iconId
    },
    iconId () {
      return this.icon ? this.icon.iconId || this.icon.id : this.id
    },
    iconUrl () {
      if (this.url) {
        return this.url
      }
      let size = '2x'
      if (this.customSize) {
        size = this.customSize * 2
      }
      let url
      if (this.icon && this.icon.commonName) {
        const platform = this.platforms[this.icon.platform]
        const seoCode = platform ? platform.seoCode : this.iconPlatform
        let color = ''
        if (!this.icon.isAnimated) {
          if (this.colorGradient && this.icon.platform === 'nolan') {
            const start = this.colorGradient.start.replace('#', '')
            const end = this.colorGradient.end.replace('#', '')
            color = `${start}/${end}/`
          } else if (this.color) {
            if (this.color.includes('#')) {
              color = this.color.split('#')[1] !== '000000' ? this.color.split('#')[1] + '/' : ''
            } else {
              color = this.color !== '000000' ? this.color + '/' : ''
            }
          }
        }

        const isGradient = color &&  color.length > 7 ? color: ''
        const commonName = this.icon.commonName
        const isHover = this.isIconHover && typeof this.isIconHover === 'boolean'
        const format = isHover ? 'gif' : 'png'

        url = `${process.env.iconsUrl}/${seoCode}/${size}/${isGradient}${commonName}.${format} 2x`

        if (this.icon.platform === 'nolan') {
          url = `${process.env.iconsUrl}/${seoCode}/${size}/${color}${commonName}.${format} 2x`
        }

        return url
      }
      url = `${process.env.iconsUrl}/?id=${this.iconId}&size=${size}`
      if (this.color) {
        if (this.color.includes('#') && this.color !== '#000000') {
          url += `&color=${this.color.split('#')[1]}`
        } else if (this.color !== '000000') {
          url += `&color=${this.color}`
        }
      }
      return url
    },
    iconUrlObj () {
      return {
        src: this.iconUrl,
        error: require('../../assets/svg/iconLoadError.svg')
      }
    },
    name () {
      if (this.icon) return this.icon.name || `${this.icon.commonName}`.replace('-', ' ') || ''
      return ''
    },
    content () {
      if (this.forcePng) {
        this.isSVG = false
        return ''
      }
      if (this.icon) {
        if (this.icon.svgEffect) {
          return this.icon.svgEffect
        }
        if (this.icon.svgCurrentResolution) {
          return this.icon.svgCurrentResolution
        }
        if (this.icon.svg) {
          return this.icon.svg
        }
      }
      if (this.svg) {
        return this.svg
      }
      if (this.iconId) {
        this.isSVG = false
      }
      return ''
    },
    iconPlatform () {
      return this.platform || (this.icon ? this.icon.platform : undefined)
    },
    imgSize () {
      const style = {}
      if (!this.customSize && this.iconPlatform) {
        const platform = this.platforms[this.iconPlatform]
        if (platform) {
          const size = platform.size < 64 ? platform.size : 64
          style.width = style.height = `${size}px`
        }
      }
      return style
    },
    iconStyle () {
      const style = {}
      if (this.customSize) {
        style.width = `${this.customSize}px`
        style.height = `${this.customSize}px`
      }
      return style
    },
    iconClasses () {
      const classes = {
        [`is-${this.iconPlatform}`]: this.platform || this.icon,
        'is-custom-size': this.customSize,
        'is-loading': !this.iconId && !this.svg && !this.icon && !this.url
      }
      const effects = [].concat(this.effects)
      effects.forEach(effect => {
        classes[`is-effect-${effect}`] = true
      })
      return classes
    },
    isPlatformColor () {
      return this.platforms[this.iconPlatform]?.isColor
    },
    getColorImage () {
      if (
        this.icon &&
        this.currentPlatform !== 'nolan' &&
        (this.forceColor || !this.icon.isAnimated) &&
        (this.forceColor || this.icon.isColor === false)
      ) {

        const colorService = new ColorPngService(this.$store)
        return colorService.styleColor(this.color)

      }
    },
    imgStyle () {
      return {
        ...this.iconStyle,
        filter: this.getColorImage
      }
    }
  },
  watch: {
    icon: {
      handler () {
        this.computeIsSVG()
      },
      deep: true
    }
  },
  mounted () {
    if (this.isCollection) {
      this.isSVG = true
      return
    }
    if (this.svg) {
      this.isSVG = true
    } else {
      this.isSVG = false
    }
    this.computeIsSVG()
  },
  methods: {
    handleMouseDown (e) {
      // stop ripple effect if we drag
      e.stopPropagation()
    },
    handleDragStart (e) {
      this.isDragging = true
      if (!this.hasDraggable) {
        e.preventDefault()
      } else {
        e.dataTransfer.setData(
          'text/plain',
          JSON.stringify({
            icon: this.icon,
            id: this.iconId,
            svg: this.content
          })
        )
      }
    },
    handleDrop () {
      this.isDragging = false
    },
    purgeIcon (e) {
      e.preventDefault()
      e.stopPropagation()
      e.stopImmediatePropagation()
      axios.delete(`${process.env.apiUrl}/siteApi/utils/renderer/clearCache`, {
        headers: {
          'content-type': 'application/json',
          Authorization: `Bearer ${this.$store.state.auth.user.authToken}`
        },
        data: {
          urlCDN: [this.iconUrl]
        }
      })
    },
    computeIsSVG () {
      if (this.icon) {
        if (!this.forcePng && (this.icon.svg || this.icon.svgEffect || this.icon.svgCurrentResolution)) {
          this.isSVG = true
        }
      }
    }
  }
}
</script>

<style lang="scss">
@import '~assets/css/variables';
@import '~assets/css/mixins';

.purge-icon {
  background: #28b351;
  position: absolute;
  top: -20px;
  right: 0;
  border-radius: 4px;
  padding: 1px 4px;
  line-height: 1;
  //width: 20px;
  height: 20px;
  font-size: 12px;
  color: white;
  cursor: pointer;
  z-index: 10;
  transition: all 0.3s;
  fill: rgba(0, 0, 0, 0.5);
  @media (max-width: 800px) {
    right: 45px;
  }
}

.app-icon {
  position: relative;
  width: 100%;
  height: auto;
  display: flex;
  justify-content: center;
  align-items: center;
  transition: 0.2s all ease;

  .app-icon-content {
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  svg {
    position: relative;
    width: 50px;
    height: 50px;
    transition: 0.2s all ease;
  }
  img {
    object-fit: contain;
    position: relative;
    transition: 0.2s all ease;
    max-width: 100%;
    max-height: 100%;

    &:not([src]) {
      // display: none;
    }

    &[lazy='loaded'],
    &[lazy='error'] {
      ~ .loading-icon {
        display: none;
      }
    }
  }

  &.is-unavailable {
    svg,
    img,
    .app-icon-effect {
      opacity: 0.35;
    }
  }

  &.is-small {
    width: 50px;
    height: 50px;
    svg,
    img,
    .app-icon-effect,
    .app-icon-content {
      width: 26px;
      height: 26px;
    }
  }

  &.is-tiny {
    width: 24px;
    height: 24px;
    svg,
    img,
    .app-icon-effect,
    .app-icon-content {
      width: 100%;
      height: 100%;
    }
  }
  .app-icon-effect {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  &.is-effect-square {
    .app-icon-effect {
      border-radius: 12.5%;
      background-color: darken($color-grey-light, 2%);
    }
  }
  &.is-effect-round {
    .app-icon-effect {
      border-radius: 50%;
      background-color: darken($color-grey-light, 2%);
    }
  }
  &.is-effect-circle {
    .app-icon-effect {
      border-radius: 50%;
      border: 2px solid $color-grey;
    }
  }

  @mixin iconSize($size: 50px, $ratio: 1.5) {
    svg,
    img,
    .app-icon-content {
      width: $size;
      height: $size;
    }
    .app-icon-effect {
      width: $size * $ratio;
      height: $size * $ratio;
    }
  }

  &.is-custom-size {
    svg,
    img,
    .app-icon-effect,
    .app-icon-content {
      width: 100%;
      height: 100%;
    }
  }

  &.is-inline {
    display: inline-block;
  }

  &.is-loading {
    @include loading;
  }

  .loading-icon {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
  }
}
</style>
