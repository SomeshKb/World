// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only{display:none!important}}@media(max-width:1023px){.desktop-only{display:none!important}}.icon-tags{font-size:15px;line-height:20px}.icon-tags .icon-tags-title{display:inline-block;margin-right:.5rem}.icon-tags .tag{height:37px;border-radius:20px;background-color:#fff;border:1px solid rgba(51,51,51,.2);color:#333;line-height:31px;text-transform:capitalize}.icon-tags .app-popup{display:inline-block}.icon-tags div.app-popup div.app-popup-content{width:30rem;padding:8px 0 0 8px}@media(max-width:1170px){.icon-tags div.app-popup div.app-popup-content{width:25rem;right:0;transform:translateX(50%)}}.icon-tags .app-popup-btn{display:flex;align-items:center;justify-content:space-around;width:48px;height:26px;margin-bottom:8px;background-color:#f4f4f4;border-radius:5px;color:#9b9b9b;padding:0 8px;border:1px solid hsla(0,0%,61.2%,0);text-decoration:none;cursor:pointer;transition:all .3s ease}.icon-tags .app-popup-btn i{width:5px;height:5px;border-radius:50%;background-color:#000}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
