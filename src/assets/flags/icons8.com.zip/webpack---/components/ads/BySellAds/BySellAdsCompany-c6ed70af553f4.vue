// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".by-sell-ads-large[data-v-fa06230e]{position:relative;background:#f7f7f7;box-sizing:border-box;border-radius:8px;min-height:72px;max-width:720px;padding:16px;display:flex}.ad-image-container[data-v-fa06230e]{border-radius:20px;box-sizing:border-box;padding:10px;max-width:40px;max-height:40px}.ad-image[data-v-fa06230e]{max-width:20px;height:auto}.ad-content[data-v-fa06230e]{margin-left:16px;color:#1a1a1a}.ad-content>*[data-v-fa06230e]{margin:0;padding:0;display:block}.ad-text-title[data-v-fa06230e]{font-weight:700;font-size:14px;line-height:24px}.ad-text-description[data-v-fa06230e]{font-size:14px;line-height:20px}.ad-ad[data-v-fa06230e]{position:absolute;top:12px;right:6px;font-weight:600;font-size:10px;line-height:10px;display:flex;align-items:center;color:#1a1a1a;opacity:.4;text-transform:uppercase}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
