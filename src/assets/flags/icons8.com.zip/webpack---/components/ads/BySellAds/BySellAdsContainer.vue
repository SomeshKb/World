<template>
  <div v-if="ad">
    <slot :ad="ad" />
  </div>
</template>

<script>
import { mapState } from 'vuex'
const IS_PROD_BUILD = process.env.NODE_ENV === 'production'
function callJSONP (options) {
  // --- default options ---
  const zoneKey = options.zoneKey || ''
  const resolve = options.resolve || function () {}
  const reject = options.reject || function () {}
  const timeout = options.timeout || 10
  const CALLBACK_BSA = `callbackBSA_${zoneKey}`

  if (!zoneKey) {
    console.error('zoneKey options is required!')
    return
  }
  // --- create link ---
  let src = `https://srv.buysellads.com/ads/${zoneKey}.json?callback=${CALLBACK_BSA}`
  if (!IS_PROD_BUILD) src += '&ignore=yes'

  // --- remove old script ---
  const hasScript = document.querySelector(`[src='${src}']`)
  if (hasScript) hasScript.remove()

  // --- add callback ---
  const timeoutTrigger = window.setTimeout(function () {
    window[CALLBACK_BSA] = function () {}
    reject()
    delete window[CALLBACK_BSA]
  }, timeout * 1000)

  window[CALLBACK_BSA] = function (data) {
    window.clearTimeout(timeoutTrigger)
    resolve(data)
    delete window[CALLBACK_BSA]
  }

  // --- add new script ---
  const script = document.createElement('script')
  script.type = 'text/javascript'
  script.async = true
  script.src = src
  document.getElementsByTagName('head')[0].appendChild(script)
}

export default {
  name: 'BySellAdsContainer',
  props: {
    zoneKey: {
      type: String,
      required: false,
      default: 'CK7DV277'
    },
    checkValue: {
      type: String,
      default: 'company'
    }
  },
  data () {
    return {
      ad: null
    }
  },
  computed: {
    ...mapState({
      user: state => state.auth.user
    }),
    isShowBaner () {
      return this.user.loaded && (this.user.isGuest || !this.user.activeLicense)
    }
  },
  watch: {
    isShowBaner (value) {
      if (value) this.load()
      else this.adsOff()
    }
  },
  mounted () {
    if (this.isShowBaner && !this.ad) this.load()
  },
  methods: {
    load () {
      callJSONP({
        zoneKey: this.zoneKey,
        resolve: (data) => {
          this.ad = this.getAd(data)
        },
        reject: () => {
          console.warn('By Sell Ads timeout :(')
          this.$emit('rejectAds')
        },
        timeout: 5
      })
    },
    getAd (data) {
      const ad = data.ads.find((el) => el[this.checkValue])
      if (!ad) {
        console.warn('By Sell Ads didn\'t return any valid ad.')
        this.$emit('rejectAds')
        return null
      } else {
        this.$emit('approveAds')
        return ad
      }
    },
    adsOff () {
      this.ad = null
    }
  }
}
</script>
