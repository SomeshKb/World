import { render, staticRenderFns } from "./BySellAdsCompany.vue?vue&type=template&id=fa06230e&scoped=true&"
import script from "./BySellAdsCompany.vue?vue&type=script&lang=js&"
export * from "./BySellAdsCompany.vue?vue&type=script&lang=js&"
import style0 from "./BySellAdsCompany.vue?vue&type=style&index=0&id=fa06230e&prod&scoped=true&lang=css&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "fa06230e",
  null
  
)

export default component.exports