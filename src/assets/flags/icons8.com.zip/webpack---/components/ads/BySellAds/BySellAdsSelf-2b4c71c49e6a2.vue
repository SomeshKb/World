// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".by-sell-ads-self[data-v-3fc9a3f6]{display:flex;position:relative;border:1px solid rgba(51,51,51,.1);box-sizing:border-box;border-radius:8px;max-width:730px;overflow:hidden}.ad-image[data-v-3fc9a3f6]{max-width:100%;height:auto;line-height:0}.ad-ad[data-v-3fc9a3f6]{position:absolute;top:6px;right:6px;font-weight:600;font-size:10px;line-height:10px;display:flex;align-items:center;color:#1a1a1a;opacity:.4;text-transform:uppercase}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
