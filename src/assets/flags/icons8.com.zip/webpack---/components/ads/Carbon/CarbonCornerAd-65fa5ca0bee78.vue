// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-12bc8ef4]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-12bc8ef4]{display:none!important}}.app-ads[data-v-12bc8ef4]{max-width:280px}.app-ads[data-v-12bc8ef4]:after{content:\"\";display:table;clear:both}.after-ad[data-v-12bc8ef4]{position:absolute;font-size:15px;display:flex;width:200px;height:60px;bottom:0;z-index:5;padding:0 16px;right:0;border-radius:8px;justify-content:space-between;align-items:center;background:#363250}.after-ad .native-main[data-v-12bc8ef4]{color:hsla(0,0%,100%,.7);font-weight:400}.after-ad .upgrade[data-v-12bc8ef4]{background-color:#fed9a3;border-radius:8px;padding:5px 8px;font-size:14px;color:rgba(0,0,0,.7);font-weight:400}@media(max-width:767px){.after-ad[data-v-12bc8ef4]{display:none}}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
