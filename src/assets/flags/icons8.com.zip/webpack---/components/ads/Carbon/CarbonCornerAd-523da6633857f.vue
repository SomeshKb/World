import { render, staticRenderFns } from "./CarbonCornerAd.vue?vue&type=template&id=12bc8ef4&scoped=true&"
import script from "./CarbonCornerAd.vue?vue&type=script&lang=js&"
export * from "./CarbonCornerAd.vue?vue&type=script&lang=js&"
import style0 from "./CarbonCornerAd.vue?vue&type=style&index=0&id=12bc8ef4&prod&lang=scss&scoped=true&"
import style1 from "./CarbonCornerAd.vue?vue&type=style&index=1&id=12bc8ef4&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "12bc8ef4",
  null
  
)

export default component.exports