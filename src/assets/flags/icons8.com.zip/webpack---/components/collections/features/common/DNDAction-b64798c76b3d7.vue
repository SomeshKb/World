// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-c60bb0c2]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-c60bb0c2]{display:none!important}}.dnd-action[data-v-c60bb0c2]{width:100%;height:100%;flex-flow:column nowrap;gap:6px;border:1px dashed var(--c-transparent-black_800);border-radius:4px;background:#f6f9f7}.dnd-action[data-v-c60bb0c2],.icon-container[data-v-c60bb0c2]{display:flex;justify-content:center;align-items:center}.icon-container[data-v-c60bb0c2]{--size:24px;width:var(--size);height:var(--size)}span[data-v-c60bb0c2]{color:var(--c-black_800);font:var(--collection-card-title,var(--collection-card-title-weight,var(--font-semibold)) var(--collection-card-title-size,var(--font-sm))/var(--collection-card-title-line-height,20px) var(--collection-card-title-family,var(--font-family-legacy)))}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
