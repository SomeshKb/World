<template>
  <I8Button
    class="create-collection"
    size="large"
    @click="$emit('createCollection')"
  >
    <div v-html="$icons.plusRounded" class="plus-icon"/>
    {{ $t('ICON.COMPONENTS.LEFT_SIDEBAR.CREATE_COLLECTION') }}
  </I8Button>
</template>

<script>
import { I8Button } from "@icons8/vue-kit"

export default {
  name: 'CreateCollectionCard',
  components: { I8Button }
}
</script>

<style scoped lang="scss">
.plus-icon {
  width: 18px;
  height: 18px;
  opacity: 0.26;

  margin-right: 6px;
}

.create-collection {
  width: 100%;
  min-height: 40px;
  height: 100%;
}
</style>
