<template>
  <DNDAction icon="plus">
    Create collection
  </DNDAction>
</template>

<script>
import DNDAction from '../common/DNDAction'

export default {
  name: 'CreateCollectionDNDCard',
  components: { DNDAction }
}
</script>

