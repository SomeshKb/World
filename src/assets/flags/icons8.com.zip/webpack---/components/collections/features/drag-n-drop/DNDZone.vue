var render = function render(){var _vm=this,_c=_vm._self._c;return _c('div',{staticClass:"dnd-zone",class:{ 'is-dragging': _vm.isDragging },on:{"dragover":function($event){$event.preventDefault();},"dragenter":function($event){$event.preventDefault();return _vm.handleDragenter.apply(null, arguments)},"dragleave":function($event){$event.preventDefault();return _vm.handleDragleave.apply(null, arguments)},"drop":function($event){$event.preventDefault();$event.stopPropagation();return _vm.handleDrop.apply(null, arguments)}}},[_vm._t("default")],2)
}
var staticRenderFns = []

export { render, staticRenderFns }