<template>
  <div
    v-if="openCollectionId && openedCollection"
    class="collection-sidebar-container"
  >
    <Collection
      :collection="openedCollection"
    />
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions } from 'vuex'

export default {
  name: "OpenedCollectionSidebar",
  components: {
    Collection: () => import(/* webpackChunkName: "collections" */ './Collection')
  },
  data: () => ({
    popstateChanged: false
  }),
  watch: {
    openCollectionId: {
      handler (newValue, oldValue) {
        if (this.popstateChanged) {
          this.popstateChanged = false
        } else {
          if (newValue && !oldValue) {
            window.history.pushState(null, null, `/icons/collections/${newValue}`)
          } else if (newValue && oldValue) {
            window.history.replaceState(null, null, `/icons/collections/${newValue}`)
          } else {
            window.history.back()
            this.popstateChanged = true
          }
        }
      }
    }
  },
  mounted() {
    window.addEventListener('popstate', this.popstateHandler)
  },
  beforeDestroy() {
    window.removeEventListener('popstate', this.popstateHandler)
  },
  computed: {
    ...mapGetters({
      openedCollection: 'collections/getOpenCollection',
    }),
    ...mapState({
      openCollectionId: state => state.collections.openCollectionId
    })
  },
  methods: {
    ...mapActions('collections', ['closeCollection']),
    popstateHandler () {
      if (this.popstateChanged) {
        // popstateChanged === true => window.history.back() was called not by user
        this.popstateChanged = false
      } else {
        this.popstateChanged = true
        this.closeCollection()
      }
    }
  }
}
</script>

<style scoped lang="scss">
@import '~assets/css/variables';
.collection-sidebar-container {
  z-index: 11;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 224px;
  right: 0;

  width: calc(100vw - 224px);

  background-color: #ffffff;
}

</style>
