import { render, staticRenderFns } from "./CollectionUploadErrorToast.vue?vue&type=template&id=2ea46ebc&scoped=true&"
import script from "./CollectionUploadErrorToast.vue?vue&type=script&lang=js&"
export * from "./CollectionUploadErrorToast.vue?vue&type=script&lang=js&"
import style0 from "./CollectionUploadErrorToast.vue?vue&type=style&index=0&id=2ea46ebc&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "2ea46ebc",
  null
  
)

export default component.exports