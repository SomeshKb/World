/**
 * @param {number|string} iconId
 * @param {{}} params
 * @returns {string}
 */
export function getIconUrl (iconId, params = {}) {
  const defaultParams = { size: '2x' }
  const query = { id: iconId, ...defaultParams, ...params }
  const qs = Object.keys(query)
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`)
    .join('&')
  return `${process.env.iconsUrl}/?${qs}`
}

/**
 * @param {File} file
 * @return {boolean}
 */
export function isFileValid (file) {
  const MAX_FILE_SIZE = 102400
  if (!/\.svg$/.test(file.name)) {
    throw new Error(`File ${file.name} must be SVG.`)
  }
  if (file.size > MAX_FILE_SIZE) {
    throw new Error(`File ${file.name} must be less than 100 KB.`)
  }
  return true
}

/**
 * @param {string} name
 * @return {string}
 */
export function prepareIconName (name) {
  return name.split('.').slice(0, -1).join('.')
}

export function parseFile (file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => {
      resolve(reader.result)
    }
    reader.onerror = reject
    reader.readAsText(file)
  })
}
