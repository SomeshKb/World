var render = function render(){var _vm=this,_c=_vm._self._c;return _c('transition',{attrs:{"name":"fade"}},[(_vm.isShow)?_c('div',{staticClass:"collection-upload-error-toast"},[_c('button',{staticClass:"close-toast",domProps:{"innerHTML":_vm._s(_vm.$icons.cancel)},on:{"click":function($event){$event.preventDefault();return _vm.close.apply(null, arguments)}}}),_vm._v(" "),_c('div',{staticClass:"toast-body"},[_c('div',{staticClass:"icon",domProps:{"innerHTML":_vm._s(_vm.$icons.warn)}}),_vm._v(" "),_c('div',{staticClass:"text"},[_c('div',{staticClass:"title"},[_vm._v("\n          Wrong file\n        ")]),_vm._v(" "),_vm._t("default")],2)])]):_vm._e()])
}
var staticRenderFns = []

export { render, staticRenderFns }