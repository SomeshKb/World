import { render, staticRenderFns } from "./OpenedCollectionSidebar.vue?vue&type=template&id=34ac2a68&scoped=true&"
import script from "./OpenedCollectionSidebar.vue?vue&type=script&lang=js&"
export * from "./OpenedCollectionSidebar.vue?vue&type=script&lang=js&"
import style0 from "./OpenedCollectionSidebar.vue?vue&type=style&index=0&id=34ac2a68&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "34ac2a68",
  null
  
)

export default component.exports