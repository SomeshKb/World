<template>
  <DNDZone
    class="collection-dnd-wrapper"
    :collection-icons="collection.icons"
    @dnd-dragging="handleDragging"
    @dnd-enter="handleEnter"
    @dnd-upload="handleUpload"
  >
    <div
      class="progress-bar"
      :style="progressBarStyle"
    />
    <DNDAction
      v-if="isDragging"
      class="dnd-container"
    >
      {{ dragText }}
    </DNDAction>
    <div
      v-else
      class="collection-info-wrapper"
    >
      <slot />
    </div>
  </DNDZone>
</template>

<script>
import { mapActions } from 'vuex'

import DNDZone from '../features/drag-n-drop/DNDZone'
import DNDAction from '../features/common/DNDAction'

export default {
  name: 'CollectionDNDWrapper',
  components: {
    DNDZone, DNDAction
  },
  props: {
    collection: {
      type: Object,
      required: true
    }
  },
  data () {
    return {
      isDragging: false,
      uploadProgress: 0,
      dragSource: null
    }
  },
  computed: {
    progressBarStyle () {
      return {
        width: `${this.uploadProgress}%`
      }
    },
    dragText () {
      return (this.dragSource === 'internal') ?
        this.$t('ICON.COMPONENTS.LEFT_SIDEBAR.ADD_TO_COLLECTION') :
        this.$t('ICON.COMPONENTS.LEFT_SIDEBAR.DROP_FILE_TO_UPLOAD')
    }
  },
  inject: ['setUploadErrors'],
  methods: {
    ...mapActions({
      uploadIcons: 'collections/addIconsToCollection'
    }),
    handleDragging (isDragging) {
      this.isDragging = isDragging
    },
    handleEnter (source) {
      this.dragSource = source
    },
    handleUpload (icons) {
      if (!icons.length) return

      this.uploadIcons({
        collectionId: this.collection.id,
        icons,
        onUploadProgress: (progressEvent) => {
          this.uploadProgress = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          if (this.uploadProgress === 100) {
            setTimeout(() => {
              this.uploadProgress = 0
            }, 100)
          }
        }
      })
        .catch((err) => {
          console.error(err)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
  .collection-dnd-wrapper {
    position: relative;
    .dnd-container {
      pointer-events: none;
      min-height: var(--collection-card-min-height, auto);
      border-radius: var(--collection-card-border-radius);
    }
    .progress-bar {
      position: absolute;
      z-index: 0;
      pointer-events: none;
      top: 0;
      left: 0;
      bottom: 0;
      background-color: #E7F9EB;
    }
  }
  .collection-info-wrapper {
    position: relative;
    z-index: 1;
    height: 100%;
  }
</style>
