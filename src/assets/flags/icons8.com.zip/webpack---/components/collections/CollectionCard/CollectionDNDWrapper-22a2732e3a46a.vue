// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-6d0f1119]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-6d0f1119]{display:none!important}}.collection-dnd-wrapper[data-v-6d0f1119]{position:relative}.collection-dnd-wrapper .dnd-container[data-v-6d0f1119]{pointer-events:none;min-height:var(--collection-card-min-height,auto);border-radius:var(--collection-card-border-radius)}.collection-dnd-wrapper .progress-bar[data-v-6d0f1119]{position:absolute;z-index:0;pointer-events:none;top:0;left:0;bottom:0;background-color:#e7f9eb}.collection-info-wrapper[data-v-6d0f1119]{position:relative;z-index:1;height:100%}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
