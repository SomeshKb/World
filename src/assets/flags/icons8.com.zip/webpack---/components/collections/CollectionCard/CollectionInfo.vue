<template>
  <div
    class="collection-info"
    @mouseover="hover = true"
    @mouseleave="hover = false"
  >
    <div class="header">
      <input
        v-if="creating"
        v-model="editedName"
        class="name"
        ref="collectionNameInput"
        maxlength="30"
        :placeholder="$t('ICON.COMPONENTS.LEFT_SIDEBAR.NEW_COLLECTION_PLACEHOLDER')"
        @keydown.esc="rejectCreation()"
        @keydown.enter="editName()"
        @blur="editName()"
      />
      <span
        v-else
        class="name"
      >{{ collectionName }}</span>
      <div class="header-right">
        <div class="icons-count">
          {{ iconsCount }}
        </div>
        <transition name="add">
          <AddNotification
            v-if="isAddNotificationShown"
            class="add-notification"
          />
        </transition>
      </div>
    </div>
    <div
      v-if="iconsToShow && iconsToShow.length"
      class="icons"
    >
      <div
        v-for="(icon, idx) in iconsToShow"
        :id="idx"
        :key="icon.id"
        class="icon-container"
      >
        <CollectionIconPreview
          :icon="icon"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex'

import CollectionIconPreview from '@/components/collections/CollectionIconPreview'
import AddNotification from '@/components/collections/notifications/AddNotification'

import { translateCollectionName } from '@/store/collections/_helpers'

function getNumberOfIconsToShow (domNode) {
  const iconSize = 40
  const nodeWidth = domNode.clientWidth
  const nodePaddingLeft = parseInt(
    window
      .getComputedStyle(domNode)
      .getPropertyValue('padding-left')
      .slice(0, -2)
  )
  const widthForIcons = nodeWidth - nodePaddingLeft
  return Math.ceil(widthForIcons / iconSize)
}

export default {
  name: 'CollectionInfo',
  components: {
    AddNotification,
    CollectionIconPreview,
  },
  props: {
    collection: {
      type: Object,
      required: true
    },
    creating: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      hover: false,
      numOfIconsToShow: 5,
      isAddNotificationShown: false,
      editedName: ''
    }
  },
  computed: {
    iconsToShow () {
      if (this.numOfIconsToShow) return this.collection.icons.slice(-this.numOfIconsToShow).reverse()
      return []
    },
    iconsCount () {
      return this.collection.iconsTotal || this.collection.icons.length
    },
    collectionName () {
      return translateCollectionName(this, this.collection)
    }
  },
  watch: {
    collection (newVal, oldVal) {
      if (newVal.icons.length === oldVal.icons.length + 1) {
        this.showAddNotification()
      }
    },
    creating: {
      handler (newValue, oldValue) {
        if (newValue && !oldValue) {
          this.$nextTick(() => {
            this.$refs.collectionNameInput.focus()
          })
        }
      }
    }
  },
  mounted () {
    this.numOfIconsToShow = getNumberOfIconsToShow(this.$el)
  },
  methods: {
    ...mapActions('collections', [
      'updateCollection',
      'deleteCollection'
    ]),
    showAddNotification () {
      this.isAddNotificationShown = true
      setTimeout(() => {
        this.isAddNotificationShown = false
      }, 500)
    },
    async editName () {
      if (this.editedName) {
        await this.updateCollection({id: this.collection.id, data: { name: this.editedName}})
      }
      this.editedName = ''
      this.$emit('created')
    },
    rejectCreation () {
      this.editedName = ''
      this.$emit('rejectCreation')
    }
  }
}
</script>

<style scoped lang="scss">
.collection-info {
  display: flex;
  flex-flow: column nowrap;
  gap: 12px;

  --collection-card-padding: calc(16px - var(--collection-card-active-border-width, 0px));
  padding: var(--collection-card-padding);

  height: 100%;

  transition: padding 0s, height 0s;
  overflow: hidden;
  cursor: pointer;
}

.header {
  display: flex;
  position: relative; // to allow the add notification to be placed above the header
  align-items: center;
  justify-content: space-between;

  min-height: 20px; // to prevent jumping on hover when there is no additional icon in header

  overflow: visible;
  z-index: 998;

  color: var(--c-black_900);

  @include font(--collection-card-title, var(--font-semibold), var(--font-base), 16px);
}

.name {
  max-width: calc(100% - 30px);

  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--c-black_900);
}

span.name {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
}

input.name {
  height: 20px;

  padding: 0;

  background: none;
  border: none;
  border-radius: 0;
  outline: none;

  &::placeholder {
    color: var(--c-transparent-black_400);
  }
}

.icons-count {
  font-style: normal;
  font-weight: 400;
  font-size: 14px;
  line-height: 20px;
  text-align: right;
  letter-spacing: -0.006em;
  color: var(--c-transparent-black_500);
}

.header-right {
  display: flex;
  align-items: center;
}

.icons {
  position: relative;

  display: flex;
  flex-flow: row nowrap;
  gap: 16px;
  margin-right: calc(0px - var(--collection-card-padding));

  overflow: hidden;

  &::after {
    content: '';

    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;

    width: 32px;

    background: linear-gradient(270deg, #EEEEEE 10%, rgba(255, 255, 255, 0) 100%);
  }
}

.add-notification {
  z-index: 999;
  position: fixed;
  margin-left: -5px;
  margin-top: -25px;
}

.add-enter {
  transform: scale(0);
}
.add-enter-to {
  transform: scale(1);
}
.add-enter-active {
  transition: all 1000ms cubic-bezier(0.25, 0.1, 0.25, 1);
}

.add-leave {
  opacity: 1;
}
.add-leave-to {
  opacity: 0;
  transform: translateY(-40px);
}
.add-leave-active {
  transition-timing-function: cubic-bezier(0.25, 0.1, 0.25, 1);
  transition-property: transform, opacity;
  transition-delay: 0s, 0.3s;
  transition-duration: 0.7s, 0.3s;
}
</style>
