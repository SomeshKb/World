// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-6dd510da]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-6dd510da]{display:none!important}}.collection__card[data-v-6dd510da]{display:flex;flex-flow:column nowrap;--collection-card-min-height:88px;height:100%;min-height:var(--collection-card-min-height);--collection-card-border-radius:8px;border-radius:var(--collection-card-border-radius);background:#eee;transition:border 0s;overflow:hidden}.collection__card_active[data-v-6dd510da]{--collection-card-active-border-width:2px;margin:calc(0 - var(--collection-card-active-border-width));border:var(--collection-card-active-border-width) solid var(--c-green_500)}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
