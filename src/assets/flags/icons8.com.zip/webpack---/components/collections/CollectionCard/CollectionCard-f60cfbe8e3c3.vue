<template>
  <div
    :class="['collection__card', {'collection__card_active': active}]"
  >
    <slot />
  </div>
</template>

<script>
import CollectionCardContainer from '../common/CollectionCardContainer'
export default {
  name: 'CollectionCard',
  components: {
    CollectionCardContainer
  },
  props: {
    active: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang="scss" scoped>
.collection__card {
  display: flex;
  flex-flow: column nowrap;

  --collection-card-min-height: 88px;
  height: 100%;
  min-height: var(--collection-card-min-height);

  --collection-card-border-radius: 8px;
  border-radius: var(--collection-card-border-radius);

  background: #EEEEEE;

  transition: border 0s;

  overflow: hidden;
  &_active {
    --collection-card-active-border-width: 2px;
    margin: calc(0 - var(--collection-card-active-border-width));

    border: var(--collection-card-active-border-width) solid var(--c-green_500);
  }
}
</style>
