<template>
  <div
    class="upload-state"
    :style="styles"
  >
    <div class="icon-container">
      <I8Icon
        :icon="icon"
        family="simpleSmall"
      />
    </div>
    <span>
      <slot />
    </span>
  </div>
</template>

<script>
import { I8Icon } from '@icons8/vue-kit'

export default {
  name: 'AddIconStateContainer',
  components: { I8Icon },
  props: {
    icon: {
      type: String,
      required: false,
      default: 'close'
    },
    color: {
      type: String,
      required: false,
      default: 'var(--c-red_500)'
    }
  },
  computed: {
    styles () {
      return {
        '--main-color': this.color
      }
    }
  }
}
</script>

<style scoped lang="scss">
.upload-state {
  --main-color: var(--c-red_500);
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  align-items: center;
}

.icon-container {
  --icon-color: var(--c-white);
  --size: 24px;

  width: var(--size);
  height: var(--size);
  border-radius: 50%;
  margin-bottom: 4px;

  display: flex;
  justify-content: center;
  align-items: center;

  background-color: var(--main-color);
}

span {
  color: var(--main-color);

  @include font(
      --upload-error-text,
      var(--font-normal),
      var(--font-sm),
      20px
  )
}
</style>
