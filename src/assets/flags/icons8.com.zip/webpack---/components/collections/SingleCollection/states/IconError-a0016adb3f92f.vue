<template>
  <div
    @mouseover="hover = true"
    @mouseleave="hover = false"
    @click="$emit('retry')"
  >
    <component
      :is="component"
      :is-message="isPreview"
    />
  </div>
</template>

<script>
import AddIconRetry from './AddIconRetry'
import AddIconError from './AddIconError'

export default {
  name: 'IconError',
  props: {
    isPreview: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  data () {
    return {
      hover: false
    }
  },
  computed: {
    component () {
      return this.hover ? AddIconRetry : AddIconError
    }
  }
}
</script>
