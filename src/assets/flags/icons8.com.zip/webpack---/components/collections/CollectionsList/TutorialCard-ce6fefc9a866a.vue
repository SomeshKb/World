// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-cb1ccc16]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-cb1ccc16]{display:none!important}}.tutorial-card[data-v-cb1ccc16]{display:flex;flex-flow:column nowrap;justify-content:center;align-items:center;padding:16px;gap:8px;--collection-card-min-height:88px;min-height:var(--collection-card-min-height);--collection-card-border-radius:8px;border:1px solid var(--c-transparent-black_200);border-radius:var(--collection-card-border-radius);text-align:center;font-style:normal;font-weight:400;font-size:12px;line-height:16px;color:var(--c-transparent-black_500)}.tutorial-card__icon[data-v-cb1ccc16]{width:16px;height:16px}.tutorial-card__icon_plus[data-v-cb1ccc16]{opacity:.4}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
