<template>
  <div class="icon-add-notification">
    <slot>
      +1
    </slot>
  </div>
</template>

<script>
export default {
  name: 'AddNotification'
}
</script>

<style scoped lang="scss">
.icon-add-notification {
  --size: 30px;

  display: flex;
  justify-content: center;
  align-items: center;

  width: var(--size);
  height: var(--size);

  padding: 5px;
  background: var(--c-red_500);
  color: var(--c-white);
  border-radius: 50%;
  border: 2px solid #FFFFFF;

  @include font(
    --icon-add-notification,
    var(--font-semibold),
    var(--font-xs),
    14px
  )
}
</style>
