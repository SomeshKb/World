// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-f012b784]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-f012b784]{display:none!important}}.icon-add-notification[data-v-f012b784]{--size:30px;display:flex;justify-content:center;align-items:center;width:var(--size);height:var(--size);padding:5px;background:var(--c-red_500);color:var(--c-white);border-radius:50%;border:2px solid #fff;font:var(--icon-add-notification,var(--icon-add-notification-weight,var(--font-semibold)) var(--icon-add-notification-size,var(--font-xs))/var(--icon-add-notification-line-height,14px) var(--icon-add-notification-family,var(--font-family-legacy)))}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
