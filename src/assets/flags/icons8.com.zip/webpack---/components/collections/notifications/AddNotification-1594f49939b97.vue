import { render, staticRenderFns } from "./AddNotification.vue?vue&type=template&id=f012b784&scoped=true&"
import script from "./AddNotification.vue?vue&type=script&lang=js&"
export * from "./AddNotification.vue?vue&type=script&lang=js&"
import style0 from "./AddNotification.vue?vue&type=style&index=0&id=f012b784&prod&scoped=true&lang=scss&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "f012b784",
  null
  
)

export default component.exports