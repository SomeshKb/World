<template>
  <div class="collection-icon-preview">
    <I8Loader
      v-if="icon.loading"
      color="--c-green_500"
      :size="24"
    />
    <IconError
      v-else-if="icon.addError"
      icon="close"
      family="simpleSmall"
      :is-preview="true"
    />
    <img
      v-else
      :src="iconUrl"
      :alt="`${icon.name} icon`"
    >
  </div>
</template>

<script>
import { getIconUrl } from './helpers'
import { I8Loader } from '@icons8/vue-kit'
import IconError from './SingleCollection/states/IconError'
export default {
  name: 'CollectionIconPreview',
  components: { I8Loader, IconError },
  props: {
    icon: {
      type: Object,
      required: true
    }
  },
  computed: {
    iconUrl () {
      return getIconUrl(this.icon.id)
    }
  }
}
</script>

<style scoped lang="scss">
.collection-icon-preview {
  --icon-size: 24px;
  height: var(--icon-size);
  width: var(--icon-size);
  border-radius: 4px;

  img {
    height: var(--icon-size);
    width: var(--icon-size);
  }
}
</style>
