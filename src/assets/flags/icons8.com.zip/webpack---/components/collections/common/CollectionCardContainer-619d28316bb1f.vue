<template>
  <div class="collection-card-container">
    <slot />
  </div>
</template>

<script>
export default {
  name: 'CollectionCardContainer'
}
</script>

<style scoped lang="scss">
.collection-card-container {
  min-width: 192px;
  height: 100%;
  background: transparent;
}
</style>
