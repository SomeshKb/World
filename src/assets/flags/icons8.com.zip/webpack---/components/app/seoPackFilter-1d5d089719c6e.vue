<template>
  <div class="seo-pack-filter">
    <menu-list
      :items="packList"
      @menu-item-click="menuItemClick"
    />
  </div>
</template>

<script>
import { mapState } from 'vuex'
import menuList from './menuList.vue'

export default {
  name: 'SeoPackFilter',
  components: {
    menuList
  },
  computed: {
    ...mapState({
      packs: state => state.appInfo.seoPacks,
      lang: state => state.i18n.locale,
      langUrl: state => state.i18n.url,
      filters: state => state.filters
    }),
    packList () {
      // format for menu
      const formattedList = this.packs.map(pack => {
        let url = `/icons/set/${pack.code}`
        if (this.filters.color) {
          url += `${this.filters.color ? '--' + this.filters.color : ''}`
        }
        if (this.filters.isAnimated !== undefined) {
          url += this.filters.isAnimated ? '--animated' : '--static'
        }
        return {
          id: pack.code,
          title: pack.name[this.lang] || pack.name['en-US'],
          url
        }
      })

      formattedList.sort((a, b) => {
        if (a.title > b.title) {
          return 1
        }
        if (a.title < b.title) {
          return -1
        }
        return 0
      })

      // add new icons
      formattedList.unshift({
        id: 'new-icons',
        title: this.$t('WEB_APP.NEW_ICONS'),
        url: '/icons/new'
      })
      return formattedList
    }
  },
  mounted () {
    this.$emit('countSeoFilters', this.packList.length)
  },
  methods: {
    menuItemClick () {
      this.$emit('menu-item-click')
    }
  }
}
</script>
<style lang="scss">
.seo-pack-filter {
  padding-bottom: 30px;
}
</style>
