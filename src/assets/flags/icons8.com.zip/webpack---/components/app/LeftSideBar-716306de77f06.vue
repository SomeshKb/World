import { render, staticRenderFns } from "./LeftSideBar.vue?vue&type=template&id=2e87a3de&scoped=true&"
import script from "./LeftSideBar.vue?vue&type=script&lang=js&"
export * from "./LeftSideBar.vue?vue&type=script&lang=js&"
import style0 from "./LeftSideBar.vue?vue&type=style&index=0&id=2e87a3de&prod&lang=scss&scoped=true&"
import style1 from "./LeftSideBar.vue?vue&type=style&index=1&id=2e87a3de&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "2e87a3de",
  null
  
)

export default component.exports