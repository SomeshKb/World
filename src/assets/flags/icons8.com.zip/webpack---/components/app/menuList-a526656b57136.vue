import { render, staticRenderFns } from "./menuList.vue?vue&type=template&id=1b40b2bc&scoped=true&"
import script from "./menuList.vue?vue&type=script&lang=js&"
export * from "./menuList.vue?vue&type=script&lang=js&"
import style0 from "./menuList.vue?vue&type=style&index=0&id=1b40b2bc&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "1b40b2bc",
  null
  
)

export default component.exports