// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-43323b60]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-43323b60]{display:none!important}}.similar-tags[data-v-43323b60]{margin:0 0 12px;height:24px;overflow:hidden}@media(min-width:900px){.similar-tags[data-v-43323b60]{margin:0 0 24px}}.similar-tags a[data-v-43323b60]{display:inline-block;color:var(--c-transparent-black_600);font-size:14px;font-weight:400;margin-right:16px;transition:all .2s}@media(max-width:600px){.similar-tags a[data-v-43323b60]{margin-bottom:10px}}.similar-tags a[data-v-43323b60]:hover{color:var(--c-black)}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
