import { render, staticRenderFns } from "./AppBottomInfo.vue?vue&type=template&id=6c5ea0c2&scoped=true&"
import script from "./AppBottomInfo.vue?vue&type=script&lang=js&"
export * from "./AppBottomInfo.vue?vue&type=script&lang=js&"
import style0 from "./AppBottomInfo.vue?vue&type=style&index=0&id=6c5ea0c2&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "6c5ea0c2",
  null
  
)

export default component.exports