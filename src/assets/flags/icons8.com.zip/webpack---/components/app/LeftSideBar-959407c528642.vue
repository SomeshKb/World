<template>
  <div
    v-if="sidebar.enabled"
    :class="sidebarClasses">
    <div
      class="app-left-sidebar-content"
    >
      <div class="left-sidebar-menu-wrap">
        <I8TabGroup
          class="left-sidebar-menu-tabs"
          type="filled"
          size="medium"
        >
          <I8Tab
            type="filled"
            size="medium"
            :active="activeTab === tabs.categories"
            @click="categoriesTabClick"
          >
            {{ $t('ICON.COMPONENTS.LEFT_SIDEBAR.CATEGORIES') }}
          </I8Tab>
          <I8Tab
            type="filled"
            size="medium"
            :active="activeTab === tabs.collections"
            @click="activeTab = tabs.collections"
          >
            {{ $t('ICON.COMPONENTS.LEFT_SIDEBAR.COLLECTIONS') }}
          </I8Tab>
        </I8TabGroup>


        <div class="left-sidebar-scroll i8-scroll">
          <template v-if="activeTab === tabs.categories">
            <div class="left-sidebar-menu">
              <keep-alive>
                <packFilter />
              </keep-alive>
            </div>
            <div class="left-sidebar-menu">
              <div class="title">
                {{ $t('ICON.COMPONENTS.LEFT_SIDEBAR.TRENDS') }}
              </div>
              <keep-alive>
                <SeoPackFilter />
              </keep-alive>
            </div>
          </template>

          <template v-else-if="activeTab === tabs.collections">
            <client-only>
              <keep-alive>
                <CollectionsList
                  :linksInCollections="linksInCollections"
                />
              </keep-alive>
            </client-only>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import SeoPackFilter from '@/components/app/seoPackFilter.vue'
import packFilter from '@/components/app/packFilter.vue'
import { I8TabGroup, I8Tab, I8Loader } from '@icons8/vue-kit'
import CollectionsList from '@/components/collections/CollectionsList/CollectionsList'
import OpenedCollectionSidebar from '@/components/collections/OpenedCollectionSidebar'

export default {
  name: 'LeftSideBar',
  components: {
    OpenedCollectionSidebar,
    SeoPackFilter,
    packFilter,
    CollectionsList,
    I8TabGroup,
    I8Tab,
    I8Loader
  },
  // serverCacheKey: props => JSON.stringify(props),
  props: {
    activeCollectionsTab: {
      type: Boolean,
      default: false
    },
    linksInCollections: {
      type: Boolean,
      default: false
    }
  },
  data: () => ({
    tabs: {
      categories: 0,
      collections: 1
    },
    activeTab: 0
  }),
  computed: {
    ...mapState({
      sidebar: state => state.ui.sidebars.left
    }),
    sidebarClasses () {
      return {
        'app-left-sidebar': true,
        'is-active': this.sidebar.active
      }
    },
    showStyle () {
      return ['icon-pack-pack-platform', 'icons-set-term', 'icon-set-term-platform'].some(
        item => item === this.$route.name
      )
    }
  },
  created () {
    if (this.activeCollectionsTab) {
      this.activeTab = this.tabs.collections
    }
  },
  methods: {
    ...mapActions([
      'showLeftSidebar',
      'hideLeftSidebar',
      'showRightSidebar',
      'hideRightSidebar',
      'setSidebarChapter',
    ]),
    ...mapActions('collections', ['closeCollection']),
    categoriesTabClick () {
      this.closeCollection()
      this.activeTab = this.tabs.categories
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~assets/css/variables';
@import '~assets/css/breakpoints';

.app-left-sidebar {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  z-index: 12;

  width: $left-sidebar-width-new;

  background: #FAFAFA;
  border-radius: 0 8px 0 0;

  will-change: transform;
  transition: 0.3s all ease-in-out;


  @media (max-width: $responsive-app-left-sidebars-new - 1px) {
    left: -$left-sidebar-width-new;
    z-index: 20;
    &.is-active {
      transform: translateX($left-sidebar-width-new);
    }
  }

  .app-left-sidebar-content {
    overflow-y: hidden;
    height: 100%;
    display: flex;
    flex-direction: column;
    position: relative;
    max-height: 100%;
  }

  .left-sidebar-menu-wrap {
    display: flex;
    flex-flow: column nowrap;
    align-items: center;
    gap: 16px;

    height: 100%;
    padding-top: 16px;
  }

  .left-sidebar-menu-tabs {
    display: flex;
    flex-flow: row nowrap;

    width: 192px;

    padding: 4px;

    background-color: #EEEEEE;
    border-radius: 8px;
    --tab-filled-background-color: transparent;
    --tab-filled-padding: 2px 9px;
    --tab-filled-active-background-color: var(--c-white);

    & .i8-tab {
      font-style: normal;
      font-weight: 400;
      font-size: 14px;
      line-height: 20px;
      letter-spacing: -0.006em;
      color: var(--c-black_900);

      &:hover:not(&--active) {
        background: var(--c-transparent-black_100);
      }

      &--active {
        font-weight: 600;
        box-shadow: 0 0 1px rgba(96, 96, 96, 0.31), 0 1px 1px rgba(96, 96, 96, 0.15);
      }
    }
  }

  .left-sidebar-scroll {
    width: 100%;

    align-self: flex-start;

    --actual-scrollbar-width: 10px;
    --left-sidebar-padding: 16px;
    padding: 0 calc(var(--left-sidebar-padding) - var(--actual-scrollbar-width)) 16px var(--left-sidebar-padding);
    margin-right: calc(0px - var(--actual-scrollbar-width));

    overflow-y: scroll;
    --scroll-auto-hide: hidden;
  }
}

.left-sidebar-menu {
  font-family: var(--font-family-global);

  & .title {
    position: sticky;
    top: 0;
    z-index: 1;

    padding: 0 8px 6px;

    background: #FAFAFA;

    font-size: 14px;
    line-height: 20px;
    letter-spacing: -.006em;
    font-weight: 600;
  }

  &:last-child:not(:first-child) {
    padding-top: 16px;
  }

  :deep(.list) {
    max-height: 100%;

    .list-item {
      font-weight: normal;
      line-height: 20px;
      letter-spacing: -0.006em;
      padding: 6px 8px;
      font-size: 14px;
      margin: 0;

      &:hover {
        background: var(--c-transparent-black_100);
      }

      &.is-active, &:active {
        color: var(--c-transparent-black_900);
        background: var(--c-transparent-black_200);
      }
    }
  }
}
</style>

<style lang="scss">
.app-left-sidebar {
  & .collections__new-collection-btn {
    margin-bottom: 8px;
  }
}
</style>
