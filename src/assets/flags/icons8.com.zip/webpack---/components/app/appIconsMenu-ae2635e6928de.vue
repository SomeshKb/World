<template>
  <div :class="{ 'app-icons-menu': true, 'is-submenu-active': isSubmenuOpen }">
    <I8Header
      id="header"
      ref="I8Header"
      :path="langPath"
      :local-logo="{ title: 'Icons' }"
      :local-links="desktopLinks"
      variant="product"
    >
      <template v-slot:adjective>
        <div class="mob-navs">
          <a
            v-for="(link, idx) in mobileLinks"
            :key="idx"
            :href="link.url"
            @click.prevent="openNav(link.type, link.url, link.spa)"
          >
            {{ link.title }}
          </a>
        </div>

        <div
          class="submenu"
          :class="{ 'submenu--active': isSubmenuOpen }"
        >
          <div class="submenu-head">
            <a
              class="arrow-back"
              @click.prevent="closeSubmenu"
            >
              <I8Icon
                icon="arrow"
                family="materialOutline"
              />
            </a>

            <span class="category">
              {{ linksCategories[selectedCategoryId].title }}
            </span>

            <a
              class="close-cross"
              @click.prevent="closeMenu"
            >
              <I8Icon
                icon="close"
                family="materialOutline"
              />
            </a>
          </div>

          <packFilter
            v-if="selectedCategoryId === 0"
            id="filter"
            @menu-item-click="menuItemClick"
          />

          <seoPackFilter
            v-else
            id="filter"
            @menu-item-click="menuItemClick"
          />
        </div>
      </template>
    </I8Header>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import I8Header from 'icons8-common/src/components/I8Header'
import { openAuthModal } from 'icons8-common/src/components/I8Auth/helper'
import seoPackFilter from '~/components/app/seoPackFilter.vue'
import packFilter from '~/components/app/packFilter.vue'
import { I8Icon } from '@icons8/vue-kit'
import { clearFilterParams } from '@/utils'

export default {
  name: 'AppIconsMenu',
  components: {
    I8Header,
    packFilter,
    seoPackFilter,
    I8Icon
  },

  data () {
    return {
      isSubmenuOpen: false,
      selectedCategoryId: 0,
      linksCenter: [
        {
          title: this.$t('WEB_APP.MENU.NEW_ICONS'),
          url: '/icons/new',
          spa: true
        },
        {
          title: this.$t('WEB_APP.MENU.STYLES'),
          url: '/icons#styles',
          spa: true
        },
        {
          title: this.$t('WEB_APP.MENU.REQUEST'),
          url: '/icons/request-icon',
          spa: true
        }
      ],
    }
  },

  computed: {
    ...mapState({
      activeLicense: state => state.auth.user.activeLicense,
      user: state => state.auth.user,
      selectPlatformChanged: state => state.ui.selectPlatformChanged,
      packs: state => state.appInfo.packs,
      filters: state => state.filters,
      platform: state => state.platform
    }),
    linksCategories() {
      if (this.platform.packs.length) {
        return [
          {
            title: this.$t('ICON.COMPONENTS.LEFT_SIDEBAR.CATEGORIES'),
            url: '/categories',
            type: 'category',
            spa: true
          },
          {
            title: this.$t('ICON.COMPONENTS.LEFT_SIDEBAR.TRENDS'),
            url: '/trends',
            type: 'category',
            spa: true
          }
        ]
      }
      return [
        {
          title: this.$t('ICON.COMPONENTS.LEFT_SIDEBAR.TRENDS'),
          url: '/trends',
          type: 'category',
          spa: true
        }
      ]
    },
    activeLicense (activeLicense) {
      return this.user.activeLicense
    },
    userIcon () {
      return this.activeLicense ? this.$icons.allAccess : this.$icons.rasterUserIcon
    },
    mobileLinks () {
      // return this.linksCenter
      //   .concat(this.linksCategories)
      //   .concat(this.linksRight)
      return [
        ...this.linksCenter,
        ...this.linksCategories,
        ...this.linksRight
      ]
    },
    linksRight () {
      return [
        {
          title: this.$t('WEB_APP.MENU.APPS'),
          url: '/app',
          spa: false
        },
        {
          title: this.$t('WEB_APP.MENU.PLUGINS'),
          url: '/app',
          spa: false
        },
        {
          title: this.$t('WEB_APP.MENU.COLLECTIONS'),
          type: 'collection',
          spa: false,
          isMobileOnly: true
        },
        {
          title: this.$t('WEB_APP.MENU.PRICING'),
          url: '/pricing',
          spa: false
        }
      ]
    },
    desktopLinks () {
      return [
        ...this.linksCenter,
        ...this.linksRight.filter(link => !link.isMobileOnly)
      ]
    },
    isPackPage () {
      if (!this.$route.params.term) {
        return false
      }
      const term = clearFilterParams(this.$route.params.term, this.filters)
      const query = term.replace(/-/g, ' ') // remove "-" from query (term)
      const preQuery = query.replace(/[/\\^$*+?.()|[\]{}]/g, '')
      const re = new RegExp(`^${preQuery}$`, 'i') // RegExp for searching category name matching
      const pack = this.packs.find(pack => re.test(pack.name[this.$i18n.localeProperties.iso]))
      return !!pack
    },
    langPath () {
      if (this.isPackPage) return ''
      if (this.$route.name === 'icon-id-name') return '/icons'

      let term = this.$route.params?.term
      if (!term) return ''
      term = clearFilterParams(term, this.filters)
      const toIconLanding = term.length > 30 || term.split('-').length > 2
      return toIconLanding ? '/icons' : ''
    }
  },
  watch: {
    selectPlatformChanged (state) {
      if (state) {
        this.resetSelectPlatform()
      }
    }
  },
  methods: {
    ...mapActions(['resetSelectPlatform']),
    openNav (type, url, isSpa) {
      if (type === 'category') {
        this.isSubmenuOpen = true
        window.scrollTo(0, 0)
        const idx = this.linksCategories.findIndex(el => el.url === url)
        this.selectedCategoryId = idx
      } else if (type === 'collection') {
        this.$router.push('/icons/collections')
      } else if (!isSpa) {
        window.location = url
      } else this.$router.push(url)
    },
    closeSubmenu () {
      window.scrollTo(0, 0)
      this.isSubmenuOpen = false
    },
    closeMenu () {
      this.isSubmenuOpen = false
      this.$refs.I8Header.toggleBurger()
    },
    menuItemClick () {
      this.closeSubmenu()
    }
  }
}
</script>

<style lang="scss" scoped>
.app-icons-menu {
  --i8-mobile-nav-padding: 24px 20px 106px;

  &.is-submenu-active {
    overflow: hidden;
  }
}

:deep(.i8-mobile-nav) {
  max-height: calc(100vh - var(--i8-header-height, 60px));
  overflow-y: auto;
}

.mob-navs {
  padding-bottom: 1.5rem;
  margin-bottom: 1rem;
  border-bottom: 1px solid var(--c-transparent-black_200);
  font-size: var(--font-sm);

  > a {
    display: block;
    font-weight: bold;
    color: var(--c-text);

    &:not(:first-child) {
      margin-top: 1rem;
    }
  }
}

.submenu {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 21;
  height: 100%;
  background: var(--c-white);
  overflow: hidden;
  height: 100vh;
  transform: translateX(100%);
  transition: all 200ms;

  &--active {
    transform: translateX(0);
  }
}

.submenu-head {
  padding: 18px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.arrow-back {
  height: 24px;
  width: 24px;
  display: block;
}

.category {
  font-size: var(--font-sm);
  font-weight: var(--font-semibold);
  line-height: 20px;
  letter-spacing: -0.006em;
}

.close-cross {
  height: 24px;
  width: 24px;
  display: block;
}

#filter :deep(.list) {
  max-height: calc(100vh - 60px);

  .list-item {
    padding: 0 12px;
    color: var(--c-transparent-black_900);
    font-size: var(--font-sm);
    font-weight: var(--font-normal);
    &:last-child {
      margin-bottom: 5px;
    }
  }
}
</style>
