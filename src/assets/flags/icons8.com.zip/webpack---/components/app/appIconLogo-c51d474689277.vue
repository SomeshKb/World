// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-523bcf0f]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-523bcf0f]{display:none!important}}.logo[data-v-523bcf0f]{background:transparent;width:30px;height:30px;display:flex}.logo span[data-v-523bcf0f]{display:block}.logo .rectangle[data-v-523bcf0f]{height:100%}.logo .circle[data-v-523bcf0f],.logo .rectangle[data-v-523bcf0f]{width:15px;box-sizing:border-box;background-color:#28b351}.logo .circle[data-v-523bcf0f]{height:50%;border-radius:100%}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
