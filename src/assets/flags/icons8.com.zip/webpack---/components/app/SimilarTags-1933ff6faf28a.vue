<template>
  <div class="similar-tags">
    <nuxt-link
      v-for="(tag, i) in normilizedTags"
      :key="i"
      :to="tag.url"
    >
      {{ tag.label }}
    </nuxt-link>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import parserUrlParams from '~/plugins/parser-url-params'

export default {
  name: 'SimilarTags',
  props: {
    tags: {
      type: Array,
      default: () => []
    }
  },
  computed: {
    ...mapState({
      platform: state => state.platform
    }),
    normilizedTags () {
      return this.tags.map(el => {
        const label = el.toLowerCase()
        const mainPath = parserUrlParams(this.$route.fullPath)
        let colorParam = ''
        if (mainPath.color) colorParam = `--${mainPath.color}`
        const result = {
          label
        }
        if (this.platform.seoCode && this.platform.seoCode !== 'all') {
          result.url = `/icon/set/${label.split(' ').join('-')}/${this.platform.seoCode}${colorParam}`
        } else {
          result.url = `/icons/set/${label.split(' ').join('-')}${colorParam}`
        }
        return result
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.similar-tags {
  margin: 0 0 12px 0;
  height: 24px;
  overflow: hidden;
  @media (min-width: 900px) {
    margin: 0 0 24px 0;
  }
  & a {
    display: inline-block;
    color: var(--c-transparent-black_600);
    font-size: 14px;
    font-weight: 400;
    margin-right: 16px;
    transition: all 200ms;

    @media (max-width: 600px) {
      margin-bottom: 10px;
    }
    &:hover{
      color: var(--c-black);
    }
  }
}
</style>
