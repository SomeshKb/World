<template>
  <div
    class="search-filters"
    :class="{ 'mobile-show': mobileFilterActive }"
  >
    <div class="mobile-filters-header">
      {{ $t('WEB_APP.FILTERS.TITLE') }}
      <I8Button
        type="large"
        class="filter-close-btn"
        @click="toggleMobileFilter(!mobileFilterActive)"
      >
        <I8Icon
          icon="close"
          family="materialOutline"
          size="24px"
        />
      </I8Button>
    </div>
    <div class="search-filters-group">
      <StyleSelect
        v-if="showStyleFilter"
        :isColor="isColor"
      />
      <AnimationSelect
        v-if="showAnimationFilter"
        class="select"
        :isColor="isColor"
      />
      <AuthorsSelect
        v-if="showAuthorsFilter"
        class="select"
      />
      <AppColorSelect
        v-model="currentColor"
        v-if="showColorFilter"
        class="search-filters-group__select_color select"
        @change="changeColor"
      />
      <GradientColorSelect
        v-if="showGradientColorFilter"
      />
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import { I8Button, I8Icon } from '@icons8/vue-kit'
import ColorSelect from '@/components/controls/ColorSelect'
import AppColorSelect from '@/components/controls/appColorSelect'
import StyleSelect from '@/components/controls/style-select/StyleSelect'
import AnimationSelect from '@/components/controls/AnimationSelect'
import AuthorsSelect from '@/components/controls/AuthorsSelect'
import GradientColorSelect from '@/components/controls/gradient-color-select/GradientColorSelect'
import { useFilter } from '@/composables/useFilter'

export default {
  name: 'SearchFilters',
  components: {
    ColorSelect,
    StyleSelect,
    AnimationSelect,
    AuthorsSelect,
    GradientColorSelect,
    AppColorSelect,
    I8Button,
    I8Icon
  },
  data () {
    return {
      notShowStyleFilterOn: ['icons-pack-pack'],
      platformsWithOutColor: [
        'color',
        'm_two_tone',
        'office',
        'dusk',
        'ultraviolet',
        'nolan',
        'cotton',
        'doodle',
        'flat_round',
        'clouds',
        'bubbles',
        'plasticine',
        'cool',
        'fluent',
        'plumpy'
      ],
      animationFilterPages: [
        'icons-set-term',
        'icon-set-term-platform',
        'icon-pack-pack-platform',
        'icons-platform'
      ],
      authorsFilterPages: [
        'icons-set-term',
        'icons-new',
        'icons-new-filter'
      ],
      currentColor: null
    }
  },
  computed: {
    ...mapState({
      lang: state => state.i18n.locale,
      packs: state => state.appInfo.packs,
      platform: state => state.platform,
      platforms: state => state.appInfo.platforms,
      isAnimated: state => state.filters.isAnimated,
      authors: state => state.filters.authors,
      baseColor: state => state.color,
      color: state => state.filters.color,
      mobileFilterActive: state => state.ui.mobileFilterActive,
      currentPlatform: state => state.platform,
    }),
    showColorFilter () {
      const isSeoCode = !this.platformsWithOutColor.some(platform => platform === this.platform.seoCode)
      return (isSeoCode && !this.isColor) && !this.isAnimated
    },
    showStyleFilter () {
      return !this.notShowStyleFilterOn.some(page => page === this.$route.name)
    },
    showAnimationFilter () {
      return this.animationFilterPages.some(page => page === this.$route.name)
    },
    showAuthorsFilter () {
      if (!process.env.areExternalAuthorsVisible) return false
      if (this.$route.name?.includes('icons-set-term')) {
        return !this.isPackPage
      }
      return this.authorsFilterPages.some(page => page === this.$route.name)
    },
    showGradientColorFilter () {
      return this.platform.apiCode === 'nolan' && !this.isAnimated
    },
    isPackPage () {
      const params = this.$route.params
      const query = params.term.replace(/-/g, ' ') // remove "-" from query (term)
      const preQuery = query.replace(/[/\\^$*+?.()|[\]{}]/g, '')
      const re = new RegExp(`^${preQuery}$`, 'i') // RegExp for searching category name matching
      const pack = this.packs.find(pack => re.test(pack.name[this.lang]))
      if (pack) {
        return true
      }
      return false
    },
    isColor() {
      return this.platforms[this.platform.apiCode]?.isColor
    }
  },
  watch: {
    baseColor(value) {
      this.currentColor = value
    }
  },
  created() {
    this.currentColor = this.baseColor
  },
  beforeDestroy () {
    this.toggleMobileFilter(false)
  },
  methods: {
    ...mapActions([
      'toggleMobileFilter',
    ]),
    changeColor() {
      this.$router.push(useFilter(this.$store).changeFilters({
        request: null,
        currentFilter: this.currentColor.code || this.currentColor.value,
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authors,
        color: this.currentColor.code || this.currentColor.value,
        platform: this.currentPlatform.seoCode,
        isPlatformColor: null
      }))
    },
    animatedParamsNormalize(value) {
      let animatedParams = null
      if (value) {
        animatedParams = 'animated'
      } else if (value === false) {
        animatedParams = 'static'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    },
  }
}
</script>

<style lang="scss" scoped>
@import '~assets/css/mixins';
.search-filters {
  @media (max-width: 1023px) {
    display: none;
    position: fixed;
    z-index: 99999999;
    left: 0;
    right: 0;
    top: 45px;
    bottom: 0;
    background-color: #fff;
    overflow: auto;
    &.mobile-show {
      display: block;
    }
  }

  .search-filters-group {
    display: flex;
    flex-direction: column;

    @media (min-width: 1024px) {
      flex-direction: row;
      flex-wrap: wrap;
      gap: 8px;
    }
  }

  --dropdown-outline-width: 100%;
  --dropdown-chosen-margin: 0 var(--spacer-xs) 0 0;
  --dropdown-content-width: 200px;
  --dropdown-close-margin: 0 0 0 var(--spacer-xs);

  .filter-close-btn {
    --button-padding-large: 0;
    --button-height-large: 44px;
    --button-border-radius: 50%;
    --button-border-text: 1px solid var(--c-transparent-black_200);
    width: var(--button-height-large);
  }

  .mobile-filters-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 10px 10px 20px;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    border-bottom: 1px solid var(--c-transparent-black_200);

    @media (min-width: 1024px) {
      display: none;
    }
  }

  .search-filters-group {
    @media (min-width: 1300px) {
      margin: 0;
    }
    @media (max-width: 1023px) {
      padding: 14px 40px;
    }
    @media (max-width: 480px) {
      padding: 14px 20px;
    }
  }
}
.search-filters-group {
  &__select_color {
    @include max(1024) {
      width: 100%;
      display: block;
    }
  }
}
</style>

<style lang="scss">
.search-filters {
  .desktop-filter {
    .i8-dropdown__label {
      background-color: #FAFAFA;
    }
    .i8-dropdown__label--is-open {
      background-color: var(--c-black_200);
    }
  }

  .i8-dropdown__content--is-open {
    display: block;
    z-index: 12;
  }

  @media (max-width: 1023px) {
    .desktop-filter {
      display: none;
    }
    .color-select {
      order: 2;
    }
    .animation-select {
      order: 3;
    }
    .authors-select {
      order: 4;
    }
  }

  @media (min-width: 1024px) {
    .mobile-filter {
      display: none;
    }
  }
}
</style>
