import { render, staticRenderFns } from "./appIconsMenu.vue?vue&type=template&id=50e62b68&scoped=true&"
import script from "./appIconsMenu.vue?vue&type=script&lang=js&"
export * from "./appIconsMenu.vue?vue&type=script&lang=js&"
import style0 from "./appIconsMenu.vue?vue&type=style&index=0&id=50e62b68&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "50e62b68",
  null
  
)

export default component.exports