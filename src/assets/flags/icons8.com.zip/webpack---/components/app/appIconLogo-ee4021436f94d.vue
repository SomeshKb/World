import { render, staticRenderFns } from "./appIconLogo.vue?vue&type=template&id=523bcf0f&scoped=true&"
import script from "./appIconLogo.vue?vue&type=script&lang=js&"
export * from "./appIconLogo.vue?vue&type=script&lang=js&"
import style0 from "./appIconLogo.vue?vue&type=style&index=0&id=523bcf0f&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "523bcf0f",
  null
  
)

export default component.exports