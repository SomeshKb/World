<template>
  <div class="app-header">
    <div class="content">
      <SimilarTags
        v-if="similarTags && similarTags.length"
        :tags="similarTags"
      />
      <client-only>
        <!-- Switch horizontalAd selfBSA | nativeBSA | CarbonAds | pixFuture -->
        <div class="ads">
          <SwitcherAds
            v-if="!isMobile()"
            @approveAds="approveAds"
          />
        </div>
      </client-only>
      <div class="box-header">
        <div
          v-if="showTitle && seo && seo.page"
          class="title-wrap"
        >
          <h1
            v-if="showTitle && seo.page.title"
            class="app-title"
          >
            {{ title }}
          </h1>
        </div>
      </div>
    </div>

    <!-- Here may will be you ads -->
  </div>
</template>

<script>
import { mapState } from 'vuex'
import SwitcherAds from '@/components/ads/SwitcherAds'
import SimilarTags from '~/components/app/SimilarTags'
import { isMobile } from '@icons8/frontend-utils'

export default {
  name: 'AppHeader',
  components: {
    SwitcherAds,
    SimilarTags
  },
  props: {
    showTitle: {
      type: Boolean,
      default: true
    },
    foundAmount: {
      type: Number,
      default: null
    },
    similarTags: {
      type: Array,
      default: null
    }
  },
  data () {
    return {
      horizontalAd: null
    }
  },
  computed: {
    ...mapState({
      platform: state => state.platform,
      seo: state => state.seo.data,
      user: state => state.auth.user,
      pack: state => state.pack
    }),
    title () {
      const color = this.$store.state.filters.color?.toUpperCase()
      let title = ''
      if (color && !color.includes('#')) {
        title = this.$t(`WEB_APP.NEW_ICONS_TITLE_${color}`)
      }

      if (this.foundAmount) return this.foundAmount + ' ' + title
      return title
    }
  },
  mounted () {
    this.currentPlatform = this.platform.apiCode
  },
  methods: {
    isMobile,
    approveAds (ad) {
      this.horizontalAd = ad
      console.log('header ads', ad)
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~assets/css/variables';
@import '~assets/css/mixins';
.app-header {
  position: relative;
  display: flex;
  justify-content: space-between;
  width: 100%;

  .content {
    width: 100%;
  }

  @media (max-width: 1300px) {
    flex-direction: column;
  }
}
.app-page {
  .box-header {
    position: relative;
    margin-top: auto;
    opacity: 1;
    transition: all 0.3s;
  }
  .title-wrap {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    // margin-top: 16px;
    // margin-bottom: 8px;
    // margin-top: 32px;

    .attr-filter {
      margin-left: 16px;
    }

    @media (max-width: 600px) {
      flex-direction: column;
      align-items: flex-start;

      .attr-filter {
        margin-left: 0;
        margin-top: 16px;
      }
    }

    @media (max-width: 600px) {
      margin-top: 12px;
    }
  }
  .switcher-ads.is-ad {
    margin-top: 10px;
  }
  .app-title {
    color: $sidebar-l_text-color;
    margin: 0;
    font-weight: bold;
    font-size: 18px;
    line-height: 24px;
    letter-spacing: -0.006em;
    max-width: 680px;
    &:first-letter {
      text-transform: none;
    }
  }

  .app-page-subtitle {
    color: $color-font-light;
  }
}

.carbon-ads {
  position: fixed;
  z-index: 20;
  right: 20px;
  bottom: 20px;
}

.badge-wrap {
  vertical-align: super;
}
</style>
