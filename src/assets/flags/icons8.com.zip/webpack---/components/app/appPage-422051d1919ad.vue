<template>
  <div
    ref="page"
    class="app-page"
    :class="pageClasses"
    @click="onClick"
  >
    <SearchBar v-if="searchBar" :show-filters="showFilters" />
    <crisp-helper />
    <slot />
  </div>
</template>

<script>
import SearchBar from '~/components/app/search/SearchBar.vue'

export default {
  name: 'AppPage',
  components: { SearchBar },
  props: {
    sidebars: {
      type: Object,
      default: () => ({ left: {}, right: {} })
    },
    searchBar: {
      type: Boolean,
      default: true
    },
    showFilters: {
      type: Boolean,
      required: false,
      default: true
    }
  },
  data () {
    return {
      sectionTitle: null,
      reached25: false,
      reached50: false,
      reached75: false,
      reached90: false
    }
  },
  computed: {
    pageClasses () {
      return {
        'is-left-sidebar-disabled': !this.sidebars.left.enabled,
        'is-right-sidebar-disabled': !this.sidebars.right.enabled,
        'is-right-sidebar-active': this.sidebars.right.active,
        'i8-scroll': true
      }
    }
  },
  methods: {
    onClick () {
      this.$emit('clicked')
    }
  }
}
</script>

<style lang="scss">
  @import '../../assets/css/variables';
  @import '../../assets/css/breakpoints';
  @import '../../assets/css/mixins';

  .clearfix:after {
    display: block;
    content: '';
    clear: both;
  }

  .app-page {
    position: absolute;
    top: 0;
    left: $left-sidebar-width-new;
    right: 0;
    bottom: 0;
    overflow-y: auto;
    transition: 0.3s all ease;
    background: #fff;
    --scroll-auto-hide: hidden;

    @media (max-width: $responsive-app-left-sidebars-new - 1px) {
      left: 0;
      width: 100%;
    }

    &[data-simplebar] {
      position: absolute;
    }

    &.is-left-sidebar-disabled {
      left: 0;
    }
    &.is-static {
      position: static;
    }

    .breadcrumbs {
      text-align: left;
      white-space: nowrap;
      & .item {
        display: inline-block;
        min-height: 26px;
        min-width: 1px;
        color: #7C7C7C;
        fill: #98989A;
        vertical-align: top;
        margin-bottom: 14px;
        margin-right: 4px;
        transition: opacity .4s;
      }
      & a.item {
        color: $color-blue;
      }
      & .badge {
        margin-left: 10px;
      }
    }

    .app-title {
      margin: 20px 0 5px;
      font-size: 48px;
      line-height: 64px;
      font-weight: 700;
      text-align: left;
      &:first-letter {
        text-transform: capitalize;
      }
      & .badge {
        margin-left: 10px;
      }
    }

    .app-page-subtitle {
      padding: 0;
      margin: 12px auto;
      color: $color-font;
      text-align: center;
      font-size: 20px;
      max-width: 680px;
      p {
        margin: 0;
      }

      @media (max-width: 800px) {
        font-size: 16px;
      }

      &.is-left {
        text-align: left;
      }

      &.is-small {
        color: var(--c-black_900);
        font-size: var(--h4-font-size);
        font-weight: var(--font-normal);
        line-height: var(--h4-line-height);
        margin: 0;

        a {
          position: relative;
          color: var(--c-black_900);
          padding-bottom: 2px;
          border-bottom: 1px solid rgba(26, 26, 26, 0.26);
        }
      }

      &.is-platform {
        font-size: 16px;
        max-width: 100%;
        text-align: left;
        margin-left: 0;
        margin-bottom: 64px;
        padding-left: 0;
        color: black;
      }
    }
    .app-page-section {
      padding: 32px;
      @media (max-width: 768px) {
        padding: 32px 24px;
      }
      &:empty {
        display: none;
      }

      &.custom-padding {
        padding: 12px 10px 0 20px;
      }
      &.description-padding {
        padding: 40px 0;
      }
      &.ads-padding {
        padding: 0 40px;
      }
      &.short-padding {
        padding: 24px 24px 12px;
      }
      &.is-loading {
        @include loading;
      }
      &.is-underline {
        border-bottom: 1px solid $color-grey;
      }
      &.is-grey {
        background-color: #fafafa;
      }
      &.ph-descr-wrap {
        padding-top: 0;
      }
      &.is-body {
        padding: 16px 20px;
      }
      @include min(768) {
        &.custom-padding {
          padding: 12px 32px 0 32px;
        }
        &.is-body {
          padding: 24px 32px 0;
        }
      }
    }
    .app-page-section-title {
      display: flex;
      align-items: center;
      text-align: left;
      text-transform: none;
      letter-spacing: -0.005em;
      white-space: nowrap;
      margin: 20px 0 24px;
      font-weight: var(--font-bold);
      &:after {
        content:"";
        bottom: 0;
        width: 100%;
        height: 1px;
        margin-left: 24px;
        background: var(--c-transparent-black_200);
      }
    }
  }
</style>
