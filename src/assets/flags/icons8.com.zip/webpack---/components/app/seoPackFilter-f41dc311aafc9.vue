import { render, staticRenderFns } from "./seoPackFilter.vue?vue&type=template&id=5b676fc4&"
import script from "./seoPackFilter.vue?vue&type=script&lang=js&"
export * from "./seoPackFilter.vue?vue&type=script&lang=js&"
import style0 from "./seoPackFilter.vue?vue&type=style&index=0&id=5b676fc4&prod&lang=scss&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports