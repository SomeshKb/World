// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../../../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-167e0b64]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-167e0b64]{display:none!important}}.detail-item[data-v-167e0b64]{display:flex;padding:4px 10px;border-radius:4px;cursor:pointer}.detail-item.is-active[data-v-167e0b64]{font-weight:600;background-color:var(--c-transparent-black_100)}.title[data-v-167e0b64]{display:flex;align-items:center;margin-right:5px;white-space:nowrap;font-size:14px;line-height:20px;letter-spacing:-.006em}.title-before[data-v-167e0b64]{margin-right:8px}.icon-selected[data-v-167e0b64]{display:block;margin-left:auto}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
