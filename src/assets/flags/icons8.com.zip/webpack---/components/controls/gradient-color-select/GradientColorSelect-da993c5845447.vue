<template>
  <div class="gradient-color-select select">
    <I8Dropdown
      :value="$t('WEB_APP.SEO.FILTERS.RECOLOR')"
      class="gradient-color-list desktop-filter"
      mode="outline"
      size="large"
      :select="true"
      :cleanable="false"
    >
      <template slot="leftIcon">
        <div
          v-if="activeGradientColor"
          class="color-icon has-color"
          :style="{ 'background': activeGradientColor }"
        />
        <div
          v-else
          class="color-icon"
        >
          <img
            :src="defaultIconUrl"
            alt="Color wheel"
          >
        </div>
      </template>
      <div class="gradient-color-wrap">
        <div
          v-for="gradient in gradients"
          :key="`gc${gradient.id}`"
          :class="['gc-item', { 'is-active': isGradientActive(gradient.id) }]"
          :style="{ 'background': gradient.value }"
          @click="selectGradient(gradient)"
        />
      </div>
    </I8Dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.SEO.FILTERS.RECOLOR')"
      class="mobile-filter"
    >
      <template #summary-addon>
        <div
          v-if="activeGradientColor"
          class="detail-gradient-color-item"
          :style="{ 'background': activeGradientColor }"
        />
        <div
          v-else
          class="color-icon"
        >
          <img
            :src="defaultIconUrl"
            alt="Color wheel"
          >
        </div>
      </template>
      <template #content>
        <div class="mobile-gradient-color-wrap">
          <div
            v-for="gradient in gradients"
            :key="`gc${gradient.id}`"
            :class="['gc-item', { 'is-active': isGradientActive(gradient.id) }]"
            :style="{ 'background': gradient.value }"
            @click="selectGradient(gradient)"
          />
        </div>
      </template>
    </DetailExpander>
  </div>
</template>

<script>
import { I8Dropdown } from '@icons8/vue-kit'
import { mapActions, mapState } from 'vuex'
import { getGradientColorList } from './GradientHelper'
import DetailExpander from '../details/DetailExpander'

export default {
  name: 'GradientColorSelect',
  components: { I8Dropdown, DetailExpander },
  data () {
    return {
      gradients: getGradientColorList()
    }
  },
  computed: {
    ...mapState({
      colorGradient: state => state.filters.colorGradient,
      mobileFilterActive: state => state.ui.mobileFilterActive
    }),
    activeGradientColor () {
      return this.colorGradient
        ? this.gradients.find(gradient => gradient.id === this.colorGradient.id)?.value
        : undefined
    },
    defaultIconUrl () {
      return `${process.env.staticUrl ?? ''}/vue-static/icon/color-wheel.png`
    }
  },
  methods: {
    ...mapActions(['setFilterColorGradient']),
    selectGradient (gradient) {
      if (this.isGradientActive(gradient.id)) { // if active gradient selected
        this.setFilterColorGradient(undefined)
        return
      }
      this.setFilterColorGradient({
        id: gradient.id,
        start: gradient.start,
        end: gradient.end
      })
    },
    isGradientActive (gradientId) {
      return this.colorGradient && this.colorGradient.id === gradientId
    }
  }
}
</script>

<style lang="scss" scoped>
  .gradient-color-select {
    margin-bottom: 4px;
  }
  .gradient-color-list {
    --dropdown-content-padding: 16px;
    --dropdown-content-width: 202px;
    --dropdown-label-padding-large: 0 var(--spacer-sm) 0 var(--spacer-xs);
    --dropdown-outline-width: 100%;
  }
  .gradient-color-wrap {
    display: grid;
    grid-template: repeat(3, 30px) / repeat(5, 30px);
    grid-gap: 5px;
  }
  .gc-item {
    width: 30px;
    height: 30px;
    cursor: pointer;
    flex-shrink: 0;
    border-radius: 4px;
    &:not(:last-child) {
      margin-right: 5px;
    }
    &.is-active {
      box-shadow: 0 0 0 1px var(--c-white), 0 0 0 3px var(--c-blue_500);
    }
  }
  .color-icon {
    width: 24px;
    height: 24px;
    display: flex;
    &.has-color {
      width: 20px;
      height: 20px;
      border-radius: 50%;
    }
  }
  .detail-gradient-color-item {
    display: block;
    width: 16px;
    height: 16px;
    border: 1px solid var(--c-black_300);
    border-radius: 50%;
  }
  .mobile-gradient-color-wrap {
    display: grid;
    grid-template: repeat(3, 52px)/repeat(5, minmax(52px, 1fr));
    grid-gap: 5px;
    margin-bottom: 8px;
    .gc-item {
      min-width: 52px;
      min-height: 52px;
      width: 100%;
    }
  }
</style>
