<template>
  <div
    class="style-select"
    :class="{ 'is-all-style-selected': isAllStylesSelected }"
  >
    <I8Dropdown
      ref="styleFilter"
      :value="styleFilterTitle"
      :class="['desktop-filter', 'desktop-style-filter', { 'is-sub-dropdown-open': isSubdropdownOpen }]"
      mode="outline"
      label="Style"
      size="large"
      :select="true"
      :is-open="isDropdownOpen"
      @click:open="dropdownOpened"
      @clear="handleDropdownClear"
      @close="isSubdropdownOpen = false"
    >
      <template slot="leftIcon">
        <img
          class="style-icon dropdown-icon"
          :src="styleImage(platform)"
          alt="house"
        >
      </template>
      <div
        class="style-dropdown-wrap"
        @mouseleave="dropdownWrapMouseLeave"
      >
        <div class="style-dropdown i8-scroll">
          <client-only>
            <div
                v-for="(style, si) in desktopPlatformList"
                :key="si"
                :class="['style-item', { 'is-active': isStyleActive(style) }]"
                @click="handleDropdownInput(style)"
                @mouseenter="itemMouseEnter(style)"
                @mouseleave="itemMouseLeave"
            >
              <img
                  class="style-icon is-desktop"
                  :src="styleImage(style)"
                  alt="house"
              >
              {{ style.title }}
              <I8Icon
                  v-if="isStyleActive(style) && !hasSubStyles(style)"
                  icon="checkmark"
                  class="active-checkmark"
              />
              <I8Icon
                  v-if="hasSubStyles(style)"
                  icon="chevron"
                  family="simpleSmall"
                  size="16px"
                  class="substyle-chevron"
              />
            </div>
          </client-only>
        </div>
        <div
          :class="['sub-style-dropdown', { 'is-open': isSubdropdownOpen }]"
        >
          <div
            v-for="(substyle, ssi) in substyleItems"
            :key="`substyle${ssi}`"
            :class="['style-item', { 'is-active': isStyleActive(substyle) }]"
            @click="handleDropdownInput(substyle)"
          >
            <img
              class="style-icon"
              :src="styleImage(substyle)"
              alt="house"
            >
            {{ substyle.title }}
            <I8Icon
              v-if="isStyleActive(substyle)"
              icon="checkmark"
              class="active-checkmark"
            />
          </div>
        </div>
      </div>
    </I8dropdown>

    <DetailExpander
      v-if="mobileFilterActive"
      :title="$t('WEB_APP.FILTERS.STYLES')"
      class="mobile-filter"
    >
      <template #summary-addon>
        {{ styleFilterTitle }}
      </template>
      <template #content>
        <DetailItem
          v-for="(style, index) in fullPlatformList"
          :key="index"
          :is-active="style.title === styleFilterTitle"
          @toggle="handleDropdownInput(style)"
        >
          <template #title-before>
            <img
              class="style-icon"
              :src="styleImage(style)"
              alt=""
            >
          </template>
          <template #title>
            {{ style.title }}
          </template>
        </DetailItem>
      </template>
    </DetailExpander>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import { I8Dropdown, I8Icon } from '@icons8/vue-kit'
import { useFilter } from '@/composables/useFilter'
import DetailExpander from '../details/DetailExpander.vue'
import DetailItem from '../details/DetailItem.vue'
import { getDesktopPlatformList } from './StyleSelectHelper'

export default {
  name: 'StyleSelect',
  components: { I8Dropdown, DetailExpander, DetailItem, I8Icon },
  props: {
    isColor: { type: Boolean, default: false }
  },
  data () {
    return {
      isDropdownOpen: false,
      isSubdropdownOpen: false,
      substyleItems: [],
      timerId: undefined
    }
  },
  computed: {
    ...mapState({
      isAnimated: state => state.filters.isAnimated,
      authors: state => state.filters.authors,
      platforms: state => state.appInfo.platforms,
      platform: state => state.platform,
      category: state => state.pack,
      color: state => state.filters.color,
      mobileFilterActive: state => state.ui.mobileFilterActive,
      baseColor: state => state.color,
    }),

    fullPlatformList () {
      const platformList = []

      const list = Object.keys(this.platforms).map(pl => {
        const platform = this.platforms[pl] || {}

        return {
          id: platform.apiCode,
          seoCode: platform.seoCode,
          order: platform.order,
          title: platform.title,
          preview: platform.preview
        }
      })

      list.map(platform => {
        if (platform.seoCode === 'all') {
          platform.title = this.$t('WEB_APP.SEO.FILTERS.STYLE.ALL')
        }
        platformList.push(platform)
      })

      return platformList.sort((a, b) => {
        if (!a || !b) return 0
        if (a.order < b.order) return -1
        return 1
      })
    },
    desktopPlatformList () {
      return getDesktopPlatformList(this)
    },

    isAllStylesSelected () {
      return this.platform.apiCode === 'all'
    },
    styleFilterTitle () {
      const [ platform ] = this.fullPlatformList.filter(item => item.id === this.platform.apiCode)
      return platform?.title
    }
  },
  methods: {
    ...mapActions(['setFilterColorGradient']),
    handleDropdownInput (platform) {

      if (!platform || this.hasSubStyles(platform)) {
        return
      }
      if (!this.isGradientStyle(platform.id)) {
        this.setFilterColorGradient(undefined)
      }

      this.isSubdropdownOpen = false
      this.isDropdownOpen = false

      this.$router.push(useFilter(this.$store).changeFilters({
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authorParamsNormalize(this.authors),
        color: this.baseColor.code || this.baseColor.value,
        platform: platform.seoCode,
        isPlatformColor: this.platforms[platform?.id]?.isColor
      }))
    },

    handleDropdownClear () {
      this.setFilterColorGradient(undefined)

      this.$router.push(useFilter(this.$store).changeFilters({
        routeName: this.$route.name,
        fullPath: this.$route.fullPath,
        animated: this.animatedParamsNormalize(this.isAnimated),
        authors: this.authorParamsNormalize(this.authors),
        color: this.color,
        platform: undefined,
        isPlatformColor: undefined
      }))
    },
    dropdownOpenSub (style) {
      this.substyleItems = style.substyles ?? []
      this.isSubdropdownOpen = !!this.substyleItems.length
    },
    dropdownWrapMouseLeave () {
      this.isSubdropdownOpen = false
    },
    dropdownOpened () {
      this.isDropdownOpen = true
    },

    itemMouseLeave () {
      clearTimeout(this.timerId)
    },
    itemMouseEnter (style) {
      this.timerId = setTimeout(() => {
        this.dropdownOpenSub(style)
      }, 150)
    },

    isGradientStyle (platformApiCode) {
      return platformApiCode === 'nolan'
    },
    classColor (item) {
      return {
        'background-color': `#${item.value}`,
        'box-shadow': item.value === 'ffffff' ? '0 0 0 1px rgba(0,0,0,0.15)' : 'none'
      }
    },
    isStyleActive (style) {
      if (style.substyles?.length) {
        return style.substyles.some(subStyle => subStyle.id === this.platform.apiCode)
      }
      return style.id === this.platform.apiCode
    },
    hasSubStyles (style) {
      return !!style?.substyles?.length
    },
    styleImage ({ seoCode, preview }) {
      if (preview) return preview
      if (!seoCode || seoCode === 'all') {
        return `${process.env.staticUrl ?? ''}/vue-static/icon/all-styles.png`
      }
      return `${process.env.iconsUrl}/${seoCode}/2x/home.png`
    },

    animatedParamsNormalize(value) {
      let animatedParams = null
      if (value) {
        animatedParams = 'animated'
      } else if (value === false) {
        animatedParams = 'static'
      } else {
        animatedParams = undefined
      }
      return animatedParams
    },
    authorParamsNormalize(value) {
      let authorParams = null

      if (value && value ===  'Independent' ) {
        authorParams = 'external'
      } else if (value && value ===  'Icons8') {
        authorParams = 'icons8'
      } else {
        authorParams = undefined
      }

      return authorParams
    },
  }
}
</script>

<style lang="scss">
.desktop-style-filter .i8-dropdown__content {
  overflow-x: hidden;
  transition: none;
}
</style>

<style lang="scss" scoped>
.style-select {
  --dropdown-label-padding-large: 0 var(--spacer-sm) 0 var(--spacer-xs);
  font-size: var(--font-sm);
  line-height: var(--h4-line-height);

  &.is-all-style-selected {
    :deep(.i8-dropdown__chosen-close) {
      display: none;
    }
  }
}

.style-icon {
  width: 16px;
  height: 16px;
}

.desktop-filter {
  --dropdown-content-width: 250px;
  --dropdown-content-maxheight: 280px;
  --dropdown-content-padding: 0;
  --dropdown-content-border: 0;

  &.is-sub-dropdown-open {
    --dropdown-content-border-radius: 4px 0 0 4px;
    --dropdown-content-width: 500px;
  }

  .style-icon {
    display: block;
    width: 24px;
    height: 24px;
    &:not(.dropdown-icon) {
      margin-right: 8px;
    }
  }
}

.style-item {
  display: flex;
  align-items: center;
  height: 32px;
  padding: 4px 8px;
  cursor: pointer;
  border-radius: 4px;
  &.is-active, &:hover {
    background: var(--c-transparent-black_100);
  }
}

.style-dropdown-wrap {
  display: flex;
  max-height: var(--dropdown-content-maxheight);
}

.style-dropdown {
  flex: 0 0 250px;
  padding: var(--spacer-xs) 0 var(--spacer-xs) var(--spacer-xs);
  height: var(--dropdown-content-maxheight);
  overflow-y: auto;
}

.sub-style-dropdown {
  display: none;
  flex: 1 0 250px;
  height: var(--dropdown-content-maxheight);
  padding: 8px;
  z-index: 12;
  background: var(--c-black_100);
  border-radius: 0 4px 4px 0;
  border: 1px solid var(--c-black_100);
  border-left: 0;
  overflow-y: auto;

  &.is-open {
    display: block;
  }
}

.active-checkmark, .substyle-chevron {
  margin-left: auto;
}

.substyle-chevron {
  transform: rotate(90deg);
}
</style>
