import { render, staticRenderFns } from "./ColorSelect.vue?vue&type=template&id=c5e90810&scoped=true&"
import script from "./ColorSelect.vue?vue&type=script&lang=js&"
export * from "./ColorSelect.vue?vue&type=script&lang=js&"
import style0 from "./ColorSelect.vue?vue&type=style&index=0&id=c5e90810&prod&lang=scss&"
import style1 from "./ColorSelect.vue?vue&type=style&index=1&id=c5e90810&prod&lang=scss&scoped=true&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "c5e90810",
  null
  
)

export default component.exports