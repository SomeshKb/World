// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only{display:none!important}}@media(max-width:1023px){.desktop-only{display:none!important}}.request-icon-layout{font-size:16px;line-height:24px;color:#333}.request-icon-layout h1,.request-icon-layout h2,.request-icon-layout h3,.request-icon-layout h4,.request-icon-layout h5,.request-icon-layout h6{margin-top:0;text-align:left;font-weight:700}.request-icon-layout h1{font-size:32px;line-height:44px}.request-icon-layout .app-filter-toggle{display:none!important}.request-icon-layout .container{max-width:720px;margin:auto}.request-icon-layout footer .container{max-width:1040px;width:100%}.request-icon-layout .app-popup-arrow{width:9px}.request-icon-layout .right-sidebar{position:fixed}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
