<template>
  <div class="app-layouts">
    <app-icons-menu />
    <div class="app-grid">
      <div class="app-content">
        <client-only>
          <OpenedCollectionSidebar />
        </client-only>
        <LeftSidebar />
        <app-page
          :sidebars="sidebars"
          :class="isBanner ? 'app-page_with-banner':''"
          @clicked="hideSidebars"
        >
          <nuxt />
          <client-only>
            <app-notify position="bottom" />
          </client-only>
        </app-page>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import LeftSidebar from '../components/app/LeftSideBar'
import OpenedCollectionSidebar from '../components/collections/OpenedCollectionSidebar'

export default {
  components: {
    LeftSidebar,
    OpenedCollectionSidebar
  },
  data () {
    return {
      isBanner: true
    }
  },
  computed: {
    ...mapState({
      seo: state => state.seo.data,
      appInfo: state => state.appInfo,
      locale: state => state.i18n.locale,
      sidebars: state => state.ui.sidebars,
      rightSidebar: state => state.ui.sidebars.right.active,
      user: state => state.auth.user
    })
  },
  created () {
    this.enableLeftSidebar()
    this.enableRightSidebar()
  },
  methods: {
    ...mapActions([
      'enableLeftSidebar',
      'enableRightSidebar',
      'hideLeftSidebar',
      'hideRightSidebar'
    ]),
    hideSidebars () {
      this.hideLeftSidebar()
    }
  },
  head () {
    return {
      ...this.seo,
      bodyAttrs: {
        class: 'flex'
      }
    }
  }
}
</script>
