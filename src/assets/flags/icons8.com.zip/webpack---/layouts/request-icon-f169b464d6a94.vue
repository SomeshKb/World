<template>
  <div class="request-icon-layout">
    <app-icons-menu
      class="request-icon-layout__menu"
      :locale="locale"
    />
    <nuxt />
    <I8Footer
      id="app-footer"
      footer-name="ICONS8"
      :locale="locale"
    />
    <crisp-helper />
    <client-only>
      <app-notify position="bottom" />
    </client-only>
  </div>
</template>

<script>
import { mapState } from 'vuex'
import OpenedCollectionSidebar from '../components/collections/OpenedCollectionSidebar'
import I8Footer from 'icons8-common/src/components/I8Footer'

export default {
  components: { OpenedCollectionSidebar, I8Footer },
  computed: {
    ...mapState({
      seo: state => state.seo.data,
      locale: state => state.i18n.locale,
      user: state => state.auth.user,
      collections: state => state.collections.collections,
      collectionsLength: state => state.collections.collections.length
    })
  },
  head () {
    return {
      ...this.seo
    }
  }
}
</script>

<style lang="scss">
  .request-icon-layout {
    font-size: 16px;
    line-height: 24px;
    color: #333;
    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      margin-top: 0;
      text-align: left;
      font-weight: bold;
    }
    h1 {
      font-size: 32px;
      line-height: 44px;
    }
    .app-filter-toggle {
      display: none !important;
    }
    .container {
      max-width: 720px;
      margin: auto;
    }
    footer .container {
      max-width: 1040px;
      width: 100%;
    }

    .app-popup-arrow {
      width: 9px;
    }
    .right-sidebar {
      position: fixed;
    }
  }
</style>

<style lang="scss" scoped>
.request-icon-layout__menu {
  z-index: 101;
}
</style>

<style lang="scss">
@import '~assets/css/mixins';

@include min(480) {
  .request-icon-layout footer a {
    font-size: 14px;
  }
}
</style>
