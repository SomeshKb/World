// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only[data-v-0c999881]{display:none!important}}@media(max-width:1023px){.desktop-only[data-v-0c999881]{display:none!important}}.request-icon-layout__menu[data-v-0c999881]{z-index:101}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
