// Imports
var ___CSS_LOADER_API_IMPORT___ = require("../node_modules/css-loader/dist/runtime/api.js");
var ___CSS_LOADER_EXPORT___ = ___CSS_LOADER_API_IMPORT___(function(i){return i[1]});
// Module
___CSS_LOADER_EXPORT___.push([module.id, "@media(min-width:1024px){.mobile-only{display:none!important}}@media(max-width:1023px){.desktop-only{display:none!important}}@keyframes spin{0%{transform:rotate(0deg)}to{transform:rotate(1turn)}}.main-page-layout{font-size:14px;color:#333;overflow-x:hidden;-webkit-font-smoothing:antialiased}@media(max-width:480px){.main-page-layout{overflow-x:hidden}}.main-page-layout p{margin:0 0 15px}.main-page-layout a{text-decoration:none}.main-page-layout .container{max-width:1040px;width:100%;margin:auto}.main-page-layout .visually-hidden{position:absolute!important;width:1px;height:1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;-webkit-clip-path:inset(50%);clip-path:inset(50%);border:0}.overlay .app-modal .close.is-outside{color:#eee}", ""]);
// Exports
___CSS_LOADER_EXPORT___.locals = {};
module.exports = ___CSS_LOADER_EXPORT___;
