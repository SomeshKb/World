import { render, staticRenderFns } from "./app-landing.vue?vue&type=template&id=ba372738&"
import script from "./app-landing.vue?vue&type=script&lang=js&"
export * from "./app-landing.vue?vue&type=script&lang=js&"


/* normalize component */
import normalizer from "!../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports