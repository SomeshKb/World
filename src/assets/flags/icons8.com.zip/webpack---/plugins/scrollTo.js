import Vue from 'vue'
import VueScrollTo from 'vue-scrollto'

Vue.use(VueScrollTo, {
  container: '.app-page.i8-scroll',
  duration: 500,
  easing: 'ease'
})
