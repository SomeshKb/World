import Vue from 'vue'
import infiniteLoading from 'vue-infinite-loading'

Vue.use(infiniteLoading, {
  props: {
    spinner: 'spinner'
    /* other props need to configure */
  },
  system: {
    throttleLimit: 50
    /* other settings need to configure */
  }
})
