
import {
  COLOR_LIST,
  AUTHORS_MAP,
  ANIMATION_MAP,
  SHAPES_MAP,
  FORMATS_MAP
} from '@/constants'



function replaceCharacters (str)  {
  return str
    .replace(/&apos;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&gt;/g, '>')
    .replace(/&lt;/g, '<')
    .replace(/&amp;/g, '&');
}
function removeCharacters (str) {
  return str.replace(/[`~!@#$%^&*()_|+=?;:'",.<>\{\}\[\]\\\/]/gi, '')
}

export default function (str) {

  const colors = COLOR_LIST.map(item => item.code)


  const formats = [
    FORMATS_MAP.PNG,
    FORMATS_MAP.VECTOR
  ]

  const shapes = [
    SHAPES_MAP.CIRCLE,
    SHAPES_MAP.SQUARE
  ]

  const authors = [
    AUTHORS_MAP.ICONS8,
    AUTHORS_MAP.EXTERNAL
  ]

  const animations = [
    ANIMATION_MAP.ANIMATED,
    ANIMATION_MAP.STATIC
  ]
  return str.split('--')
    .reduce((acc, val, index) => {
      let param = val.trim()
      if (index === 0) {
        const term = param
          .replace(/ /g, '-')
          .split('-')
          .filter(item => item !== '')
          .join('-')

        acc['$rootPath'] = decodeURIComponent(encodeURIComponent(term))
      } else {
        if (formats.some(el => el === param)) acc['format'] = decodeURIComponent(param)

        if (colors.some(el => el === param) || param.includes('c-')) acc['color'] = decodeURIComponent(param)

        if (shapes.some(el => el === param)) acc['shape'] = decodeURIComponent(param)

        if (authors.some(el => el === param)) acc['authors'] = decodeURIComponent(param)

        if (animations.some(el => el === param)) acc['animation'] = decodeURIComponent(param)
      }

      return acc
    }, {})
}
