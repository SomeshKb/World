'use strict'

import axios from '~/plugins/axios'

import upload from './upload'
import similar from './similar'

let atob
if (process.browser) {
  atob = window.atob
} else {
  atob = require('atob')
}

function getIcon (_ctx, {
  id,
  info = 'false',
  language = this.$i18n.localeProperties.iso,
  svg = false
} = {}) {
  const url = 'siteApi/icons/icon'
  const params = {
    id,
    info,
    language,
    svg
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params
  }).then(response => {
    const data = response.data
    if (!data.success) {
      throw { ...data, status: response.status }
    }

    const icon = data.icon
    if (svg) {
      icon.svg = icon.svg ? atob(icon.svg) : icon.svg
    }

    // init svgEffect
    icon.svgEffect = undefined
    // init svgCurrentResolution
    icon.svgCurrentResolution = undefined

    // mainId it's lowest id of all variants
    icon.mainId = undefined

    if (icon.variants) {
      icon.variants.forEach(variant => {
        // find mainId
        if (variant.platform === 'ios7') {
          icon.mainId = variant.id
        }
      })
      if (!icon.mainId && icon.variants.length > 0) {
        icon.mainId = icon.variants[0].id
      }
    }

    return { icon }
  })
}

export default {
  getIcon,
  ...similar,
  ...upload
}
