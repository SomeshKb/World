'use strict'

const api = {
  getSimilarIcons,
  getRelatedIcons,
  getRelatedExternalIcons
}

async function getRelatedIcons (
  { rootState, dispatch },
  {
    platform,
    pack,
    amount = 24,
    language = this.$i18n.localeProperties.iso,
    sortBy = 'popular'
  } = {}
) {
  const { category } = await dispatch('getPack', {
    platform,
    pack,
    amount,
    language,
    sortBy
  })

  return category.icons ?? []
}

async function getSimilarIcons ({ dispatch }, {
  term,
  amount = 24,
  language = this.$i18n.localeProperties.iso,
  isColor = undefined
} = {}) {
  return (await dispatch('search', {
    term,
    amount,
    language,
    ...(isColor && {isColor})
  }))?.icons ?? []
}

async function getRelatedExternalIcons ({ rootState, dispatch }, { pack }) {
  const { category } = await dispatch(
    'getPack',
    {
      pack,
      authors: 'external'
    },
    { root: true }
  )
  return category.subcategory[0]?.icons ?? []
}

export default api
