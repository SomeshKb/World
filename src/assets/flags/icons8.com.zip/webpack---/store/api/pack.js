'use strict'

import axios from '../../plugins/axios'

function getPack ({ rootState }, {
  pack = rootState.pack.code,
  platform = rootState.platform.apiCode || 'all',
  amount = 100,
  page = 1,
  language = this.$i18n.localeProperties.iso,
  isAnimated = undefined,
  authors = undefined,
  sortBy = undefined
} = {}) {
  const url = '/siteApi/icons/packs/demarcation'
  const params = {
    category: pack,
    amount,
    offset: (page - 1) * amount,
    platform,
    language,
    isAnimated,
    authors,
    sortBy
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params
  }).then(res => res.data)
}

function getSeoPack ({ rootState }, {
  pack = rootState.seoPack.code,
  platform = rootState.platform.apiCode,
  amount = 50,
  page = 1,
  language = this.$i18n.localeProperties.iso
}) {
  const url = 'api/iconsets/v4/seoCategory'
  const params = {
    category: pack,
    amount,
    offset: (page - 1) * amount,
    platform: platform === 'all' ? undefined : platform,
    language
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params
  }).then(res => res.data)
}

export default {
  getPack,
  getSeoPack
}
