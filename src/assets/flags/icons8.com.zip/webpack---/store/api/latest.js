'use strict'

import axios from '~/plugins/axios'

export default function latest ({ rootState }, {
  amount = 100,
  page = 1,
  platform = rootState.platform.apiCode,
  language = this.$i18n.localeProperties.iso,
  authors = 'all',
  isColor,
  isAnimated
} = {}) {
  const url = '/siteApi/icons/latest'
  const params = {
    amount,
    offset: (page - 1) * amount,
    platform,
    language,
    authors,
    isColor,
    isAnimated
  }

  return axios.request({
    url,
    baseURL: process.env.apiUrl,
    method: 'get',
    params
  }).then(res => res.data)
}
