import {COLOR_EMPTY} from "@/constants";

export default () => ({
  collections: [],
  areCollectionsLoaded: false,
  areCollectionsLoading: false,
  simulatedDeletedCollectionId: null,
  openCollectionId: null,
  color: COLOR_EMPTY,
  alreadyDownloadedIconsIds: [],

  downloadErrors: [], // array of errors in collection downloading.
  downloadProgress: 0 // number downloaded icons.
})
