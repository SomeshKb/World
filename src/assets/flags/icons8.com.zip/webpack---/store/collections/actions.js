import fileSaver from 'file-saver'
import * as types from './_mutationTypes'
import iconUtils from '~/plugins/iconUtils'

import {
  canAddIconsToCollection,
  canAddIconToCollection,
  isCollectionNameValid,
  isIconValidForCollection,
  prepareCollectionForCreation
} from './_helpers'
import {DOWNLOADED_COLLECTION_NAME, FAVORITES_COLLECTION_NAME} from './_constants'

import {
  generateFont as generateFontRequest,
  generateIconSet as generateIconSetRequest
} from '../../api/collections/download'

import {
  ADD_ICON_TO_COLLECTION_FAILED,
  COLLECTION_IS_FULL,
  CREATE_COLLECTION_FAILED,
  DELETE_COLLECTION_FAILED,
  DELETE_ICON_FROM_COLLECTION_FAILED,
  GET_COLLECTIONS_FAILED,
  INVALID_NAME_ERROR,
  OPEN_COLLECTION_FAILED,
  UPDATE_COLLECTION_FAILED,
  UPDATE_ICON_IN_COLLECTION_FAILED
} from './_errors'

import { getDownloadedIconsIdsForCollection, wasIconDownloaded } from '@/api/user'
import { collectionsService } from '@/api/collections/collectionsService'
import { NO_SUCH_COLLECTION } from '@/api/collections/errors'
import { getCollectionsPreview } from '@/api/collections/serverAPI'

import { downloadIcon } from '@/api/icon/download'
import { normalizeValue } from '@icons8/frontend-utils'
import { generateAndroidManifest } from '@/utils/icon/formatsGenerator'

export default {

  /**
   * Add new collection in the front of the collection list.
   * @param commit
   * @param rootGetters
   * @param state
   * @param rootState
   * @param {object} collection
   */
  async addCollection ({ commit, rootGetters, state, rootState }, collection) {
    if (!rootState.auth.user.isGuest) {
      try {
        const newCollection = await collectionsService(rootGetters.isGuest)
          .createCollection(prepareCollectionForCreation(collection, state.collections.length))
        newCollection.edit = false
        commit(
          types.SET_COLLECTIONS,
          [newCollection, ...state.collections]
        )
        return newCollection
      } catch (e) {
        console.error(e)
        throw CREATE_COLLECTION_FAILED(collection.name)
      }
    }
  },


  async simulateDeleteCollection ({ commit, dispatch, rootGetters, state }, id) {
    if (state.simulatedDeletedCollectionId) {
      await dispatch('deleteCollection', {id: state.simulatedDeletedCollectionId, closeOpened: false})
    }
    commit(
      types.SET_OPEN_COLLECTION_ID,
      null
    )
    commit(
      types.SET_SIMULATED_DELETED_COLLECTION_ID,
      id
    )
  },

  cancelDeleteCollection ({commit}) {
    commit(
      types.SET_SIMULATED_DELETED_COLLECTION_ID,
      null
    )
  },

  /**
   * Delete collection with given ID from the state.
   * @param commit
   * @param rootGetters
   * @param state
   * @param {number|string|null} id
   * @param {boolean} keepAlive is sending request with keep-alive needed to support deletion before unloading page
   * @param {boolean} closeOpened is closing opened collection needed
   * @param {boolean} resetSimulation is resetting simulated delete needed
   */
  async deleteCollection ({ commit, rootGetters, state }, {id, keepAlive=false, closeOpened=true, resetSimulation=true}) {
    try {
      await collectionsService(rootGetters.isGuest)
        .deleteCollection(id, keepAlive)
      if (closeOpened) {
        commit(
          types.SET_OPEN_COLLECTION_ID,
          null
        )
      }
      if (resetSimulation) {
        commit(
          types.SET_SIMULATED_DELETED_COLLECTION_ID,
          null
        )
      }
      commit(
        types.SET_COLLECTIONS,
        state.collections.filter(el => el.id !== id)
      )
    } catch (e) {
      throw DELETE_COLLECTION_FAILED(id)
    }
  },

  /**
   * Update collection with given id with given data.
   * @param commit
   * @param state
   * @param rootGetters
   * @param {number|string} id
   * @param {object} data
   */
  async updateCollection ({ commit, state, rootGetters }, { id, data }) {
    try {
      const collection = await collectionsService(rootGetters.isGuest)
        .updateCollection(id, data)
      commit(types.SET_COLLECTION_BY_ID, {
        collectionId: id,
        newCollection: collection
      })
    } catch (e) {
      throw UPDATE_COLLECTION_FAILED(id)
    }
  },

  /**
   * Load collection from server and set to state.
   * @param commit
   * @param rootGetters
   * @param {number|string} id
   * @returns {Promise<void>}
   */
  async loadCollection ({ commit, rootGetters }, { id }) {
    try {
      commit(types.SET_IS_COLLECTION_LOADING, { collectionId: id, value: true })
      const collection = await collectionsService(rootGetters.isGuest)
        .getCollection(id)
      commit(types.SET_COLLECTION_BY_ID, {
        collectionId: id,
        newCollection: collection
      })
      commit(types.SET_IS_COLLECTION_LOADING, { collectionId: id, value: false })
    } catch (e) {
      console.error(e)
    }
  },

  /**
   * Select collection with given id from collections list
   * @param commit
   * @param dispatch
   * @param getters
   * @param rootGetters
   * @param {number|string} id
   */
  async openCollection ({ commit, dispatch, getters, rootGetters }, id) {
    try {
      const collection = getters.getCollectionById(id)
      if (!collection.loaded) {
        dispatch('loadCollection', { id })
      }
      commit(types.SET_OPEN_COLLECTION_ID, id)
    } catch (e) {
      throw OPEN_COLLECTION_FAILED(id)
    }
  },

  closeCollection ({ commit }) {
    commit(types.SET_OPEN_COLLECTION_ID, null)
  },

  /**
   * @param state
   * @param commit
   * @param rootGetters
   * @param dispatch
   * @param previewOnly:boolean is fetching only icons for preview needed
   * @returns {Promise<void>}
   */
  async getCollections ({ state, commit, rootGetters, dispatch }, previewOnly=true) {
    if (state.areCollectionsLoading) return
    try {
      // set loading state
      commit(types.SET_ARE_COLLECTIONS_LOADING, true)

      const collections = await collectionsService(rootGetters.isGuest).getCollections()

      const defaultsToCreate = {
        favorites: !collections.find(el => el.isDefault),
        downloaded: !collections.find(el => el.isDownloaded)
      }
      dispatch('createSystemCollections', { collections: defaultsToCreate })

      commit(types.SET_COLLECTIONS, collections)

      if (!previewOnly) {
        collections.forEach(collection => {
          if (collection.iconsTotal > collection.icons.length) {
            dispatch('loadCollection', {id: collection.id})
          }
        })
      }

      commit(types.SET_ARE_COLLECTIONS_LOADED, true)
      commit(types.SET_ARE_COLLECTIONS_LOADING, false)
    } catch (e) {
      throw GET_COLLECTIONS_FAILED
    }
  },

  /**
   *
   * @param dispatch
   * @param commit
   * @param state
   * @param {{ favorites: boolean, downloaded: boolean }} collections
   */
  createSystemCollections (
    { dispatch, commit, state },
    { collections } = { collections: { favorites: false, downloaded: false } }
  ) {
    const requests = []
    if (collections.favorites) {
      requests.push(dispatch('createFavoritesCollection'))
    }
    if (collections.downloaded) {
      requests.push(dispatch('createDownloadedCollection'))
    }
    try {
      Promise.all(requests).then()
    } catch (e) {
      console.error(e)
    }
  },

  renameCollection ({ dispatch }, { collectionId, name }) {
    if (isCollectionNameValid(name)) {
      dispatch('updateCollection', {
        id: collectionId,
        data: { name }
      })
    } else {
      throw INVALID_NAME_ERROR(name)
    }
  },

  /**
   * TODO: refactor in terms of addIconsToCollection
   * @param commit
   * @param dispatch
   * @param state
   * @param getters
   * @param rootGetters
   * @param {number|string} collectionId
   * @param {{id: number|string, isFree: boolean, free: boolean}} icon
   */
  async addIconToCollection (
    { commit, dispatch, state, getters, rootGetters },
    { collectionId, icon }
  ) {
    if (!isIconValidForCollection(icon)) {
      throw ADD_ICON_TO_COLLECTION_FAILED(collectionId, icon)
    }
    let collection = getters.getCollectionById(collectionId)
    if (!collection.loaded) {
      await dispatch('loadCollection', { id: collectionId })
      collection = getters.getCollectionById(collectionId)
    }
    if (canAddIconToCollection(collection)) {
      try {
        // add icon loader preview
        commit(types.ADD_ICON_TO_COLLECTION, {
          collectionId,
          icon: {
            ...icon,
            loading: true,
            isFree: icon.free || icon.isFree
          }
        })

        // sending request
        const newIcons = await collectionsService(rootGetters.isGuest)
          .addIconsToCollection(collectionId, [
            {
              id: icon.id,
              name: icon.name,
              isFree: icon.free || icon.isFree
            }
          ])

        // setting real icon
        commit(types.UPDATE_ICON_IN_COLLECTION, {
          collectionId,
          icon: { ...icon, free: icon.free || icon.isFree},
          data: {
            ...newIcons[0],
            loading: false
          }
        })
      } catch (e) {
        throw ADD_ICON_TO_COLLECTION_FAILED(collectionId, icon)
      }
    } else {
      throw COLLECTION_IS_FULL
    }
  },

  async retryIconUpload (
    { dispatch, commit, rootGetters, getters },
    { collectionId, icon }
  ) {
    try {
      const collection = getters.getCollectionById(collectionId)
      if (!collection) {
        throw NO_SUCH_COLLECTION(collectionId)
      }

      // add loader state
      commit(types.UPDATE_ICONS_IN_COLLECTION, {
        collectionId,
        icons: [{ ...icon, loading: true, addError: null }]
      })

      if (!icon.isUserSource) {
        if (icon.svgEffect) {
          icon.svg = icon.svgEffect
        } else {
          delete icon.svg
        }
      }

      // perform request
      const newIcons = await collectionsService(rootGetters.isGuest)
        .addIconsToCollection(collectionId, [icon])

      // setting real icon
      commit(types.UPDATE_ICONS_IN_COLLECTION, {
        collectionId,
        icons: newIcons.map(el => ({ ...el, loading: false }))
      })
    } catch (e) {
      console.error(e)
      throw ADD_ICON_TO_COLLECTION_FAILED(collectionId, icon)
    }
  },

  /**
   * Upload user icons to our services.
   * @param commit
   * @param dispatch
   * @param rootGetters
   * @param getters
   * @param {number|string} collectionId
   * @param {Array<Object>} icons
   */
  async addIconsToCollection (
    { commit, dispatch, rootGetters, getters },
    { collectionId, icons, onUploadProgress }
  ) {
    const invalidIcon = icons.find(el => !isIconValidForCollection(el))
    if (invalidIcon) {
      throw ADD_ICON_TO_COLLECTION_FAILED(collectionId, invalidIcon.id || invalidIcon.name)
    }

    let collection = getters.getCollectionById(collectionId)
    if (!collection.loaded) {
      await dispatch('loadCollection', { id: collectionId })
      collection = getters.getCollectionById(collectionId)
    }

    if (canAddIconsToCollection(collection, icons)) {
      try {
        // show loaders
        commit(types.ADD_ICONS_TO_COLLECTION, {
          collectionId,
          icons: icons.map(el => ({ ...el, loading: true }))
        })

        // fetch icons
        const newIcons = await collectionsService(rootGetters.isGuest)
          .addIconsToCollection(collectionId, icons.map((el) => {
            if (el.isUserSource) {
              return el
            } else {
              const { svg, ...icon } = el
              return icon
            }
          }), onUploadProgress)

        // show icons
        commit(types.UPDATE_ICONS_IN_COLLECTION, {
          collectionId,
          icons: newIcons.map(el => ({ ...el, loading: false }))
        })
      } catch (e) {
        commit(types.UPDATE_ICONS_IN_COLLECTION, {
          collectionId,
          icons: icons.map(el => ({ ...el, loading: false, addError: true }))
        })
        throw Error(e)
      }
    } else {
      throw COLLECTION_IS_FULL
    }
  },

  async addIconToDownloadedCollection ({ state, dispatch, getters }, { icon }) {
    if (!state.areCollectionsLoaded) {
      await dispatch('getCollections')
    }

    let downloadedCollection = getters.getDownloadedCollection
    if (!downloadedCollection.loaded) {
      await dispatch('loadCollection', { id: downloadedCollection.id })
      downloadedCollection = getters.getCollectionById(downloadedCollection.id)
    }

    const isInDownloadCollection = downloadedCollection.icons.some(el => el.id === icon.id)
    if (downloadedCollection && !isInDownloadCollection) {
      await dispatch('addIconsToCollection', {
        collectionId: downloadedCollection.id,
        icons: [icon]
      })
    }
  },

  /**
   * @param dispatch
   * @param rootGetters
   * @param {number|string} collectionId
   * @param {{id: number|string}} icon
   */
  async updateIconInCollection ({ dispatch, rootGetters }, { collectionId, icon }) {
    try {
      let collection = rootGetters.getCollectionById(collectionId)
      if (!collection) {
        throw NO_SUCH_COLLECTION(collectionId)
      }
      if (!collection.loaded) {
        collection = await collectionsService(rootGetters.isGuest)
          .getCollection(collectionId)
      }
      const newIcon = await collectionsService(rootGetters.isGuest)
        .updateIconInCollection(collectionId, icon.id, icon)
      const newIcons = collection.icons.map(el => {
        if (el.id !== icon.id) { return el }
        return {
          ...el,
          ...newIcon
        }
      })
      dispatch('updateCollection', {
        id: collectionId,
        data: { icons: newIcons }
      })
    } catch (e) {
      throw UPDATE_ICON_IN_COLLECTION_FAILED(collectionId, icon.id)
    }
  },

  /**
   * @param commit
   * @param dispatch
   * @param getters
   * @param rootGetters
   * @param {number|string} collectionId
   * @param {number|string} iconId
   */
  async removeIconFromCollection (
    { commit, dispatch, getters, rootGetters },
    { collectionId, iconId }
  ) {
    try {
      await collectionsService(rootGetters.isGuest)
        .deleteIconFromCollection(collectionId, iconId)

      commit(types.REMOVE_ICON_FROM_COLLECTION, {
        collectionId,
        iconIds: [iconId]
      })
    } catch (e) {
      console.error(e)
      throw DELETE_ICON_FROM_COLLECTION_FAILED(collectionId, iconId)
    }
  },

  /**
   * Create collection of favorite icons, add it to the store
   * and immediately select this new collection.
   * @param dispatch
   * @param rootGetters
   * @returns {Promise<void>}
   */
  async createFavoritesCollection ({ dispatch, rootGetters }) {
    return await dispatch('addCollection', {
      name: FAVORITES_COLLECTION_NAME,
      icons: [],
      isDefault: true
    })
  },

  /**
   * Create collection of downloaded icons and add it to the store.
   * @param dispatch
   * @param rootGetters
   * @returns {Promise<void>}
   */
  async createDownloadedCollection ({ dispatch, rootGetters }) {
    return await dispatch('addCollection', {
      name: DOWNLOADED_COLLECTION_NAME,
      icons: [],
      isDownloaded: true
    })
  },

  async fetchDownloadedIconsIds ({ commit, rootGetters }, collectionId) {
    if (!rootGetters.isGuest) {
      try {
        const res = await getDownloadedIconsIdsForCollection(collectionId)
        commit(types.SET_ALREADY_DOWNLOADED_ICONS_IDS, res)
      } catch (e) {
        console.error(e)
        throw new Error('Cannot fetch downloaded icons ids.')
      }
    }
  },

  setColor ({ commit }, { color }) {
    commit(types.SET_COLOR, {
      color: color
    })
  },

  async generateFont ({ rootState, dispatch }, { collection, namePrefix, appendHash }) {
    return generateFontRequest({ collection, namePrefix, appendHash }, rootState.auth.user.authToken)
  },

  async generateIconSet ({ rootState, dispatch }, { collection, size }) {
    return generateIconSetRequest(collection.id, collection.name, rootState.auth.user.authToken, size)
  },

  async downloadCollection ({ commit, dispatch }, { collection, options, sizes, userEmail, apiToken }) {
    const Zip = (await import(/* webpackChunkName: "jszip" */ 'jszip-sync')).default
    const zip = new Zip()
    const uniqueNames = new iconUtils.UniqueNames()
    commit(types.RESET_DOWNLOAD_PROCESS)

    let downloadingErrorCounter = 0
    const handleIconDownload = async (icon, idx) => {
      const params = {
        id: iconsRequestsData[idx].id,
        size: iconsRequestsData[idx].size,
        format: options.format,
        color: options.color,
        userLicense: options.userLicense,
        isSimplified: options.isSimplified
      }

      let forceFormat
      if (!icon.formats.includes(options.format)) {
        forceFormat = 'png'
      }

      try {
        const response = await downloadIcon(icon, params, userEmail, apiToken)
        let name = normalizeValue(icon.name).replace('.svg', '')
        if (icon.filled && !name.endsWith('-filled')) { name += '-filled' }
        if (icon.size) { name += `-${icon.size}` }
        if (!name.startsWith('icons8')) { name = 'icons8-' + name }
        if (icon.postfix) { name = name + `(${icon.postfix})` }
        if (icon.folderName) { name = `${icon.folderName}/` + name }
        name = uniqueNames.getName(name)
        return zip.file(`${name}.${forceFormat || options.format}`, response.data)
      } catch (error) {
        commit(types.ADD_DOWNLOAD_ERROR, { error, icon })
        downloadingErrorCounter++
      } finally {
        commit(types.INCREMENT_PROGRESS)
      }
    }

    const iconsRequestsData = collection.icons
      .map(icon => sizes.map(size => ({ ...icon, size: size.title, postfix: size.postfix, folderName: size.folderName })))
      .reduce((acc, arr) => { return acc.concat(arr) }, [])

    const results = []
    const chunkedDownload = async (icons) => {
      const current = await Promise.all(icons.map(handleIconDownload))
      results.push(current)
    }

    await chunkedDownload(iconsRequestsData)
    if (downloadingErrorCounter !== collection.icons.length) {
      const blob = await zip.generateAsync({ type: 'blob' })
      fileSaver.saveAs(blob, `${collection.name}.zip`)
    }
  },

  async downloadFavicons ({ commit, dispatch }, { icon, options, selectedSizes, userEmail, apiToken }) {
    const Zip = (await import(/* webpackChunkName: "jszip" */ 'jszip-sync')).default
    const zip = new Zip()
    commit(types.RESET_DOWNLOAD_PROCESS)

    const params = {
      id: icon.id,
      color: options.color,
      userLicense: options.userLicense,
      isSimplified: true
    }
    const iconsPlusName = `icons8-${normalizeValue(icon.name + ' ' + icon.platformName)}`

    let downloadingErrorCounter = 0
    await Promise.all(selectedSizes.map(async selectedSize => {
      for await (const format of selectedSize.formats) {
        try {
          const response = await downloadIcon(
            icon,
            {
              ...params,
              size: selectedSize.width,
              format
            },
            userEmail,
            apiToken
          )
          zip.file(`${selectedSize.category}/${iconsPlusName}-${selectedSize.width}.${format}`, response.data)
        } catch (error) {
          console.error(error)
          commit(types.ADD_DOWNLOAD_ERROR, { error, icon })
          downloadingErrorCounter++
        } finally {
          commit(types.INCREMENT_PROGRESS)
        }
      }
    }))

    const androidManifest = generateAndroidManifest(iconsPlusName, selectedSizes)
    if (androidManifest) {
      zip.file('Android Chrome/manifest.json', androidManifest)
    }

    if (downloadingErrorCounter !== selectedSizes.length) {
      const blob = await zip.generateAsync({ type: 'blob' })
      fileSaver.saveAs(blob, `${iconsPlusName}-favicons.zip`)
    }
  }
}
