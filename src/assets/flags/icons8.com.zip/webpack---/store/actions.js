'use strict'

import * as types from './mutation-types'
import appInfo from '~/plugins/appInfo'

import icon from './api/icon/index'
import latest from './api/latest'
import pack from './api/pack'
import search from './api/search'
import * as market from './api/market'

const actions = {
  ...icon,
  latest,
  ...pack,
  search,
  ...market,

  setPlatform,
  setPack,
  setSeoPack,
  setSearchColor,
  setSearchShape,
  setSearchMain,

  enableLeftSidebar,
  disableLeftSidebar,
  showLeftSidebar,
  hideLeftSidebar,

  enableRightSidebar,
  disableRightSidebar,
  showRightSidebar,
  hideRightSidebar,

  showMobileSearch,
  hideMobileSearch,
  changeSelectPlatform,
  resetSelectPlatform,

  showCornerAd,
  hideCornerAd,
  showFallbackAd,

  setFilterColor,
  setFilterColorGradient,
  setFilterIsAnimated,
  setFilterAuthors,
  setSidebarChapter,

  selectPlatforms,
  fillPlatformsArray,
  updatePlatformsArray,
  setPlatformsLength,

  nuxtServerInit,
  nuxtClientInit,

  showLinkCopyBar,
  hideLinkCopyBar,
  setLinkCopyBarNeedShow,
  setLinkCopyBarLinkText,
  toggleMobileFilter,

  setIsPageLoading
}

function setPlatform ({ commit }, platformCode) {
  commit(types.PLATFORM_CHANGED, platformCode)
}

function setPack ({ commit }, packCode) {
  commit(types.PACK_CHANGED, packCode)
}

function setSeoPack ({ commit }, packCode) {
  commit(types.SEO_PACK_CHANGED, packCode)
}

function setSearchColor ({ commit }, color) {
  commit(types.SEARCH_COLOR_CHANGED, color)
}

function setSearchShape ({ commit }, shape) {
  commit(types.SEARCH_SHAPE_CHANGED, shape)
}

function setSearchMain ({ commit }, search) {
  commit(types.SET_SEARCH_MAIN, search)
}

function enableLeftSidebar ({ commit }) {
  commit(types.LEFT_SIDEBAR_ENABLED)
}

function disableLeftSidebar ({ commit }) {
  commit(types.LEFT_SIDEBAR_DISABLED)
}

function showLeftSidebar ({ commit }) {
  commit(types.LEFT_SIDEBAR_SHOWN)
}

function hideLeftSidebar ({ commit }) {
  commit(types.LEFT_SIDEBAR_HIDDEN)
}

function showCornerAd ({ commit }) {
  commit(types.CORNER_AD_SHOWN)
}

function hideCornerAd ({ commit }) {
  commit(types.CORNER_AD_HIDDEN)
}

function showFallbackAd ({ commit }) {
  commit(types.FALLBACK_AD_SHOWN)
}

function enableRightSidebar ({ commit }) {
  commit(types.RIGHT_SIDEBAR_ENABLED)
}

function disableRightSidebar ({ commit }) {
  commit(types.RIGHT_SIDEBAR_DISABLED)
}

function showRightSidebar ({ commit }) {
  commit(types.RIGHT_SIDEBAR_SHOWN)
}

function hideRightSidebar ({ commit }) {
  commit(types.RIGHT_SIDEBAR_HIDDEN)
}

function showMobileSearch ({ commit }) {
  commit(types.MOBILE_SEARCH_SHOWN)
}

function hideMobileSearch ({ commit }) {
  commit(types.MOBILE_SEARCH_HIDDEN)
}

function changeSelectPlatform ({ commit }) {
  commit(types.SELECT_PLATFORM_CHANGED)
}

function resetSelectPlatform ({ commit }) {
  commit(types.SELECT_PLATFORM_RESET)
}

async function nuxtServerInit ({ commit }) {
  const appInfoCache = await appInfo.getAppInfo()
  commit(types.APP_INFO_LOADED, Object.assign({}, appInfoCache))
  commit(types.PLATFORM_CHANGED, 'all')
}

function nuxtClientInit ({ dispatch }) {
  dispatch('loadFromLocalStorage')
}

function setFilterColor ({ commit }, color) {
  commit(types.SET_FILTER_COLOR, color)
}

function setFilterColorGradient ({ commit }, color) {
  commit(types.SET_FILTER_COLOR_GRADIENT, color)
}

function setFilterIsAnimated ({ commit }, isAnimated) {
  commit(types.SET_FILTER_IS_ANIMATED, isAnimated)
}

function setFilterAuthors ({ commit }, authors) {
  commit(types.SET_FILTER_AUTHORS, authors)
}

function selectPlatforms ({ commit }, selectedPlatforms) {
  commit(types.CHOOSE_PLATFORMS_STRING, selectedPlatforms)
}

function fillPlatformsArray ({ commit }, platforms) {
  commit(types.FILL_PLATFORMS_ARRAY, platforms)
}

function updatePlatformsArray ({ commit }, newPlatformArray) {
  commit(types.UPDATE_PLATFORMS_ARRAY, newPlatformArray)
}

function setPlatformsLength ({ commit }, length) {
  commit(types.SET_PLATFORMS_LIST_LENGTH, length)
}

function setSidebarChapter ({ commit }, chapter) {
  commit(types.SET_SIDEBAR_CHAPTER, chapter)
}

function showLinkCopyBar ({ commit }) {
  commit(types.LINK_COPY_BAR_SHOWN)
}

function hideLinkCopyBar ({ commit }) {
  commit(types.LINK_COPY_BAR_HIDDEN)
}

function setLinkCopyBarNeedShow ({ commit }, needShow) {
  commit(types.LINK_COPY_BAR_SET_NEEDSHOW, needShow)
}

function setLinkCopyBarLinkText ({ commit }, linkText) {
  commit(types.LINK_COPY_BAR_SET_LINKTEXT, linkText)
}

function toggleMobileFilter ({ commit }, isOpen) {
  commit(types.TOGGLE_MOBILE_FILTER, isOpen)
}

function setIsPageLoading ({ commit }, isPageLoading) {
  commit(types.IS_PAGE_LOADING, isPageLoading)
}

export default actions
