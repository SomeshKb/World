import * as types from './_mutationTypes'
import {DEFAULT_ICON, defaultState} from './_constants'

export default {
  /**
   * @param {object} state
   * @param {string} type
   */
  [types.RECOLOR_GRADIENT_TYPE] (state, type) {
    if (type === 'presetGradient') {
      state.recolorGradient.presetGradient.change = true
      state.recolorGradient.customGradient.change = false
    }
    state.recolorGradient.active = type
  },

  /**
   * @param {object} state
   * @param {object} gradient TODO: more strict type
   */
  [types.RECOLOR_GRADIENT_SAVE_STATE_PRESET] (state, gradient) {
    if (state.recolorGradient.presetGradient.init) {
      state.recolorGradient.presetGradient.change = true
      state.recolorGradient.customGradient.change = false
    }
    state.recolorGradient.presetGradient.init = true
    state.recolorGradient.presetGradient = Object.assign(
      state.recolorGradient.presetGradient,
      gradient
    )
  },

  /**
   * @param {object} state
   * @param {object} gradient TODO: more strict type
   */
  [types.RECOLOR_GRADIENT_SAVE_STATE_CUSTOM] (state, gradient) {
    state.recolorGradient.presetGradient.change = false
    state.recolorGradient.customGradient.change = true
    state.recolorGradient.customGradient = Object.assign(
      state.recolorGradient.customGradient,
      gradient
    )
  },

  /**
   * @param {object} state
   * @param {'png' | 'svg' | 'pdf' | 'eps' | 'svgset' | 'ico'} format
   */
  [types.CHANGE_FORMAT] (state, format) {
    state.format = format
  },

  /**
   * @param {object} state
   * @param {number} size
   */
  [types.CHANGE_SIZE] (state, size) {
    state.size = size
  },

  /**
   *
   * @param state
   * @param sizeIndex
   */
  [types.CHANGE_SIZE_INDEX] (state, sizeIndex) {
    state.sizeIndex = sizeIndex
  },

  /**
   * @param {object} state
   * @param {string} color
   */
  [types.CHANGE_COLOR] (state, color) {
    state.color = color.replace('#', '')
  },

  /**
   * @param {object} state
   * @param {object} colorMap
   */
  [types.CHANGE_COLOR_MAP] (state, colorMap) {
    state.colorMap = colorMap
  },

  /**
   * @param {object} state
   * @param {object} icon
   */
  [types.SELECT_ICON] (state, icon) {
    state.selectedIcon = {...DEFAULT_ICON, ...icon}
  },

  /**
   * @param {object} state
   * @param {object} icon
   */
  [types.SET_FULL_ICON] (state, icon) {
    state.fullIcon = {...DEFAULT_ICON, ...icon}
  },

  /**
   * @param {object} state
   * @param {object | undefined} svg
   */
  [types.SET_FULL_ICON_SVG_EFFECT] (state, svg) {
    state.fullIcon.svgEffect = svg
  },

  /**
   * @param {object} state
   * @param {string} data
   */
  [types.SET_FULL_ICON_SVG_B64] (state, data) {
    state.fullIcon.svgBase64 = data
  },

  /**
   * @param {object} state
   */
  [types.RESET_ICON] (state) {
    state.selectedIcon = defaultState.selectedIcon
    state.fullIcon = defaultState.fullIcon
  },

  /**
   * @param {object} state
   * @param {boolean} isMultiSize
   */
  [types.SET_MULTI_SIZE] (state, isMultiSize) {
    state.isMultiSize = isMultiSize
  },

  /**
   * @param {object} state
   * @param {boolean} isSimplified
   */
  [types.SET_SIMPLIFIED] (state, isSimplified) {
    state.isSimplified = isSimplified
  },

  /**
   * @param {object} state
   * @param {number | undefined} resolution
   */
  [types.CHANGE_RESOLUTION] (state, resolution) {
    state.resolution = resolution || defaultState.resolution
  },

  /**
   * @param {object} state
   * @param {object} data
   */
  [types.EXTEND_SELECTED_ICON] (state, data) {
    state.selectedIcon = Object.assign(state.selectedIcon, data)
  },

  /**
   * @param {object} state
   * @param {object} data
   */
  [types.EXTEND_FULL_ICON] (state, data) {
    state.selectedIcon = Object.assign(state.fullIcon, data)
  },

  /**
   * @param {object} state
   * @param {string} effectName
   */
  [types.SET_ACTIVE_EFFECT] (state, effectName) {
    state.accordion.activeEffect = effectName
  },

  /**
   * @param {object} state
   * @param {object} project
   */
  [types.SET_CANVAS_PROJECT] (state, project) {
    state.accordion.project = project
  }
}
